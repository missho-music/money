"use client";

import { motion } from "framer-motion";

const COLORS = ["#f4c95d", "#7dce82", "#8fd7ea", "#b9a7f2", "#ff8b5e", "#fff"];

export function Confetti({ show }: { show: boolean }) {
  if (!show) return null;
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {Array.from({ length: 40 }, (_, index) => (
        <motion.span
          key={index}
          className="absolute h-2.5 w-2 rounded-sm"
          style={{ left: `${(index * 13) % 100}%`, background: COLORS[index % COLORS.length] }}
          initial={{ y: -24, opacity: 1, rotate: 0 }}
          animate={{ y: 520, opacity: 0, rotate: index % 2 ? 200 : -160 }}
          transition={{ duration: 1.3 + (index % 6) * 0.12, ease: "easeOut" }}
        />
      ))}
    </div>
  );
}
