"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Backpack, Coins, Gift, LogOut, PawPrint, Sparkles, Store, Swords, Trophy } from "lucide-react";
import { api } from "@/lib/api";
import type { Actor } from "@/server/types";

const NAV = [
  { href: "/student", label: "寵物", icon: PawPrint },
  { href: "/student/shop", label: "商店", icon: Store },
  { href: "/student/inventory", label: "背包", icon: Backpack },
  { href: "/student/points", label: "金幣", icon: Coins },
  { href: "/student/rewards", label: "禮物", icon: Gift },
  { href: "/student/leaderboard", label: "排行", icon: Trophy },
  { href: "/student/milestones", label: "里程碑", icon: Sparkles },
  { href: "/student/battle", label: "對戰", icon: Swords },
];

export function StudentShell({ actor, children }: { actor: Actor; children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();

  async function logout() {
    await api("auth/logout", { method: "POST", body: {} });
    router.push("/login");
    router.refresh();
  }

  return (
    <div className="min-h-screen">
      <header className="border-b bg-white/80 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3">
          <Link href="/student" className="font-display text-lg font-semibold text-primary">
            Classroom Pet Quest
          </Link>
          <div className="flex items-center gap-3 text-sm">
            <span className="hidden sm:inline">{actor.displayName}</span>
            <button type="button" onClick={logout} className="inline-flex items-center gap-1 text-muted-foreground">
              <LogOut className="size-4" />
              登出
            </button>
          </div>
        </div>
        <nav className="mx-auto flex max-w-5xl gap-1 overflow-x-auto px-3 pb-3">
          {NAV.map((item) => {
            const active = pathname === item.href;
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`inline-flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-medium ${
                  active ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"
                }`}
              >
                <Icon className="size-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </header>
      <main className="mx-auto w-full max-w-5xl px-4 py-6">{children}</main>
    </div>
  );
}
