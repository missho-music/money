"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  BarChart3,
  Coins,
  Dices,
  Gift,
  LayoutDashboard,
  LogOut,
  PawPrint,
  Settings,
  Store,
  Users,
} from "lucide-react";
import { api } from "@/lib/api";
import type { Actor } from "@/server/types";

const NAV = [
  { href: "/teacher", label: "主頁", icon: LayoutDashboard },
  { href: "/teacher/classes", label: "班別管理", icon: Users },
  { href: "/teacher/draw", label: "隨機抽籤", icon: Dices },
  { href: "/teacher/points", label: "積分管理", icon: Coins },
  { href: "/teacher/pets", label: "寵物", icon: PawPrint },
  { href: "/teacher/shop", label: "商店管理", icon: Store },
  { href: "/teacher/rewards", label: "實體獎勵", icon: Gift },
  { href: "/teacher/reports", label: "報表", icon: BarChart3 },
  { href: "/teacher/settings", label: "設定", icon: Settings },
];

export function TeacherShell({ actor, children }: { actor: Actor; children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();

  async function logout() {
    await api("auth/logout", { method: "POST", body: {} });
    router.push("/login");
    router.refresh();
  }

  return (
    <div className="min-h-screen md:grid md:grid-cols-[240px_1fr]">
      <aside className="hidden bg-sidebar text-sidebar-foreground md:flex md:flex-col">
        <div className="px-5 py-6">
          <p className="font-display text-xl font-semibold">Classroom Pet Quest</p>
          <p className="mt-1 text-sm text-sidebar-foreground/70">教師控制台</p>
        </div>
        <nav className="flex flex-1 flex-col gap-1 px-3">
          {NAV.map((item) => {
            const active = pathname === item.href;
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 rounded-2xl px-3 py-2.5 text-sm font-medium ${
                  active ? "bg-sidebar-primary text-sidebar-primary-foreground" : "hover:bg-sidebar-accent"
                }`}
              >
                <Icon className="size-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="p-4">
          <p className="truncate text-sm font-medium">{actor.displayName}</p>
          <button type="button" onClick={logout} className="mt-2 flex items-center gap-2 text-sm text-sidebar-foreground/75">
            <LogOut className="size-4" />
            登出
          </button>
        </div>
      </aside>
      <div className="min-w-0">
        <div className="sticky top-0 z-30 flex gap-2 overflow-x-auto border-b bg-white/90 px-3 py-2 backdrop-blur md:hidden">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`shrink-0 rounded-full px-3 py-1.5 text-sm ${
                pathname === item.href ? "bg-primary text-primary-foreground" : "bg-muted"
              }`}
            >
              {item.label}
            </Link>
          ))}
        </div>
        <main className="mx-auto w-full max-w-6xl px-4 py-6 md:px-8 md:py-8">{children}</main>
      </div>
    </div>
  );
}
