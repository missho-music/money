"use client";

import { motion } from "framer-motion";

export type PetType = "fire" | "water" | "nature" | "thunder";

export function PetSprite({
  type,
  className = "h-52 w-52",
  happy = false,
}: {
  type: PetType;
  className?: string;
  happy?: boolean;
}) {
  return (
    <motion.div
      className={className}
      animate={happy ? { y: [0, -18, 0], rotate: [0, -8, 8, 0] } : { y: [0, -7, 0] }}
      transition={happy ? { duration: 0.55 } : { duration: 2.6, repeat: Infinity, ease: "easeInOut" }}
    >
      <svg viewBox="0 0 200 200" className="h-full w-full drop-shadow-md" role="img" aria-label={label(type)}>
        {type === "fire" && <FirePet />}
        {type === "water" && <WaterPet />}
        {type === "nature" && <NaturePet />}
        {type === "thunder" && <ThunderPet />}
      </svg>
    </motion.div>
  );
}

function label(type: PetType) {
  if (type === "fire") return "小火龍";
  if (type === "water") return "水滴獸";
  if (type === "nature") return "森林狐";
  return "雷電貓";
}

function Eyes({ y = 92 }: { y?: number }) {
  return (
    <g className="pet-eyes">
      <ellipse cx="78" cy={y} rx="11" ry="13" fill="#fff" />
      <ellipse cx="122" cy={y} rx="11" ry="13" fill="#fff" />
      <circle cx="81" cy={y + 2} r="5" fill="#2b2440" />
      <circle cx="125" cy={y + 2} r="5" fill="#2b2440" />
      <circle cx="83" cy={y} r="2" fill="#fff" />
      <circle cx="127" cy={y} r="2" fill="#fff" />
    </g>
  );
}

function FirePet() {
  return (
    <g>
      <ellipse cx="100" cy="176" rx="46" ry="10" fill="#000" opacity="0.08" />
      <path d="M146 132c18 8 22 28 8 36-10-12-14-20-8-36z" fill="#ffb703" />
      <path d="M150 124c10 2 16 14 8 22-8-8-12-14-8-22z" fill="#ff7b39" />
      <ellipse cx="100" cy="118" rx="58" ry="50" fill="#ff8b5e" />
      <ellipse cx="100" cy="132" rx="36" ry="28" fill="#ffe3c4" />
      <path d="M62 78c-2-28 22-40 28-18 6-20 30-16 28 10" fill="#ffb703" />
      <path d="M78 70c2-10 12-12 12 0" fill="#ff7b39" />
      <circle cx="58" cy="108" r="8" fill="#ffb7a1" />
      <circle cx="142" cy="108" r="8" fill="#ffb7a1" />
      <Eyes />
      <path d="M92 112c6 6 12 6 18 0" fill="none" stroke="#c2543a" strokeWidth="3" strokeLinecap="round" />
    </g>
  );
}

function WaterPet() {
  return (
    <g>
      <ellipse cx="100" cy="176" rx="42" ry="9" fill="#000" opacity="0.08" />
      <path d="M148 118c22 4 24 28 4 34-8-12-10-22-4-34z" fill="#5eb8d4" />
      <ellipse cx="100" cy="122" rx="54" ry="56" fill="#8fd7ea" />
      <ellipse cx="100" cy="136" rx="32" ry="30" fill="#e7fbff" />
      <circle cx="46" cy="96" r="10" fill="#d7f6ff" opacity="0.9" />
      <circle cx="158" cy="88" r="7" fill="#d7f6ff" />
      <path d="M70 64c8-22 28-24 30-4 10-16 28-8 24 10" fill="#5eb8d4" />
      <Eyes y={108} />
      <path d="M90 126c8 7 14 7 22 0" fill="none" stroke="#2f7f99" strokeWidth="3" strokeLinecap="round" />
    </g>
  );
}

function NaturePet() {
  return (
    <g>
      <ellipse cx="100" cy="176" rx="48" ry="10" fill="#000" opacity="0.08" />
      <path d="M132 150c28 8 36 2 42-16-20 4-32 8-42 16z" fill="#f6c28b" />
      <path d="M150 142c10-2 18 4 16 12-8-2-12-6-16-12z" fill="#7dce82" />
      <ellipse cx="96" cy="124" rx="48" ry="42" fill="#f4a261" />
      <ellipse cx="96" cy="136" rx="28" ry="22" fill="#fff1df" />
      <path d="M58 86c-6-34 20-48 28-16" fill="#f4a261" />
      <path d="M112 78c2-36 28-40 30-8" fill="#f4a261" />
      <path d="M128 48c8-16 22-8 16 6-8-2-12-2-16-6z" fill="#7dce82" />
      <circle cx="64" cy="118" r="7" fill="#f7c7b0" />
      <Eyes y={112} />
      <path d="M86 128c6 5 12 5 18 0" fill="none" stroke="#c47a45" strokeWidth="3" strokeLinecap="round" />
    </g>
  );
}

function ThunderPet() {
  return (
    <g>
      <ellipse cx="100" cy="176" rx="44" ry="9" fill="#000" opacity="0.08" />
      <path d="M150 138c16 10 14 26-2 28 2-12 0-20 2-28z" fill="#ffe08a" />
      <ellipse cx="100" cy="122" rx="52" ry="46" fill="#ffe08a" />
      <path d="M78 108h10l-6 14h12l-16 22 4-16H72z" fill="#7aa2ff" opacity="0.9" />
      <ellipse cx="104" cy="134" rx="28" ry="22" fill="#fff6d8" />
      <path d="M62 78l18 16-8-20z" fill="#f4c95d" />
      <path d="M138 78l-18 16 8-20z" fill="#f4c95d" />
      <path d="M154 96l8 4-8 2 2 8-6-6-6 4 2-8-6-2 8-2z" fill="#ffe566" />
      <Eyes y={104} />
      <path d="M90 122c8 6 16 6 24 0" fill="none" stroke="#c8962e" strokeWidth="3" strokeLinecap="round" />
    </g>
  );
}
