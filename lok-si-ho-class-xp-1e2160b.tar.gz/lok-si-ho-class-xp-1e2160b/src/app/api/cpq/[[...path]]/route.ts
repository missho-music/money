import { NextResponse } from "next/server";
import { toErrorBody } from "@/server/errors";
import { dispatch } from "@/server/router";
import { SESSION_COOKIE, getActor, sessionCookieOptions } from "@/server/session";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

async function handle(request: Request, context: { params: Promise<{ path?: string[] }> }) {
  const { path = [] } = await context.params;
  try {
    const actor = await getActor();
    const result = await dispatch(request, path, actor);
    if (result.kind === "file") {
      return new NextResponse(new Uint8Array(result.body), {
        headers: {
          "content-type": result.contentType,
          "content-disposition": `attachment; filename*=UTF-8''${encodeURIComponent(result.filename)}`,
        },
      });
    }
    const response = NextResponse.json(result.body, { status: result.status });
    if (result.session) {
      response.cookies.set(SESSION_COOKIE, result.session, sessionCookieOptions());
    } else if (result.session === null) {
      response.cookies.set(SESSION_COOKIE, "", { ...sessionCookieOptions(), maxAge: 0 });
    }
    return response;
  } catch (error) {
    const mapped = toErrorBody(error);
    return NextResponse.json(mapped.body, { status: mapped.status });
  }
}

export const GET = handle;
export const POST = handle;
export const PATCH = handle;
export const PUT = handle;
export const DELETE = handle;
