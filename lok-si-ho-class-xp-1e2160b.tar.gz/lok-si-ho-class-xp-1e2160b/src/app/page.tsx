import Link from "next/link";
import { Coins, Dices, PawPrint } from "lucide-react";

export default function HomePage() {
  return (
    <div className="mx-auto flex min-h-screen max-w-5xl flex-col px-5 py-8">
      <header className="flex items-center justify-between">
        <p className="font-display text-lg font-semibold text-primary">Classroom Pet Quest</p>
        <Link href="/login" className="rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">
          登入
        </Link>
      </header>
      <section className="grid items-center gap-8 py-12 md:grid-cols-[1.2fr_0.8fr]">
        <div>
          <p className="text-sm font-medium text-primary">香港中學課堂用</p>
          <h1 className="font-display mt-3 text-4xl font-semibold leading-tight md:text-6xl">
            抽一位同學，
            <br />
            養成一隻夥伴。
          </h1>
          <p className="mt-4 max-w-xl text-base leading-7 text-muted-foreground">
            把隨機抽籤、寵物金幣和虛擬寵物放在同一個畫面。老師投影時可以即時抽人、加分；同學用自己的帳號看寵物、逛商店、兌換老師準備的小禮物。
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link href="/login" className="rounded-full bg-primary px-5 py-3 text-sm font-medium text-primary-foreground">
              教師登入
            </Link>
            <Link href="/login" className="rounded-full bg-secondary px-5 py-3 text-sm font-medium text-secondary-foreground">
              學生登入
            </Link>
          </div>
        </div>
        <div className="rounded-[2rem] bg-white p-6 shadow-sm ring-1 ring-foreground/5">
          <div className="rounded-3xl bg-gradient-to-b from-sky-100 to-emerald-100 p-6 text-center">
            <p className="text-xs text-muted-foreground">抽籤畫面示意</p>
            <p className="font-display mt-2 text-3xl text-primary">陳同學</p>
            <p className="mt-2 text-sm text-muted-foreground">抽中後可直接加寵物金幣</p>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2 text-center text-sm">
            <div className="rounded-2xl bg-muted p-3">
              <Dices className="mx-auto size-4 text-primary" />
              <p className="mt-1 font-medium">抽籤</p>
            </div>
            <div className="rounded-2xl bg-accent p-3">
              <Coins className="mx-auto size-4" />
              <p className="mt-1 font-medium">金幣</p>
            </div>
            <div className="rounded-2xl bg-secondary p-3">
              <PawPrint className="mx-auto size-4" />
              <p className="mt-1 font-medium">寵物</p>
            </div>
          </div>
        </div>
      </section>
      <section className="grid gap-4 md:grid-cols-3">
        {[
          ["同一輪不重複", "全班都被抽中一次之前，系統不會再抽到同一位同學。缺席的同學保留機會。"],
          ["金幣有帳目", "加分、扣分、買裝備和兌換禮物都會留下紀錄，餘額不會變成負數。"],
          ["投影夠大", "抽籤結果用大字顯示。可以關掉動畫，也可以只顯示課堂暱稱。"],
        ].map(([title, copy]) => (
          <article key={title} className="rounded-3xl bg-white p-5 ring-1 ring-foreground/5">
            <h2 className="font-display text-xl">{title}</h2>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">{copy}</p>
          </article>
        ))}
      </section>
      <p className="mt-10 text-xs leading-5 text-muted-foreground">
        學生資料只供課堂管理。投影畫面可改用顯示名稱。正式使用前請關閉示範模式，並依校方個人資料政策匯出或封存紀錄。
      </p>
    </div>
  );
}
