"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ApiError, api } from "@/lib/api";

interface Item {
  itemId: string;
  name: string;
  category: string;
  categoryLabel: string;
  rarity: string;
  rarityLabel: string;
  price: number;
  description: string;
  stock: number | null;
  purchaseLimit: number | null;
  minLevel: number;
  isActive: boolean;
  statsBonus: { hp: number; attack: number; defense: number; speed: number; criticalRate: number };
}

const blank = {
  name: "",
  category: "weapon",
  rarity: "common",
  price: 10,
  description: "",
  stock: "",
  purchaseLimit: "",
  minLevel: 1,
  isActive: true,
  attack: 0,
  defense: 0,
  hp: 0,
  speed: 0,
  criticalRate: 0,
};

export default function ShopAdminPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<string | null>(null);
  const [form, setForm] = useState(blank);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setItems(await api<Item[]>("items"));
  }
  useEffect(() => { load().catch((reason) => setError(reason instanceof ApiError ? reason.message : "未能載入商店")); }, []);

  function edit(item?: Item) {
    setEditing(item?.itemId ?? null);
    setForm(item ? {
      name: item.name,
      category: item.category,
      rarity: item.rarity,
      price: item.price,
      description: item.description,
      stock: item.stock == null ? "" : String(item.stock),
      purchaseLimit: item.purchaseLimit == null ? "" : String(item.purchaseLimit),
      minLevel: item.minLevel,
      isActive: item.isActive,
      attack: item.statsBonus.attack,
      defense: item.statsBonus.defense,
      hp: item.statsBonus.hp,
      speed: item.statsBonus.speed,
      criticalRate: item.statsBonus.criticalRate,
    } : blank);
    setOpen(true);
  }

  async function save() {
    const body = {
      name: form.name,
      category: form.category,
      rarity: form.rarity,
      price: Number(form.price),
      description: form.description,
      stock: form.stock === "" ? null : Number(form.stock),
      purchaseLimit: form.purchaseLimit === "" ? null : Number(form.purchaseLimit),
      minLevel: Number(form.minLevel),
      isActive: form.isActive,
      statsBonus: { hp: Number(form.hp), attack: Number(form.attack), defense: Number(form.defense), speed: Number(form.speed), criticalRate: Number(form.criticalRate) },
    };
    try {
      await api(editing ? `items/${editing}` : "items", { method: editing ? "PATCH" : "POST", body });
      setOpen(false);
      toast.success("商品已儲存，學生商店會即時看到");
      await load();
    } catch (reason) {
      toast.error(reason instanceof ApiError ? reason.message : "未能儲存商品");
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-semibold">商店管理</h1>
          <p className="text-sm text-muted-foreground">虛擬裝備和消耗品。實體禮物在另一頁管理。</p>
        </div>
        <Button className="h-10" onClick={() => edit()}>新增商品</Button>
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}
      <div className="grid gap-3 md:grid-cols-2">
        {items.map((item) => (
          <article key={item.itemId} className={`rounded-3xl bg-white p-4 rarity-${item.rarity}`}>
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-medium">{item.name}</p>
                <p className="text-sm text-muted-foreground">{item.categoryLabel} · {item.rarityLabel} · {item.price} 金幣</p>
                <p className="mt-1 text-sm">{item.description}</p>
                <p className="mt-1 text-xs text-muted-foreground">{item.isActive ? "發售中" : "已下架"} · 庫存 {item.stock ?? "不限"} · 每人上限 {item.purchaseLimit ?? "不限"}</p>
              </div>
              <Button variant="outline" className="h-9" onClick={() => edit(item)}>編輯</Button>
            </div>
          </article>
        ))}
      </div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>{editing ? "編輯商品" : "新增商品"}</DialogTitle></DialogHeader>
          <div className="grid gap-2">
            <Input className="h-10" placeholder="名稱" value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} />
            <div className="grid grid-cols-2 gap-2">
              <select className="h-10 rounded-lg border px-2" value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value })}>
                <option value="weapon">武器</option><option value="armor">防具</option><option value="headgear">頭飾</option><option value="accessory">飾品</option><option value="consumable">消耗品</option><option value="cosmetic">寵物造型</option>
              </select>
              <select className="h-10 rounded-lg border px-2" value={form.rarity} onChange={(event) => setForm({ ...form, rarity: event.target.value })}>
                <option value="common">普通</option><option value="rare">稀有</option><option value="epic">史詩</option><option value="legendary">傳說</option>
              </select>
            </div>
            <Input className="h-10" type="number" value={form.price} onChange={(event) => setForm({ ...form, price: Number(event.target.value) })} />
            <Textarea value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} />
            <div className="grid grid-cols-2 gap-2">
              <Input className="h-10" placeholder="攻擊" value={form.attack} onChange={(event) => setForm({ ...form, attack: Number(event.target.value) })} />
              <Input className="h-10" placeholder="防禦" value={form.defense} onChange={(event) => setForm({ ...form, defense: Number(event.target.value) })} />
              <Input className="h-10" placeholder="生命" value={form.hp} onChange={(event) => setForm({ ...form, hp: Number(event.target.value) })} />
              <Input className="h-10" placeholder="速度" value={form.speed} onChange={(event) => setForm({ ...form, speed: Number(event.target.value) })} />
            </div>
            <Input className="h-10" placeholder="暴擊%" value={form.criticalRate} onChange={(event) => setForm({ ...form, criticalRate: Number(event.target.value) })} />
            <Input className="h-10" placeholder="庫存，留空代表不限" value={form.stock} onChange={(event) => setForm({ ...form, stock: event.target.value })} />
            <Input className="h-10" placeholder="每人上限，留空代表不限" value={form.purchaseLimit} onChange={(event) => setForm({ ...form, purchaseLimit: event.target.value })} />
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.isActive} onChange={(event) => setForm({ ...form, isActive: event.target.checked })} />開放購買</label>
            <Button className="h-10" onClick={save}>儲存</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
