"use client";

import { useEffect, useState } from "react";
import { PetSprite, type PetType } from "@/components/pet-art";
import { ApiError, api } from "@/lib/api";

interface Row {
  student: { studentId: string; classNumber: number; studentName: string };
  detail: { pet: { name: string; petType: PetType; level: number }; combat: { final: { attack: number; defense: number; speed: number } } } | null;
}
interface ClassRoom { classId: string; className: string; status: string }

export default function PetsAdminPage() {
  const [classes, setClasses] = useState<ClassRoom[]>([]);
  const [classId, setClassId] = useState("");
  const [rows, setRows] = useState<Row[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<ClassRoom[]>("classes").then((list) => {
      const active = list.filter((item) => item.status === "active");
      setClasses(active);
      setClassId(active[0]?.classId ?? "");
    }).catch((reason) => setError(reason instanceof ApiError ? reason.message : "未能載入"));
  }, []);
  useEffect(() => {
    if (!classId) return;
    api<Row[]>(`pets?classId=${classId}`).then(setRows).catch((reason) => setError(reason instanceof ApiError ? reason.message : "未能載入寵物"));
  }, [classId]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-semibold">寵物</h1>
          <p className="text-sm text-muted-foreground">能力由等級和裝備計算，老師不能直接改數字。</p>
        </div>
        <select className="h-10 rounded-xl border bg-white px-3" value={classId} onChange={(event) => setClassId(event.target.value)}>
          {classes.map((room) => <option key={room.classId} value={room.classId}>{room.className}</option>)}
        </select>
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {rows.map((row) => (
          <article key={row.student.studentId} className="rounded-3xl bg-white p-4 ring-1 ring-foreground/5">
            <div className="flex items-center gap-3">
              {row.detail ? <PetSprite type={row.detail.pet.petType} className="h-20 w-20" /> : <div className="grid h-20 w-20 place-items-center rounded-full bg-muted text-xs">未選擇</div>}
              <div>
                <p className="font-medium">{row.student.classNumber} {row.student.studentName}</p>
                <p className="text-sm text-muted-foreground">{row.detail ? `${row.detail.pet.name} · Lv.${row.detail.pet.level}` : "尚未選擇寵物"}</p>
              </div>
            </div>
            {row.detail && <p className="mt-2 text-xs text-muted-foreground">攻擊 {row.detail.combat.final.attack} · 防禦 {row.detail.combat.final.defense} · 速度 {row.detail.combat.final.speed}</p>}
          </article>
        ))}
      </div>
    </div>
  );
}
