"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Coins, Dices, Gift, Users } from "lucide-react";
import { ApiError, api } from "@/lib/api";

interface Report {
  classCount: number;
  studentCount: number;
  drawsToday: number;
  coinsToday: number;
  pendingRewards: number;
  classRows: {
    classId: string;
    className: string;
    studentCount: number;
    drawnThisRound: number;
    roundNumber: number;
    roundStatus: string;
    lifetimeEarned: number;
  }[];
}

export default function TeacherHomePage() {
  const [report, setReport] = useState<Report | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<Report>("reports")
      .then(setReport)
      .catch((reason) => setError(reason instanceof ApiError ? reason.message : "未能載入主頁"));
  }, []);

  const cards = report
    ? [
        ["管理班別", report.classCount, "班"],
        ["在學學生", report.studentCount, "人"],
        ["今日抽籤", report.drawsToday, "次"],
        ["今日發出金幣", report.coinsToday, "枚"],
        ["待領取禮物", report.pendingRewards, "張"],
      ]
    : [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold">今日課堂</h1>
        <p className="mt-1 text-sm text-muted-foreground">數字來自已儲存的抽籤、積分和兌換紀錄。</p>
      </div>
      {error && <p className="rounded-2xl bg-destructive/10 px-4 py-3 text-sm text-destructive">{error}</p>}
      {!report && !error && <p className="text-sm text-muted-foreground">正在整理今日數據…</p>}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        {cards.map(([label, value, unit]) => (
          <article key={String(label)} className="rounded-3xl bg-white p-4 ring-1 ring-foreground/5">
            <p className="text-sm text-muted-foreground">{label}</p>
            <p className="font-display mt-2 text-3xl">
              {value}
              <span className="ml-1 text-base text-muted-foreground">{unit}</span>
            </p>
          </article>
        ))}
      </div>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Quick href="/teacher/draw" icon={<Dices />} title="開始抽籤" copy="投影抽人並即時加分" />
        <Quick href="/teacher/points" icon={<Coins />} title="學生加分" copy="個人、多選或全班" />
        <Quick href="/teacher/classes" icon={<Users />} title="管理班別" copy="匯入名單、點缺席" />
        <Quick href="/teacher/rewards" icon={<Gift />} title="獎勵兌換" copy="查看待領取清單" />
      </div>
      <section className="rounded-3xl bg-white p-5 ring-1 ring-foreground/5">
        <h2 className="font-display text-xl">各班本輪進度</h2>
        <div className="mt-4 space-y-3">
          {report?.classRows.length === 0 && <p className="text-sm text-muted-foreground">尚未建立班別。</p>}
          {report?.classRows.map((room) => {
            const pct = room.studentCount ? Math.round((room.drawnThisRound / room.studentCount) * 100) : 0;
            return (
              <div key={room.classId}>
                <div className="flex justify-between text-sm">
                  <span className="font-medium">{room.className}</span>
                  <span className="text-muted-foreground">
                    第 {room.roundNumber || 1} 輪 · 已抽 {room.drawnThisRound}/{room.studentCount}
                    {room.roundStatus === "completed" ? " · 本輪已完成" : ""}
                  </span>
                </div>
                <div className="mt-1 h-2 rounded-full bg-muted">
                  <div className="h-2 rounded-full bg-primary" style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}

function Quick({ href, icon, title, copy }: { href: string; icon: React.ReactNode; title: string; copy: string }) {
  return (
    <Link href={href} className="rounded-3xl bg-white p-4 ring-1 ring-foreground/5 transition hover:-translate-y-0.5">
      <div className="text-primary">{icon}</div>
      <p className="mt-3 font-medium">{title}</p>
      <p className="text-sm text-muted-foreground">{copy}</p>
    </Link>
  );
}
