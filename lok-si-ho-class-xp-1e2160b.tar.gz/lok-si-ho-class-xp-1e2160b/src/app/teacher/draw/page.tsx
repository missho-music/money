"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { Confetti } from "@/components/confetti";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { ApiError, api, idempotencyKey } from "@/lib/api";

interface ClassRoom {
  classId: string;
  className: string;
  status: string;
}
interface RosterStudent {
  studentId: string;
  classNumber: number;
  studentName: string;
  displayName: string;
  state: "drawn" | "absent" | "remaining";
}
interface DrawState {
  className: string;
  roundNumber: number;
  roundStatus: string;
  totalActive: number;
  drawnCount: number;
  remainingCount: number;
  absentCount: number;
  roster: RosterStudent[];
  fastDraw: boolean;
  projectionShowsFullName: boolean;
  pointRules: { id: string; label: string; points: number }[];
}
interface Selected {
  status: "selected";
  draw: { drawId: string };
  student: { studentId: string; classNumber: number; studentName: string; displayName: string; className: string };
  roundNumber: number;
  drawnCount: number;
  total: number;
  roundComplete: boolean;
  message: string | null;
}
interface Complete {
  status: "round_complete";
  roundNumber: number;
  message: string;
}

export default function DrawPage() {
  const [classes, setClasses] = useState<ClassRoom[]>([]);
  const [classId, setClassId] = useState("");
  const [state, setState] = useState<DrawState | null>(null);
  const [phase, setPhase] = useState<"idle" | "spinning" | "result" | "complete">("idle");
  const [shown, setShown] = useState("準備好了");
  const [result, setResult] = useState<Selected | null>(null);
  const [busy, setBusy] = useState(false);
  const [awarded, setAwarded] = useState<string[]>([]);
  const [skipOpen, setSkipOpen] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const [customOpen, setCustomOpen] = useState(false);
  const [customAmount, setCustomAmount] = useState("4");
  const [customReason, setCustomReason] = useState("自訂加分");
  const [projection, setProjection] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<ClassRoom[]>("classes")
      .then((rows) => {
        const active = rows.filter((row) => row.status === "active");
        setClasses(active);
        setClassId((current) => current || active[0]?.classId || "");
      })
      .catch((reason) => setError(reason instanceof ApiError ? reason.message : "未能載入班別"));
  }, []);

  useEffect(() => {
    if (!classId) return;
    api<DrawState>(`draws/state?classId=${classId}`)
      .then((next) => {
        setState(next);
        if (next.roundStatus === "completed") setPhase("complete");
        else setPhase("idle");
        setResult(null);
      })
      .catch((reason) => setError(reason instanceof ApiError ? reason.message : "未能載入抽籤進度"));
  }, [classId]);

  async function reload() {
    if (!classId) return;
    const next = await api<DrawState>(`draws/state?classId=${classId}`);
    setState(next);
  }

  async function start() {
    if (!state || busy) return;
    setBusy(true);
    setError(null);
    setPhase("spinning");
    const reel = state.roster.filter((student) => student.state !== "absent");
    try {
      const data = await api<Selected | Complete>("draws", {
        method: "POST",
        body: { classId, idempotencyKey: idempotencyKey("draw") },
      });
      if (data.status === "round_complete") {
        setPhase("complete");
        setResult(null);
        toast.message(data.message);
        await reload();
        return;
      }
      const steps = state.fastDraw ? 1 : 24;
      for (let index = 0; index < steps; index += 1) {
        const pick = reel[Math.floor(Math.random() * Math.max(reel.length, 1))];
        setShown(pick ? `${pick.classNumber} ${pick.displayName}` : "…");
        await wait(40 + (index / steps) ** 2 * 170);
      }
      const name = state.projectionShowsFullName ? data.student.studentName : data.student.displayName;
      setShown(`${data.student.classNumber} ${name}`);
      setResult(data);
      setAwarded([]);
      setPhase("result");
      await reload();
    } catch (reason) {
      setPhase(state.roundStatus === "completed" ? "complete" : "idle");
      const message = reason instanceof ApiError ? reason.message : "抽籤未能完成";
      setError(message);
      toast.error(message);
    } finally {
      setBusy(false);
    }
  }

  async function award(ruleId: string, amount?: number, reason?: string) {
    if (!result || awarded.includes(ruleId)) return;
    setAwarded((current) => [...current, ruleId]);
    try {
      const response = await api<{ already: boolean; transactions: { amount: number }[] }>("points/draw-award", {
        method: "POST",
        body: {
          drawId: result.draw.drawId,
          ruleId,
          amount,
          reason,
          idempotencyKey: idempotencyKey(`award-${ruleId}`),
        },
      });
      const gained = response.transactions[0]?.amount ?? amount ?? 0;
      toast.success(response.already ? "這項加分已經記錄" : `已加 ${gained} 寵物金幣`);
    } catch (reason) {
      setAwarded((current) => current.filter((id) => id !== ruleId));
      toast.error(reason instanceof ApiError ? reason.message : "加分失敗");
    }
  }

  async function resolve(action: "return" | "mark") {
    if (!result) return;
    setSkipOpen(false);
    try {
      await api("draws/resolve", { method: "POST", body: { drawId: result.draw.drawId, action } });
      toast.success(action === "return" ? "已返回未抽名單" : "已標記為本輪抽中");
      setPhase("idle");
      setResult(null);
      await reload();
    } catch (reason) {
      toast.error(reason instanceof ApiError ? reason.message : "未能更新抽籤結果");
    }
  }

  async function reset() {
    setResetOpen(false);
    try {
      await api("draws/reset", {
        method: "POST",
        body: { classId, confirm: true, idempotencyKey: idempotencyKey("reset") },
      });
      toast.success("新一輪已開始，過往紀錄仍然保留");
      setPhase("idle");
      setResult(null);
      await reload();
    } catch (reason) {
      toast.error(reason instanceof ApiError ? reason.message : "未能開始新一輪");
    }
  }

  async function toggleFast() {
    if (!state) return;
    const fastDraw = !state.fastDraw;
    setState({ ...state, fastDraw });
    await api("settings", { method: "PATCH", body: { fastDraw } });
  }

  const stage = (
    <div className={`relative overflow-hidden rounded-[2rem] bg-[#2a2558] text-white ${projection ? "min-h-[80vh]" : ""}`}>
      <Confetti show={phase === "result" || phase === "complete"} />
      <div className="relative px-6 py-10 text-center md:px-12">
        <p className="text-sm text-white/70">
          {state ? `${state.className} · 第 ${state.roundNumber || 1} 輪` : "選擇班別"}
        </p>
        <motion.p
          key={shown + phase}
          initial={{ scale: 0.92, opacity: 0.4 }}
          animate={{ scale: 1, opacity: 1 }}
          className="font-display mt-4 text-5xl font-semibold md:text-7xl"
        >
          {phase === "complete" ? "本輪抽籤已完成！" : phase === "idle" ? state?.className || "選擇班別" : shown}
        </motion.p>
        {phase === "result" && result && (
          <p className="mt-3 text-lg text-white/80">
            {result.student.className} · {result.student.classNumber} 號 · {result.student.studentName}
          </p>
        )}
        {phase === "idle" && state && (
          <p className="mt-4 text-white/75">
            在學 {state.totalActive} · 已抽 {state.drawnCount} · 未抽 {state.remainingCount} · 缺席 {state.absentCount}
          </p>
        )}
        {phase === "complete" && (
          <p className="mt-4 text-white/75">歷史紀錄已保留。確認後才會開始下一輪。</p>
        )}
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          {phase !== "result" && phase !== "complete" && (
            <Button onClick={start} disabled={busy || !classId || state?.remainingCount === 0} className="h-14 rounded-full bg-amber-300 px-8 text-lg text-amber-950 hover:bg-amber-200">
              {busy ? "抽籤中…" : "開始抽籤"}
            </Button>
          )}
          {phase === "result" && (
            <Button onClick={() => (result?.roundComplete ? setPhase("complete") : setPhase("idle"))} className="h-12 rounded-full px-6">
              下一位
            </Button>
          )}
          {phase === "complete" && (
            <Button onClick={() => setResetOpen(true)} className="h-12 rounded-full bg-amber-300 px-6 text-amber-950 hover:bg-amber-200">
              開始新一輪
            </Button>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className={projection ? "fixed inset-0 z-50 overflow-auto bg-[#221c4a] p-4 md:p-8" : "space-y-4"}>
      <div className={projection ? "mx-auto max-w-5xl space-y-4" : "space-y-4"}>
        <div className="flex flex-wrap items-center gap-3">
          <select value={classId} onChange={(event) => setClassId(event.target.value)} className="h-11 rounded-xl border bg-white px-3 text-base text-foreground">
            {classes.map((room) => (
              <option key={room.classId} value={room.classId}>{room.className}</option>
            ))}
          </select>
          <Button variant="outline" className="h-11 bg-white" onClick={toggleFast}>
            {state?.fastDraw ? "快速抽籤開" : "快速抽籤關"}
          </Button>
          <Button variant="outline" className="h-11 bg-white" onClick={() => setProjection((value) => !value)}>
            {projection ? "離開投影" : "投影模式"}
          </Button>
          <Button variant="outline" className="h-11 bg-white" onClick={() => setResetOpen(true)}>
            重設本輪
          </Button>
        </div>
        {error && <p className="rounded-2xl bg-white px-4 py-3 text-sm text-destructive">{error}</p>}
        {classes.length === 0 && !error && <p className="text-sm text-muted-foreground">尚未有可抽籤的班別。</p>}
        {stage}
        {phase === "result" && result && state && (
          <div className="grid gap-3 rounded-3xl bg-white p-4 md:grid-cols-2">
            <div className="flex flex-wrap gap-2">
              {state.pointRules.map((rule) => (
                <Button key={rule.id} className="h-11" disabled={awarded.includes(rule.id)} onClick={() => award(rule.id)}>
                  {rule.label} +{rule.points}
                </Button>
              ))}
              <Button variant="secondary" className="h-11" onClick={() => setCustomOpen(true)}>自訂加分</Button>
            </div>
            <div className="flex flex-wrap gap-2 md:justify-end">
              <Button variant="outline" className="h-11" onClick={() => setSkipOpen(true)}>略過</Button>
            </div>
          </div>
        )}
      </div>
      <Dialog open={skipOpen} onOpenChange={setSkipOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>這位同學怎樣處理？</DialogTitle>
            <DialogDescription>稍後再抽會返回未抽名單。標記已抽中則本輪不再抽到。</DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-2">
            <Button className="h-11" onClick={() => resolve("return")}>稍後再抽</Button>
            <Button variant="secondary" className="h-11" onClick={() => resolve("mark")}>標記為已抽中</Button>
          </div>
        </DialogContent>
      </Dialog>
      <Dialog open={resetOpen} onOpenChange={setResetOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>開始新一輪？</DialogTitle>
            <DialogDescription>未抽完的同學本輪機會會結束。所有歷史抽籤紀錄會保留。</DialogDescription>
          </DialogHeader>
          <Button className="h-11" onClick={reset}>確認開始新一輪</Button>
        </DialogContent>
      </Dialog>
      <Dialog open={customOpen} onOpenChange={setCustomOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>自訂加分</DialogTitle>
            <DialogDescription>同一抽籤結果的自訂加分只會記錄一次。</DialogDescription>
          </DialogHeader>
          <Input value={customAmount} onChange={(event) => setCustomAmount(event.target.value)} className="h-11" inputMode="numeric" />
          <Input value={customReason} onChange={(event) => setCustomReason(event.target.value)} className="h-11" />
          <Button
            className="h-11"
            onClick={() => {
              setCustomOpen(false);
              void award("custom", Number(customAmount), customReason);
            }}
          >
            確認加分
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function wait(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
