"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ApiError, api, formatWhen } from "@/lib/api";

interface Reward { rewardId: string; name: string; description: string; price: number; stock: number; isActive: boolean }
interface Order {
  orderId: string;
  itemName: string;
  studentName?: string;
  classNumber?: number | null;
  status: string;
  totalPrice: number;
  createdAt: string;
  orderType: string;
}

export default function RewardsPage() {
  const [rewards, setRewards] = useState<Reward[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [status, setStatus] = useState("pending");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Reward | null>(null);
  const [form, setForm] = useState({ name: "", description: "", price: 10, stock: 10, isActive: true });
  const [error, setError] = useState<string | null>(null);

  async function load() {
    const [rewardRows, orderRows] = await Promise.all([
      api<Reward[]>("rewards"),
      api<Order[]>(`orders?orderType=physical&status=${status}`),
    ]);
    setRewards(rewardRows);
    setOrders(orderRows);
  }
  useEffect(() => { load().catch((reason) => setError(reason instanceof ApiError ? reason.message : "未能載入獎勵")); }, [status]);

  async function save() {
    try {
      await api(editing ? `rewards/${editing.rewardId}` : "rewards", { method: editing ? "PATCH" : "POST", body: form });
      setOpen(false);
      toast.success("實體獎勵已更新");
      await load();
    } catch (reason) {
      toast.error(reason instanceof ApiError ? reason.message : "未能儲存");
    }
  }

  async function act(orderId: string, action: "fulfill" | "cancel") {
    try {
      await api(`orders/${orderId}/${action}`, { method: "POST", body: action === "cancel" ? { note: "缺貨取消" } : {} });
      toast.success(action === "fulfill" ? "已標記領取" : "已取消並退回金幣");
      await load();
    } catch (reason) {
      toast.error(reason instanceof ApiError ? reason.message : "未能更新訂單");
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-semibold">實體獎勵</h1>
          <p className="text-sm text-muted-foreground">文具、貼紙和小禮物跟虛擬裝備分開。取消訂單會退回金幣。</p>
        </div>
        <Button className="h-10" onClick={() => { setEditing(null); setForm({ name: "", description: "", price: 10, stock: 10, isActive: true }); setOpen(true); }}>新增獎勵</Button>
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}
      <div className="grid gap-3 md:grid-cols-2">
        {rewards.map((reward) => (
          <article key={reward.rewardId} className="rounded-3xl bg-white p-4 ring-1 ring-foreground/5">
            <p className="font-medium">{reward.name}</p>
            <p className="text-sm text-muted-foreground">{reward.price} 金幣 · 餘下 {reward.stock} · {reward.isActive ? "開放兌換" : "已關閉"}</p>
            <p className="mt-1 text-sm">{reward.description}</p>
            <Button variant="outline" className="mt-3 h-9" onClick={() => { setEditing(reward); setForm(reward); setOpen(true); }}>編輯</Button>
          </article>
        ))}
      </div>
      <div className="flex gap-2">
        {[["pending", "待領取"], ["fulfilled", "已領取"], ["cancelled", "已取消"]].map(([value, label]) => (
          <Button key={value} variant={status === value ? "default" : "outline"} className="h-9" onClick={() => setStatus(value)}>{label}</Button>
        ))}
      </div>
      <div className="space-y-2">
        {orders.length === 0 && <p className="text-sm text-muted-foreground">這個狀態沒有訂單。</p>}
        {orders.map((order) => (
          <article key={order.orderId} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-white px-4 py-3 ring-1 ring-foreground/5">
            <div>
              <p className="font-medium">{order.studentName} · {order.classNumber} 號</p>
              <p className="text-sm text-muted-foreground">{order.itemName} · {order.totalPrice} 金幣 · {formatWhen(order.createdAt)}</p>
            </div>
            {order.status === "pending" && (
              <div className="flex gap-2">
                <Button className="h-9" onClick={() => act(order.orderId, "fulfill")}>已派發</Button>
                <Button variant="outline" className="h-9" onClick={() => act(order.orderId, "cancel")}>取消並退款</Button>
              </div>
            )}
          </article>
        ))}
      </div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "編輯獎勵" : "新增實體獎勵"}</DialogTitle></DialogHeader>
          <Input className="h-10" placeholder="名稱" value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} />
          <Textarea value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} />
          <Input className="h-10" type="number" value={form.price} onChange={(event) => setForm({ ...form, price: Number(event.target.value) })} />
          <Input className="h-10" type="number" value={form.stock} onChange={(event) => setForm({ ...form, stock: Number(event.target.value) })} />
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.isActive} onChange={(event) => setForm({ ...form, isActive: event.target.checked })} />開放兌換</label>
          <Button className="h-10" onClick={save}>儲存</Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
