"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ApiError, api } from "@/lib/api";

interface ClassRoom {
  classId: string;
  className: string;
  schoolYear: string;
  status: string;
  studentCount: number;
}
interface StudentRow {
  studentId: string;
  classId: string;
  classNumber: number;
  studentName: string;
  displayName: string;
  enrollmentStatus: string;
  loginId: string | null;
  absentToday: boolean;
  wallet: { currentBalance: number };
}
interface ImportResult {
  created: { studentName: string; className: string; classNumber: number; loginId: string; temporaryPassword: string }[];
  skipped: { row: number; reason: string }[];
  errors: { row: number; reason: string }[];
}

const emptyForm = { studentName: "", displayName: "", classNumber: "", enrollmentStatus: "active", classId: "" };

export default function ClassesPage() {
  const [classes, setClasses] = useState<ClassRoom[]>([]);
  const [classId, setClassId] = useState("");
  const [students, setStudents] = useState<StudentRow[]>([]);
  const [query, setQuery] = useState("");
  const [className, setClassName] = useState("");
  const [form, setForm] = useState(emptyForm);
  const [editing, setEditing] = useState<StudentRow | null>(null);
  const [open, setOpen] = useState(false);
  const [imported, setImported] = useState<ImportResult | null>(null);
  const [passwordNote, setPasswordNote] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function loadClasses(prefer?: string) {
    const rows = await api<ClassRoom[]>("classes");
    setClasses(rows);
    const next = prefer || classId || rows.find((row) => row.status === "active")?.classId || rows[0]?.classId || "";
    setClassId(next);
    return next;
  }

  async function loadStudents(id = classId, q = query) {
    if (!id) return;
    const rows = await api<StudentRow[]>(`students?classId=${id}&q=${encodeURIComponent(q)}`);
    setStudents(rows);
  }

  useEffect(() => {
    loadClasses().catch((reason) => setError(reason instanceof ApiError ? reason.message : "未能載入班別"));
    // initial load only
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!classId) return;
    loadStudents(classId).catch((reason) => setError(reason instanceof ApiError ? reason.message : "未能載入學生"));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [classId]);

  async function createClassRoom() {
    try {
      const room = await api<ClassRoom>("classes", { method: "POST", body: { className } });
      setClassName("");
      toast.success(`已新增 ${room.className}`);
      await loadClasses(room.classId);
    } catch (reason) {
      toast.error(reason instanceof ApiError ? reason.message : "未能新增班別");
    }
  }

  async function archive() {
    const room = classes.find((item) => item.classId === classId);
    if (!room || !confirm(`封存 ${room.className}？學生、積分和抽籤紀錄會保留。`)) return;
    await api(`classes/${classId}`, { method: "PATCH", body: { status: room.status === "archived" ? "active" : "archived" } });
    await loadClasses(classId);
  }

  async function saveStudent() {
    try {
      if (editing) {
        await api(`students/${editing.studentId}`, {
          method: "PATCH",
          body: {
            studentName: form.studentName,
            displayName: form.displayName || form.studentName,
            classNumber: Number(form.classNumber),
            classId: form.classId,
            enrollmentStatus: form.enrollmentStatus,
          },
        });
        toast.success("學生資料已更新");
      } else {
        const created = await api<{ loginId: string; temporaryPassword: string }>("students", {
          method: "POST",
          body: {
            classId,
            classNumber: Number(form.classNumber),
            studentName: form.studentName,
            displayName: form.displayName || form.studentName,
          },
        });
        setPasswordNote(`${created.loginId} 的首次密碼：${created.temporaryPassword}`);
      }
      setOpen(false);
      await loadStudents();
      await loadClasses(classId);
    } catch (reason) {
      toast.error(reason instanceof ApiError ? reason.message : "未能儲存學生");
    }
  }

  async function importFile(file: File) {
    const payload = await readImport(file);
    try {
      const result = await api<ImportResult>("students/import", { method: "POST", body: payload });
      setImported(result);
      await loadClasses(classId);
      await loadStudents();
    } catch (reason) {
      toast.error(reason instanceof ApiError ? reason.message : "匯入失敗");
    }
  }

  async function saveAbsence(student: StudentRow, absent: boolean) {
    const ids = students.filter((item) => (item.studentId === student.studentId ? absent : item.absentToday)).map((item) => item.studentId);
    try {
      await api("absences", { method: "PUT", body: { classId, studentIds: ids } });
      setStudents((current) => current.map((item) => (item.studentId === student.studentId ? { ...item, absentToday: absent } : item)));
    } catch (reason) {
      toast.error(reason instanceof ApiError ? reason.message : "未能更新缺席");
    }
  }

  async function resetPassword(student: StudentRow) {
    try {
      const result = await api<{ loginId: string; temporaryPassword: string }>(`students/${student.studentId}/password`, {
        method: "POST",
        body: {},
      });
      setPasswordNote(`${result.loginId} 的新密碼：${result.temporaryPassword}`);
    } catch (reason) {
      toast.error(reason instanceof ApiError ? reason.message : "未能重設密碼");
    }
  }

  const room = classes.find((item) => item.classId === classId);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-3xl font-semibold">班別管理</h1>
        <p className="mt-1 text-sm text-muted-foreground">以班別加學號核對學生。轉班會保留積分、寵物和抽籤紀錄。</p>
      </div>
      {error && <p className="rounded-2xl bg-destructive/10 px-4 py-3 text-sm text-destructive">{error}</p>}
      {passwordNote && <p className="rounded-2xl bg-accent px-4 py-3 text-sm">{passwordNote}　請只向該學生展示一次。</p>}
      <div className="grid gap-4 lg:grid-cols-[240px_1fr]">
        <aside className="space-y-3 rounded-3xl bg-white p-4 ring-1 ring-foreground/5">
          {classes.map((item) => (
            <button key={item.classId} type="button" onClick={() => setClassId(item.classId)} className={`block w-full rounded-2xl px-3 py-2 text-left ${item.classId === classId ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
              <span className="font-medium">{item.className}</span>
              <span className="mt-1 block text-xs opacity-80">{item.status === "archived" ? "已封存" : `${item.studentCount} 人`}</span>
            </button>
          ))}
          {classes.length === 0 && <p className="text-sm text-muted-foreground">尚未有班別。</p>}
          <div className="flex gap-2">
            <Input value={className} onChange={(event) => setClassName(event.target.value)} placeholder="例如 1A" className="h-10" />
            <Button className="h-10" onClick={createClassRoom}>新增</Button>
          </div>
        </aside>
        <section className="rounded-3xl bg-white p-4 ring-1 ring-foreground/5">
          {room && (
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-display text-2xl">{room.className}</h2>
              <span className="text-sm text-muted-foreground">{room.schoolYear}</span>
              <Button variant="outline" className="h-9" onClick={archive}>{room.status === "archived" ? "恢復" : "封存"}</Button>
              <Button className="h-9" onClick={() => { setEditing(null); setForm({ ...emptyForm, classId }); setOpen(true); }}>新增學生</Button>
              <label className="inline-flex h-9 cursor-pointer items-center rounded-lg border px-3 text-sm">
                匯入 CSV / Excel
                <input type="file" accept=".csv,.xlsx,.xls" className="hidden" onChange={(event) => { const file = event.target.files?.[0]; if (file) void importFile(file); event.target.value = ""; }} />
              </label>
              <a className="text-sm text-primary underline" href="/samples/students.csv">下載範本</a>
            </div>
          )}
          <Input value={query} onChange={(event) => setQuery(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") void loadStudents(); }} placeholder="搜尋姓名、學號或登入名稱" className="mt-3 h-10" />
          <div className="mt-3 overflow-x-auto">
            <table className="w-full min-w-[720px] text-left text-sm">
              <thead className="text-muted-foreground">
                <tr>
                  <th className="py-2">缺席</th><th>學號</th><th>姓名</th><th>顯示名稱</th><th>登入</th><th>金幣</th><th></th>
                </tr>
              </thead>
              <tbody>
                {students.map((student) => (
                  <tr key={student.studentId} className="border-t">
                    <td className="py-2"><input type="checkbox" checked={student.absentToday} onChange={(event) => saveAbsence(student, event.target.checked)} aria-label={`${student.studentName} 今日缺席`} /></td>
                    <td>{student.classNumber}</td>
                    <td>{student.studentName}</td>
                    <td>{student.displayName}</td>
                    <td>{student.loginId}</td>
                    <td>{student.wallet.currentBalance}</td>
                    <td className="space-x-2 text-right">
                      <button type="button" className="text-primary" onClick={() => { setEditing(student); setForm({ studentName: student.studentName, displayName: student.displayName, classNumber: String(student.classNumber), enrollmentStatus: student.enrollmentStatus, classId: student.classId }); setOpen(true); }}>編輯</button>
                      <button type="button" className="text-primary" onClick={() => resetPassword(student)}>重設密碼</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {students.length === 0 && <p className="py-6 text-sm text-muted-foreground">這個班別還沒有學生。</p>}
          </div>
        </section>
      </div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editing ? "編輯學生" : "新增學生"}</DialogTitle>
            <DialogDescription>顯示名稱會用於投影抽籤，可改成暱稱。</DialogDescription>
          </DialogHeader>
          <Label>姓名</Label>
          <Input className="h-10" value={form.studentName} onChange={(event) => setForm({ ...form, studentName: event.target.value })} />
          <Label>顯示名稱</Label>
          <Input className="h-10" value={form.displayName} onChange={(event) => setForm({ ...form, displayName: event.target.value })} />
          <Label>學號</Label>
          <Input className="h-10" value={form.classNumber} onChange={(event) => setForm({ ...form, classNumber: event.target.value })} />
          {editing && (
            <>
              <Label>轉到班別</Label>
              <select className="h-10 rounded-lg border px-3" value={form.classId} onChange={(event) => setForm({ ...form, classId: event.target.value })}>
                {classes.filter((item) => item.status === "active").map((item) => <option key={item.classId} value={item.classId}>{item.className}</option>)}
              </select>
              <Label>狀態</Label>
              <select className="h-10 rounded-lg border px-3" value={form.enrollmentStatus} onChange={(event) => setForm({ ...form, enrollmentStatus: event.target.value })}>
                <option value="active">在學</option>
                <option value="withdrawn">退學</option>
              </select>
            </>
          )}
          <Button className="h-10" onClick={saveStudent}>儲存</Button>
        </DialogContent>
      </Dialog>
      <Dialog open={Boolean(imported)} onOpenChange={(value) => !value && setImported(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>匯入結果</DialogTitle>
            <DialogDescription>新帳戶的密碼只在這裡顯示一次。重複的班別加學號已被略過。</DialogDescription>
          </DialogHeader>
          <p className="text-sm">新增 {imported?.created.length ?? 0} 人，略過 {imported?.skipped.length ?? 0} 行，錯誤 {imported?.errors.length ?? 0} 行。</p>
          <div className="max-h-64 overflow-auto text-sm">
            {imported?.created.map((row) => (
              <p key={row.loginId}>{row.className} {row.classNumber} {row.studentName} · {row.loginId} · {row.temporaryPassword}</p>
            ))}
            {imported?.errors.map((row) => <p key={row.row} className="text-destructive">第 {row.row} 行：{row.reason}</p>)}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function readImport(file: File) {
  return new Promise<{ csv?: string; fileBase64?: string; filename?: string }>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("讀取檔案失敗"));
    if (file.name.toLowerCase().endsWith(".csv")) {
      reader.onload = () => resolve({ csv: String(reader.result ?? "") });
      reader.readAsText(file);
      return;
    }
    reader.onload = () => {
      const text = String(reader.result ?? "");
      resolve({ fileBase64: text.split(",")[1] ?? "", filename: file.name });
    };
    reader.readAsDataURL(file);
  });
}
