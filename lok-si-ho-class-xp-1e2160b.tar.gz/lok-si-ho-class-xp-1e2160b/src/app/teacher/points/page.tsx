"use client";

import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { ApiError, api, formatWhen, idempotencyKey } from "@/lib/api";

interface ClassRoom { classId: string; className: string; status: string }
interface StudentRow {
  studentId: string;
  classNumber: number;
  studentName: string;
  enrollmentStatus: string;
  wallet: { currentBalance: number; lifetimeEarned: number; lifetimeSpent: number };
}
interface Tx { transactionId: string; amount: number; type: string; reason: string; createdAt: string }

export default function PointsPage() {
  const [classes, setClasses] = useState<ClassRoom[]>([]);
  const [classId, setClassId] = useState("");
  const [rows, setRows] = useState<StudentRow[]>([]);
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<"number" | "balance" | "earned">("number");
  const [selected, setSelected] = useState<string[]>([]);
  const [open, setOpen] = useState<"earn" | "adjust" | null>(null);
  const [amount, setAmount] = useState("1");
  const [reason, setReason] = useState("課堂表現");
  const [detail, setDetail] = useState<{ name: string; rows: Tx[] } | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<ClassRoom[]>("classes").then((list) => {
      const active = list.filter((item) => item.status === "active");
      setClasses(active);
      setClassId(active[0]?.classId ?? "");
    }).catch((reason) => setError(reason instanceof ApiError ? reason.message : "未能載入"));
  }, []);

  useEffect(() => {
    if (!classId) return;
    api<StudentRow[]>(`points?classId=${classId}`).then(setRows).catch((reason) => setError(reason instanceof ApiError ? reason.message : "未能載入積分"));
    setSelected([]);
  }, [classId]);

  const visible = useMemo(() => {
    const filtered = rows.filter((row) => `${row.classNumber}${row.studentName}`.includes(query.trim()));
    return [...filtered].sort((a, b) => {
      if (sort === "balance") return b.wallet.currentBalance - a.wallet.currentBalance;
      if (sort === "earned") return b.wallet.lifetimeEarned - a.wallet.lifetimeEarned;
      return a.classNumber - b.classNumber;
    });
  }, [rows, query, sort]);

  async function submit() {
    const ids = selected.length ? selected : visible.filter((row) => row.enrollmentStatus === "active").map((row) => row.studentId);
    try {
      await api("points/award", {
        method: "POST",
        body: {
          studentIds: ids,
          amount: open === "adjust" ? -Math.abs(Number(amount)) : Number(amount),
          reason,
          mode: open,
          idempotencyKey: idempotencyKey("points"),
        },
      });
      toast.success(open === "adjust" ? "已記錄扣除" : "已發放寵物金幣");
      setOpen(null);
      const next = await api<StudentRow[]>(`points?classId=${classId}`);
      setRows(next);
    } catch (reason) {
      toast.error(reason instanceof ApiError ? reason.message : "未能更新積分");
    }
  }

  async function showDetail(row: StudentRow) {
    const txs = await api<Tx[]>(`points/transactions?studentId=${row.studentId}`);
    setDetail({ name: row.studentName, rows: txs });
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-semibold">積分管理</h1>
          <p className="text-sm text-muted-foreground">排行用累積獲得計算。扣除會留下修正紀錄，餘額不可低於 0。</p>
        </div>
        <a className="text-sm text-primary underline" href={`/api/cpq/export?kind=points&format=csv&classId=${classId}`}>匯出 CSV</a>
      </div>
      {error && <p className="rounded-2xl bg-destructive/10 px-4 py-3 text-sm text-destructive">{error}</p>}
      <div className="flex flex-wrap gap-2">
        <select className="h-10 rounded-xl border bg-white px-3" value={classId} onChange={(event) => setClassId(event.target.value)}>
          {classes.map((room) => <option key={room.classId} value={room.classId}>{room.className}</option>)}
        </select>
        <Input className="h-10 max-w-xs" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜尋學生" />
        <Button variant="outline" className="h-10" onClick={() => setSort(sort === "number" ? "balance" : sort === "balance" ? "earned" : "number")}>
          排序：{sort === "number" ? "學號" : sort === "balance" ? "可用金幣" : "累積獲得"}
        </Button>
        <Button className="h-10" onClick={() => { setOpen("earn"); setReason("課堂表現"); }}>發放金幣</Button>
        <Button variant="secondary" className="h-10" onClick={() => { setOpen("adjust"); setReason("誤加積分，修正"); }}>扣除金幣</Button>
        <Button variant="outline" className="h-10" onClick={() => setSelected(visible.map((row) => row.studentId))}>全選此名單</Button>
      </div>
      <div className="overflow-x-auto rounded-3xl bg-white ring-1 ring-foreground/5">
        <table className="w-full min-w-[680px] text-left text-sm">
          <thead className="text-muted-foreground"><tr><th className="p-3"></th><th>學號</th><th>學生姓名</th><th>可用金幣</th><th>累積獲得</th><th>已花費</th><th></th></tr></thead>
          <tbody>
            {visible.map((row) => (
              <tr key={row.studentId} className="border-t">
                <td className="p-3"><input type="checkbox" checked={selected.includes(row.studentId)} onChange={(event) => setSelected((current) => event.target.checked ? [...current, row.studentId] : current.filter((id) => id !== row.studentId))} /></td>
                <td>{row.classNumber}</td>
                <td>{row.studentName}{row.enrollmentStatus === "withdrawn" ? "（退學）" : ""}</td>
                <td>{row.wallet.currentBalance}</td>
                <td>{row.wallet.lifetimeEarned}</td>
                <td>{row.wallet.lifetimeSpent}</td>
                <td><button type="button" className="text-primary" onClick={() => showDetail(row)}>紀錄</button></td>
              </tr>
            ))}
          </tbody>
        </table>
        {visible.length === 0 && <p className="p-6 text-sm text-muted-foreground">沒有符合的學生。</p>}
      </div>
      <Dialog open={open !== null} onOpenChange={(value) => !value && setOpen(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{open === "adjust" ? "扣除寵物金幣" : "發放寵物金幣"}</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">{selected.length ? `已選 ${selected.length} 人` : "未有勾選時會套用到目前名單的在學學生"}</p>
          <Input className="h-10" value={amount} onChange={(event) => setAmount(event.target.value)} inputMode="numeric" />
          <Input className="h-10" value={reason} onChange={(event) => setReason(event.target.value)} />
          <Button className="h-10" onClick={submit}>確認</Button>
        </DialogContent>
      </Dialog>
      <Dialog open={Boolean(detail)} onOpenChange={(value) => !value && setDetail(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>{detail?.name} 的積分紀錄</DialogTitle></DialogHeader>
          <div className="max-h-80 space-y-2 overflow-auto text-sm">
            {detail?.rows.length === 0 && <p className="text-muted-foreground">尚未有紀錄。</p>}
            {detail?.rows.map((row) => (
              <p key={row.transactionId}>{formatWhen(row.createdAt)} · {row.amount > 0 ? `+${row.amount}` : row.amount} · {row.reason}</p>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
