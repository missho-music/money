"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ApiError, api } from "@/lib/api";

interface Rule { id: string; label: string; points: number }
interface Settings {
  schoolYear: string;
  expPerCoin: number;
  levelBaseExp: number;
  levelGrowth: number;
  pointRules: Rule[];
  fastDraw: boolean;
  leaderboardEnabled: boolean;
  leaderboardUseNickname: boolean;
  projectionShowsFullName: boolean;
  demoMode: boolean;
}
interface Teacher { uid: string; displayName: string; loginId: string; authorizedClassIds: string[] }

export default function SettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [teacherForm, setTeacherForm] = useState({ displayName: "", loginId: "", password: "" });
  const [passwords, setPasswords] = useState({ currentPassword: "", nextPassword: "" });
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([api<Settings>("settings"), api<Teacher[]>("teachers")])
      .then(([next, people]) => { setSettings(next); setTeachers(people); })
      .catch((reason) => setError(reason instanceof ApiError ? reason.message : "未能載入設定"));
  }, []);

  async function save() {
    if (!settings) return;
    try {
      setSettings(await api<Settings>("settings", { method: "PATCH", body: settings }));
      toast.success("設定已儲存");
    } catch (reason) {
      toast.error(reason instanceof ApiError ? reason.message : "未能儲存設定");
    }
  }

  async function addTeacher() {
    try {
      await api("teachers", { method: "POST", body: { ...teacherForm, authorizedClassIds: [] } });
      setTeachers(await api<Teacher[]>("teachers"));
      setTeacherForm({ displayName: "", loginId: "", password: "" });
      toast.success("已新增教師。空白授權代表可管理所有班別。");
    } catch (reason) {
      toast.error(reason instanceof ApiError ? reason.message : "未能新增教師");
    }
  }

  async function changePassword() {
    try {
      await api("auth/password", { method: "POST", body: passwords });
      setPasswords({ currentPassword: "", nextPassword: "" });
      toast.success("密碼已更新");
    } catch (reason) {
      toast.error(reason instanceof ApiError ? reason.message : "未能更新密碼");
    }
  }

  if (!settings) return <p className="text-sm text-muted-foreground">{error ?? "正在載入設定…"}</p>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold">設定</h1>
        <p className="text-sm text-muted-foreground">積分規則和升級曲線可以改。完整寵物對戰仍未開放，不能在這裡打開。</p>
      </div>
      <section className="space-y-3 rounded-3xl bg-white p-5 ring-1 ring-foreground/5">
        <h2 className="font-medium">學年與經驗</h2>
        <Input className="h-10" value={settings.schoolYear} onChange={(event) => setSettings({ ...settings, schoolYear: event.target.value })} />
        <div className="grid gap-2 md:grid-cols-3">
          <Field label="每枚金幣經驗" value={settings.expPerCoin} onChange={(value) => setSettings({ ...settings, expPerCoin: value })} />
          <Field label="1 級升級所需" value={settings.levelBaseExp} onChange={(value) => setSettings({ ...settings, levelBaseExp: value })} />
          <Field label="其後倍率" value={settings.levelGrowth} onChange={(value) => setSettings({ ...settings, levelGrowth: value })} step="0.05" />
        </div>
        <h2 className="pt-2 font-medium">抽籤加分按鈕</h2>
        {settings.pointRules.map((rule, index) => (
          <div key={rule.id} className="grid grid-cols-[1fr_90px] gap-2">
            <Input className="h-10" value={rule.label} onChange={(event) => {
              const pointRules = settings.pointRules.slice();
              pointRules[index] = { ...rule, label: event.target.value };
              setSettings({ ...settings, pointRules });
            }} />
            <Input className="h-10" type="number" value={rule.points} onChange={(event) => {
              const pointRules = settings.pointRules.slice();
              pointRules[index] = { ...rule, points: Number(event.target.value) };
              setSettings({ ...settings, pointRules });
            }} />
          </div>
        ))}
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={settings.fastDraw} onChange={(event) => setSettings({ ...settings, fastDraw: event.target.checked })} />預設使用快速抽籤</label>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={settings.projectionShowsFullName} onChange={(event) => setSettings({ ...settings, projectionShowsFullName: event.target.checked })} />投影顯示全名</label>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={settings.leaderboardEnabled} onChange={(event) => setSettings({ ...settings, leaderboardEnabled: event.target.checked })} />學生可看本班排行榜</label>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={settings.leaderboardUseNickname} onChange={(event) => setSettings({ ...settings, leaderboardUseNickname: event.target.checked })} />排行榜向學生顯示暱稱</label>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={settings.demoMode} onChange={(event) => setSettings({ ...settings, demoMode: event.target.checked })} />顯示示範帳號</label>
        <Button className="h-10" onClick={save}>儲存設定</Button>
      </section>
      <section className="rounded-3xl bg-white p-5 ring-1 ring-foreground/5">
        <h2 className="font-medium">其他教師</h2>
        <p className="mt-1 text-sm text-muted-foreground">新教師目前可管理所有班別。日後可把 authorizedClassIds 收窄到指定班。</p>
        <div className="mt-3 space-y-1 text-sm">{teachers.map((teacher) => <p key={teacher.uid}>{teacher.displayName} · {teacher.loginId}</p>)}</div>
        <div className="mt-3 grid gap-2 md:grid-cols-3">
          <Input className="h-10" placeholder="名稱" value={teacherForm.displayName} onChange={(event) => setTeacherForm({ ...teacherForm, displayName: event.target.value })} />
          <Input className="h-10" placeholder="登入電郵" value={teacherForm.loginId} onChange={(event) => setTeacherForm({ ...teacherForm, loginId: event.target.value })} />
          <Input className="h-10" placeholder="密碼" value={teacherForm.password} onChange={(event) => setTeacherForm({ ...teacherForm, password: event.target.value })} />
        </div>
        <Button className="mt-3 h-10" variant="secondary" onClick={addTeacher}>新增教師</Button>
      </section>
      <section className="rounded-3xl bg-white p-5 ring-1 ring-foreground/5">
        <h2 className="font-medium">更改我的密碼</h2>
        <div className="mt-3 grid gap-2 md:grid-cols-2">
          <Input className="h-10" type="password" placeholder="目前密碼" value={passwords.currentPassword} onChange={(event) => setPasswords({ ...passwords, currentPassword: event.target.value })} />
          <Input className="h-10" type="password" placeholder="新密碼" value={passwords.nextPassword} onChange={(event) => setPasswords({ ...passwords, nextPassword: event.target.value })} />
        </div>
        <Button className="mt-3 h-10" variant="outline" onClick={changePassword}>更新密碼</Button>
      </section>
      <section className="rounded-3xl bg-muted p-5 text-sm leading-6">
        <h2 className="font-medium">個人資料使用提示</h2>
        <p className="mt-2">系統收集姓名、班別、學號、登入名稱、積分、寵物和兌換紀錄，只用來做課堂抽籤和獎勵。學生只能看自己的積分、背包和訂單；排行榜可關閉或改為暱稱。投影預設使用顯示名稱。</p>
        <p className="mt-2">學年結束可封存班別，並在報表頁下載不含密碼的備份。退學學生會離開抽籤名單，但紀錄仍在。請按香港《個人資料（私隱）條例》和校方政策決定保留期，不要把備份放到公開位置。</p>
      </section>
    </div>
  );
}

function Field({ label, value, onChange, step }: { label: string; value: number; onChange: (value: number) => void; step?: string }) {
  return (
    <label className="text-sm">
      {label}
      <Input className="mt-1 h-10" type="number" step={step} value={value} onChange={(event) => onChange(Number(event.target.value))} />
    </label>
  );
}
