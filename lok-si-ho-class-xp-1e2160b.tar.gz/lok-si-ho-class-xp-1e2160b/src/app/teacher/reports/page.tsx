"use client";

import { useEffect, useState } from "react";
import { ApiError, api, formatWhen } from "@/lib/api";

interface Report {
  classRows: { classId: string; className: string; studentCount: number; drawCount: number; drawnThisRound: number; lifetimeEarned: number; averagePetLevel: number; absentToday: number }[];
  rarelyDrawn: { studentId: string; className: string; classNumber: number; studentName: string; drawCount: number; lastDrawAt: string | null }[];
  coinsByDay: { date: string; amount: number }[];
  popularItems: { name: string; count: number }[];
}

export default function ReportsPage() {
  const [report, setReport] = useState<Report | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    api<Report>("reports").then(setReport).catch((reason) => setError(reason instanceof ApiError ? reason.message : "未能載入報表"));
  }, []);
  const maxCoins = Math.max(1, ...(report?.coinsByDay.map((day) => day.amount) ?? [1]));
  const maxDraw = Math.max(1, ...(report?.classRows.map((row) => row.drawCount) ?? [1]));

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-semibold">報表</h1>
          <p className="text-sm text-muted-foreground">以下全部由抽籤、積分和訂單計算，沒有寫死的數字。</p>
        </div>
        <div className="flex gap-3 text-sm">
          <a className="text-primary underline" href="/api/cpq/export?kind=draws&format=csv">匯出抽籤 CSV</a>
          <a className="text-primary underline" href="/api/cpq/export?kind=points&format=xlsx">匯出積分 Excel</a>
          <a className="text-primary underline" href="/api/cpq/export?kind=backup&format=json">下載備份</a>
        </div>
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}
      {!report && !error && <p className="text-sm text-muted-foreground">正在計算…</p>}
      <section className="rounded-3xl bg-white p-5 ring-1 ring-foreground/5">
        <h2 className="font-medium">近 14 日發出的寵物金幣</h2>
        <div className="mt-4 flex h-36 items-end gap-1">
          {report?.coinsByDay.map((day) => (
            <div key={day.date} className="flex flex-1 flex-col items-center gap-1">
              <div className="w-full rounded-t-md bg-primary" style={{ height: `${(day.amount / maxCoins) * 100}%`, minHeight: day.amount ? 4 : 0 }} />
              <span className="text-[10px] text-muted-foreground">{day.date.slice(5)}</span>
            </div>
          ))}
        </div>
      </section>
      <section className="grid gap-4 lg:grid-cols-2">
        <article className="rounded-3xl bg-white p-5 ring-1 ring-foreground/5">
          <h2 className="font-medium">各班抽籤次數</h2>
          <div className="mt-3 space-y-3">
            {report?.classRows.map((row) => (
              <div key={row.classId}>
                <div className="flex justify-between text-sm"><span>{row.className}</span><span>{row.drawCount} 次 · 平均等級 {row.averagePetLevel}</span></div>
                <div className="mt-1 h-2 rounded-full bg-muted"><div className="h-2 rounded-full bg-secondary-foreground" style={{ width: `${(row.drawCount / maxDraw) * 100}%` }} /></div>
                <p className="text-xs text-muted-foreground">本輪 {row.drawnThisRound}/{row.studentCount} · 今日缺席 {row.absentToday} · 累積金幣 {row.lifetimeEarned}</p>
              </div>
            ))}
          </div>
        </article>
        <article className="rounded-3xl bg-white p-5 ring-1 ring-foreground/5">
          <h2 className="font-medium">較少被抽中的學生</h2>
          <div className="mt-3 space-y-2 text-sm">
            {report?.rarelyDrawn.map((row) => (
              <p key={row.studentId}>{row.className} {row.classNumber} {row.studentName} · {row.drawCount} 次 · 上次 {formatWhen(row.lastDrawAt)}</p>
            ))}
          </div>
          <h2 className="mt-6 font-medium">最多人購買的商品</h2>
          <div className="mt-3 space-y-2 text-sm">
            {report?.popularItems.length === 0 && <p className="text-muted-foreground">還沒有購買紀錄。</p>}
            {report?.popularItems.map((item) => <p key={item.name}>{item.name} · {item.count} 次</p>)}
          </div>
        </article>
      </section>
    </div>
  );
}
