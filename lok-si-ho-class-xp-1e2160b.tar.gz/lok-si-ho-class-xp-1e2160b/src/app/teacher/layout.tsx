import { redirect } from "next/navigation";
import { TeacherShell } from "@/components/teacher-shell";
import { getActor } from "@/server/session";

export default async function TeacherLayout({ children }: { children: React.ReactNode }) {
  const actor = await getActor();
  if (!actor) redirect("/login");
  if (actor.role !== "teacher") redirect("/student");
  return <TeacherShell actor={actor}>{children}</TeacherShell>;
}
