"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ApiError, api } from "@/lib/api";

interface DemoAccount {
  role: string;
  label: string;
  loginId: string;
  password: string;
}

export default function LoginPage() {
  const router = useRouter();
  const [loginId, setLoginId] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [accounts, setAccounts] = useState<DemoAccount[]>([]);
  const [backend, setBackend] = useState("sqlite");

  useEffect(() => {
    api<{ demoMode: boolean; backend: string; accounts: DemoAccount[] }>("demo")
      .then((data) => {
        setAccounts(data.accounts);
        setBackend(data.backend);
      })
      .catch(() => undefined);
  }, []);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    try {
      const result = await api<{ actor: { role: string } }>("auth/login", {
        method: "POST",
        body: { loginId, password },
      });
      router.push(result.actor.role === "teacher" ? "/teacher" : "/student");
      router.refresh();
    } catch (error) {
      toast.error(error instanceof ApiError ? error.message : "登入失敗");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-5 py-10">
      <p className="font-display text-sm text-primary">Classroom Pet Quest</p>
      <h1 className="font-display mt-2 text-3xl font-semibold">登入課堂</h1>
      <p className="mt-2 text-sm leading-6 text-muted-foreground">
        請使用教師電郵或學生登入名稱加密碼。只輸入學號不能進入帳戶。
      </p>
      <form onSubmit={submit} className="mt-6 space-y-4 rounded-3xl bg-white p-5 ring-1 ring-foreground/5">
        <div className="space-y-2">
          <Label htmlFor="loginId">登入名稱</Label>
          <Input id="loginId" value={loginId} onChange={(event) => setLoginId(event.target.value)} autoComplete="username" className="h-11" required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="password">密碼</Label>
          <Input id="password" type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete="current-password" className="h-11" required />
        </div>
        <Button type="submit" disabled={busy} className="h-11 w-full">
          {busy ? "正在登入…" : "登入"}
        </Button>
      </form>
      {accounts.length > 0 && (
        <div className="mt-4 rounded-3xl bg-accent/60 p-4 text-sm">
          <p className="font-medium">示範帳號</p>
          <p className="mt-1 text-muted-foreground">
            目前使用{backend === "firestore" ? " Firestore" : "本機資料庫"}。正式上課前請在設定關閉示範模式並重設密碼。
          </p>
          <div className="mt-3 flex flex-col gap-2">
            {accounts.map((account) => (
              <button
                key={account.loginId}
                type="button"
                className="rounded-2xl bg-white px-3 py-2 text-left"
                onClick={() => {
                  setLoginId(account.loginId);
                  setPassword(account.password);
                }}
              >
                {account.label} · {account.loginId}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
