export const C = {
  users: "users",
  classes: "classes",
  students: "students",
  wallets: "wallets",
  pointTransactions: "pointTransactions",
  drawSessions: "drawSessions",
  drawHistory: "drawHistory",
  pets: "pets",
  items: "items",
  rewards: "rewards",
  inventories: "inventories",
  orders: "orders",
  settings: "settings",
  absences: "absences",
  idempotency: "idempotency",
  seats: "seats",
  loginIndex: "loginIndex",
} as const;

export type CollectionName = (typeof C)[keyof typeof C];

export const SETTINGS_ID = "app";

export function seatKey(classId: string, classNumber: number) {
  return `${classId}_${classNumber}`;
}

export function absenceKey(classId: string, date: string) {
  return `${classId}_${date}`;
}

export function loginKey(loginId: string) {
  return loginId.trim().toLowerCase();
}
