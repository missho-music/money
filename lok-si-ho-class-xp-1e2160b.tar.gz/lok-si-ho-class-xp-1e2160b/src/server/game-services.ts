import {
  CATEGORY_LABEL,
  PET_CATALOG,
  PET_TYPES,
  RARITY_LABEL,
  SLOT_LABEL,
  combatFrom,
  progressFromExp,
  slotForCategory,
  normalizeStats,
} from "./catalog";
import { C, SETTINGS_ID, absenceKey } from "./collections";
import { AppError } from "./errors";
import { newId, nowIso, randomIntBelow, temporaryPassword } from "./ids";
import { parseStudentTable, toCsv, toXlsx } from "./importers";
import type { Database, Repo } from "./repo";
import {
  addStudent,
  assertTeacher,
  cached,
  createClass,
  deduct,
  earn,
  emptyWallet,
  idempotencyKey,
  integer,
  listClasses,
  listStudents,
  optionalText,
  ownStudentId,
  petDocId,
  refundCoins,
  remember,
  requireClass,
  resultLabel,
  settingsOf,
  spend,
  syncLevel,
  text,
  tx,
} from "./services";
import { hkDateString, hkMonthKey, hkWeekStart, inRange } from "./time";
import type {
  Absence,
  Actor,
  ClassRoom,
  DrawRecord,
  DrawSession,
  InventoryItem,
  Item,
  ItemCategory,
  Order,
  Pet,
  PetType,
  PointRule,
  PointTransaction,
  Rarity,
  Reward,
  Settings,
  Stats,
  Student,
  Wallet,
} from "./types";
import { EMPTY_EQUIPPED } from "./types";

const SLOTS = ["weapon", "armor", "headgear", "accessory", "appearance"] as const;
const RARITIES = new Set<Rarity>(["common", "rare", "epic", "legendary"]);
const CATEGORIES = new Set<ItemCategory>([
  "weapon",
  "armor",
  "headgear",
  "accessory",
  "consumable",
  "cosmetic",
]);

function presentItem(item: Item) {
  return {
    ...item,
    categoryLabel: CATEGORY_LABEL[item.category],
    rarityLabel: RARITY_LABEL[item.rarity] ?? item.rarity,
    slotLabel: item.slot ? SLOT_LABEL[item.slot] : null,
  };
}

async function activeStudents(repo: Repo, classId: string) {
  return (await repo.list<Student>(C.students)).filter(
    (student) => student.classId === classId && student.enrollmentStatus === "active",
  );
}

function latestSession(sessions: DrawSession[]) {
  return [...sessions].sort((a, b) => b.roundNumber - a.roundNumber)[0] ?? null;
}

export async function resetStudentPassword(db: Database, actor: Actor, studentId: string) {
  assertTeacher(actor);
  const student = await db.read((repo) => repo.get<Student>(C.students, studentId));
  if (!student?.userId) throw new AppError(404, "找不到學生帳戶。", "STUDENT");
  assertTeacher(actor, student.classId);
  const password = temporaryPassword();
  const user = await db.read(async (repo) => {
    const record = await repo.get<import("./types").UserRecord>(C.users, student.userId!);
    if (!record) throw new AppError(404, "找不到學生帳戶。", "STUDENT");
    return record;
  });
  await db.provisionLogin(user, password);
  await db.withTransaction(async (repo) => {
    await repo.set(C.users, user.uid, user);
  });
  return { loginId: user.loginId, temporaryPassword: password, studentName: student.studentName };
}

export async function importStudents(
  db: Database,
  actor: Actor,
  input: { csv?: string; fileBase64?: string; filename?: string; createMissingClasses?: boolean },
) {
  assertTeacher(actor);
  const rows = parseStudentTable(input);
  const settings = await db.read(settingsOf);
  const created: {
    row: number;
    studentName: string;
    className: string;
    classNumber: number;
    loginId: string;
    temporaryPassword: string;
  }[] = [];
  const skipped: { row: number; reason: string }[] = [];
  const errors: { row: number; reason: string }[] = [];
  const seen = new Set<string>();
  for (const row of rows) {
    const key = `${row.className.toLowerCase()}#${row.classNumber}`;
    if (seen.has(key)) {
      skipped.push({ row: row.rowNumber, reason: "檔案內班別及學號重複" });
      continue;
    }
    seen.add(key);
    try {
      const classes = await db.read((repo) => repo.list<ClassRoom>(C.classes));
      let room = classes.find(
        (item) =>
          item.status === "active" &&
          item.schoolYear === settings.schoolYear &&
          item.className.toLowerCase() === row.className.toLowerCase(),
      );
      if (!room) {
        if (input.createMissingClasses === false) {
          errors.push({ row: row.rowNumber, reason: `找不到班別 ${row.className}` });
          continue;
        }
        room = await createClass(db, actor, { className: row.className, schoolYear: settings.schoolYear });
      }
      assertTeacher(actor, room.classId);
      const seatTaken = await db.read((repo) =>
        repo.get(C.seats, `${room!.classId}_${row.classNumber}`),
      );
      if (seatTaken) {
        skipped.push({ row: row.rowNumber, reason: "此學號已有學生，已略過以免重複開戶" });
        continue;
      }
      const result = await addStudent(db, actor, {
        classId: room.classId,
        classNumber: row.classNumber,
        studentName: row.studentName,
        displayName: row.displayName,
      });
      created.push({
        row: row.rowNumber,
        studentName: row.studentName,
        className: room.className,
        classNumber: row.classNumber,
        loginId: result.loginId,
        temporaryPassword: result.temporaryPassword,
      });
    } catch (error) {
      if (error instanceof AppError && (error.code === "DUPLICATE_SEAT" || error.code === "DUPLICATE_LOGIN")) {
        skipped.push({ row: row.rowNumber, reason: error.message });
        continue;
      }
      if (error instanceof AppError) {
        errors.push({ row: row.rowNumber, reason: error.message });
        continue;
      }
      throw error;
    }
  }
  return { created, skipped, errors };
}

export async function getAbsences(db: Database, actor: Actor, classId: string, date?: string | null) {
  assertTeacher(actor, classId);
  const day = date || hkDateString();
  const absence = await db.read((repo) => repo.get<Absence>(C.absences, absenceKey(classId, day)));
  return { classId, date: day, studentIds: absence?.studentIds ?? [] };
}

export async function setAbsences(
  db: Database,
  actor: Actor,
  input: { classId: unknown; studentIds: unknown; date?: unknown },
) {
  const classId = text(input.classId, "班別", 80);
  assertTeacher(actor, classId);
  if (!Array.isArray(input.studentIds)) throw new AppError(400, "缺席名單不正確。", "VALIDATION");
  const day = input.date ? text(input.date, "日期", 10) : hkDateString();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) throw new AppError(400, "日期不正確。", "VALIDATION");
  const studentIds = [...new Set(input.studentIds.map((id) => text(id, "學生", 80)))];
  return db.withTransaction(async (repo) => {
    await requireClass(repo, classId);
    const allowed = new Set((await activeStudents(repo, classId)).map((student) => student.studentId));
    if (studentIds.some((id) => !allowed.has(id))) {
      throw new AppError(400, "缺席名單包含不屬於此班的在學學生。", "VALIDATION");
    }
    const absence: Absence = { classId, date: day, studentIds };
    await repo.set(C.absences, absenceKey(classId, day), absence);
    return absence;
  });
}

async function buildDrawState(repo: Repo, classId: string) {
  const room = await requireClass(repo, classId);
  const settings = await settingsOf(repo);
  const students = await activeStudents(repo, classId);
  const absence = await repo.get<Absence>(C.absences, absenceKey(classId, hkDateString()));
  const absent = new Set(absence?.studentIds ?? []);
  const sessions = (await repo.list<DrawSession>(C.drawSessions)).filter((session) => session.classId === classId);
  const active = sessions.find((session) => session.status === "active") ?? null;
  const session = active ?? latestSession(sessions);
  const drawn = new Set(session && session.status !== "completed" ? session.drawnStudentIds : []);
  const completed = session?.status === "completed";
  const roster = students
    .map((student) => {
      let state: "drawn" | "absent" | "remaining" = "remaining";
      if (completed) state = "drawn";
      else if (drawn.has(student.studentId)) state = "drawn";
      else if (absent.has(student.studentId)) state = "absent";
      return {
        studentId: student.studentId,
        classNumber: student.classNumber,
        studentName: student.studentName,
        displayName: student.displayName,
        state,
      };
    })
    .sort((a, b) => a.classNumber - b.classNumber);
  return {
    classId,
    className: room.className,
    archived: room.status === "archived",
    roundNumber: session?.roundNumber ?? 0,
    roundStatus: session ? session.status : "ready",
    totalActive: students.length,
    drawnCount: roster.filter((student) => student.state === "drawn").length,
    remainingCount: roster.filter((student) => student.state === "remaining").length,
    absentCount: roster.filter((student) => student.state === "absent").length,
    roster,
    fastDraw: settings.fastDraw,
    projectionShowsFullName: settings.projectionShowsFullName,
    pointRules: settings.pointRules,
  };
}

export async function getDrawState(db: Database, actor: Actor, classId: string) {
  assertTeacher(actor, classId);
  return db.read((repo) => buildDrawState(repo, classId));
}

export async function performDraw(
  db: Database,
  actor: Actor,
  input: { classId: unknown; idempotencyKey: unknown },
) {
  const classId = text(input.classId, "班別", 80);
  assertTeacher(actor, classId);
  const key = idempotencyKey(input.idempotencyKey);
  return db.withTransaction(async (repo) => {
    const prior = await cached<Record<string, unknown>>(repo, key);
    if (prior) return prior;
    const room = await requireClass(repo, classId);
    if (room.status !== "active") throw new AppError(400, "班別已封存，不能抽籤。", "CLASS");
    const students = await activeStudents(repo, classId);
    if (!students.length) throw new AppError(400, "此班沒有在學學生。", "EMPTY_CLASS");
    const absence = await repo.get<Absence>(C.absences, absenceKey(classId, hkDateString()));
    const absent = new Set(absence?.studentIds ?? []);
    const sessions = (await repo.list<DrawSession>(C.drawSessions)).filter((session) => session.classId === classId);
    let session = sessions.find((item) => item.status === "active") ?? null;
    const latest = latestSession(sessions);
    if (!session && latest?.status === "completed") {
      const payload = {
        status: "round_complete" as const,
        roundNumber: latest.roundNumber,
        drawnCount: latest.drawnStudentIds.length,
        total: students.length,
        message: "本輪抽籤已完成！請確認後開始新一輪。",
      };
      await remember(repo, key, payload);
      return payload;
    }
    if (!session) {
      session = {
        sessionId: newId("ses"),
        classId,
        roundNumber: (latest?.roundNumber ?? 0) + 1,
        drawnStudentIds: [],
        status: "active",
        startedAt: nowIso(),
        completedAt: null,
      };
    }
    const drawn = new Set(session.drawnStudentIds);
    const pool = students.filter((student) => !drawn.has(student.studentId) && !absent.has(student.studentId));
    if (!pool.length) {
      const held = students.filter((student) => !drawn.has(student.studentId));
      if (!held.length) {
        session.status = "completed";
        session.completedAt = nowIso();
        await repo.set(C.drawSessions, session.sessionId, session);
        const payload = {
          status: "round_complete" as const,
          roundNumber: session.roundNumber,
          drawnCount: session.drawnStudentIds.length,
          total: students.length,
          message: "本輪抽籤已完成！請確認後開始新一輪。",
        };
        await remember(repo, key, payload);
        return payload;
      }
      throw new AppError(
        409,
        `今日沒有可抽的學生。${held.length} 位缺席同學仍保留本輪機會。`,
        "NO_ELIGIBLE",
        { absentCount: held.length },
      );
    }
    const picked = pool[randomIntBelow(pool.length)];
    const draw: DrawRecord = {
      drawId: newId("draw"),
      sessionId: session.sessionId,
      classId,
      studentId: picked.studentId,
      roundNumber: session.roundNumber,
      result: "selected",
      timestamp: nowIso(),
      createdBy: actor.uid,
      awards: {},
    };
    session.drawnStudentIds = [...session.drawnStudentIds, picked.studentId];
    const roundComplete = students.every((student) => session!.drawnStudentIds.includes(student.studentId));
    if (roundComplete) {
      session.status = "completed";
      session.completedAt = nowIso();
    }
    await repo.set(C.drawSessions, session.sessionId, session);
    await repo.set(C.drawHistory, draw.drawId, draw);
    const payload = {
      status: "selected" as const,
      draw,
      student: {
        studentId: picked.studentId,
        classNumber: picked.classNumber,
        studentName: picked.studentName,
        displayName: picked.displayName,
        className: room.className,
      },
      roundNumber: session.roundNumber,
      drawnCount: session.drawnStudentIds.length,
      total: students.length,
      absentCount: [...absent].filter((id) => students.some((student) => student.studentId === id)).length,
      roundComplete,
      message: roundComplete ? "本輪最後一位同學已抽出。" : null,
    };
    await remember(repo, key, payload);
    return payload;
  });
}

export async function resolveDraw(
  db: Database,
  actor: Actor,
  input: { drawId: unknown; action: unknown },
) {
  assertTeacher(actor);
  const drawId = text(input.drawId, "抽籤", 80);
  if (input.action !== "return" && input.action !== "mark") {
    throw new AppError(400, "請選擇稍後再抽，或標記為已抽中。", "VALIDATION");
  }
  const action = input.action;
  return db.withTransaction(async (repo) => {
    const draw = await repo.get<DrawRecord>(C.drawHistory, drawId);
    if (!draw) throw new AppError(404, "找不到抽籤紀錄。", "DRAW");
    assertTeacher(actor, draw.classId);
    if (draw.result !== "selected") throw new AppError(409, "此抽籤結果已經處理。", "DRAW_RESOLVED");
    const session = await repo.get<DrawSession>(C.drawSessions, draw.sessionId);
    if (!session) throw new AppError(404, "找不到抽籤輪次。", "DRAW");
    if (action === "return") {
      draw.result = "returned";
      session.drawnStudentIds = session.drawnStudentIds.filter((id) => id !== draw.studentId);
      if (session.status === "completed") {
        session.status = "active";
        session.completedAt = null;
      }
    } else {
      draw.result = "marked";
      if (!session.drawnStudentIds.includes(draw.studentId)) {
        session.drawnStudentIds = [...session.drawnStudentIds, draw.studentId];
      }
    }
    await repo.set(C.drawHistory, draw.drawId, draw);
    await repo.set(C.drawSessions, session.sessionId, session);
    return { draw, resultLabel: resultLabel(draw.result) };
  });
}

export async function resetRound(
  db: Database,
  actor: Actor,
  input: { classId: unknown; confirm: unknown; idempotencyKey: unknown },
) {
  const classId = text(input.classId, "班別", 80);
  assertTeacher(actor, classId);
  if (input.confirm !== true) throw new AppError(400, "請再次確認才可開始新一輪。", "CONFIRM");
  const key = idempotencyKey(input.idempotencyKey);
  return db.withTransaction(async (repo) => {
    const prior = await cached<Record<string, unknown>>(repo, key);
    if (prior) return prior;
    const room = await requireClass(repo, classId);
    const sessions = (await repo.list<DrawSession>(C.drawSessions)).filter((session) => session.classId === classId);
    const active = sessions.find((session) => session.status === "active") ?? null;
    const latest = latestSession(sessions);
    if (active) {
      active.status = "completed";
      active.completedAt = nowIso();
      await repo.set(C.drawSessions, active.sessionId, active);
    }
    const next: DrawSession = {
      sessionId: newId("ses"),
      classId,
      roundNumber: (latest?.roundNumber ?? 0) + 1,
      drawnStudentIds: [],
      status: "active",
      startedAt: nowIso(),
      completedAt: null,
    };
    await repo.set(C.drawSessions, next.sessionId, next);
    const payload = { roundNumber: next.roundNumber, sessionId: next.sessionId, className: room.className };
    await remember(repo, key, payload);
    return payload;
  });
}

export async function listDrawHistory(
  db: Database,
  actor: Actor,
  query: { classId?: string | null; studentId?: string | null; from?: string | null; to?: string | null },
) {
  assertTeacher(actor, query.classId);
  return db.read(async (repo) => {
    const [draws, students, classes] = await Promise.all([
      repo.list<DrawRecord>(C.drawHistory),
      repo.list<Student>(C.students),
      repo.list<ClassRoom>(C.classes),
    ]);
    const byStudent = new Map(students.map((student) => [student.studentId, student]));
    const byClass = new Map(classes.map((room) => [room.classId, room]));
    return draws
      .filter((draw) => {
        if (actor.authorizedClassIds.length && !actor.authorizedClassIds.includes(draw.classId)) return false;
        if (query.classId && draw.classId !== query.classId) return false;
        if (query.studentId && draw.studentId !== query.studentId) return false;
        return inRange(draw.timestamp, query.from, query.to);
      })
      .sort((a, b) => b.timestamp.localeCompare(a.timestamp))
      .slice(0, 500)
      .map((draw) => {
        const student = byStudent.get(draw.studentId);
        return {
          ...draw,
          resultLabel: resultLabel(draw.result),
          studentName: student?.studentName ?? "（學生資料已封存）",
          displayName: student?.displayName ?? "",
          classNumber: student?.classNumber ?? null,
          className: byClass.get(draw.classId)?.className ?? "",
        };
      });
  });
}

async function economy(repo: Repo, studentIds: string[]) {
  const settings = await settingsOf(repo);
  const rows = [];
  for (const studentId of studentIds) {
    const student = await repo.get<Student>(C.students, studentId);
    if (!student) throw new AppError(404, "找不到學生。", "STUDENT");
    const wallet = (await repo.get<Wallet>(C.wallets, studentId)) ?? emptyWallet(studentId);
    const pet = await repo.get<Pet>(C.pets, petDocId(studentId));
    rows.push({ student, wallet, pet });
  }
  return { settings, rows };
}

export async function awardPoints(
  db: Database,
  actor: Actor,
  input: {
    studentIds: unknown;
    amount: unknown;
    reason: unknown;
    mode: unknown;
    idempotencyKey: unknown;
    relatedReferenceId?: unknown;
  },
) {
  assertTeacher(actor);
  const key = idempotencyKey(input.idempotencyKey);
  const reason = text(input.reason, "原因", 80);
  if (input.mode !== "earn" && input.mode !== "adjust") {
    throw new AppError(400, "積分操作不正確。", "VALIDATION");
  }
  const amount =
    input.mode === "earn" ? integer(input.amount, "積分", 1, 100) : integer(input.amount, "積分", -1000, -1);
  if (!Array.isArray(input.studentIds) || input.studentIds.length < 1 || input.studentIds.length > 80) {
    throw new AppError(400, "請選擇 1 至 80 位學生。", "VALIDATION");
  }
  const studentIds = input.studentIds.map((id) => text(id, "學生", 80));
  const related = input.relatedReferenceId ? text(input.relatedReferenceId, "相關紀錄", 80) : null;
  return db.withTransaction(async (repo) => {
    const prior = await cached<Record<string, unknown>>(repo, key);
    if (prior) return prior;
    const { settings, rows } = await economy(repo, studentIds);
    for (const row of rows) assertTeacher(actor, row.student.classId);
    const transactions: PointTransaction[] = [];
    for (const row of rows) {
      if (input.mode === "earn") earn(row.wallet, row.pet, amount, settings);
      else deduct(row.wallet, row.pet, -amount, settings);
      transactions.push(
        tx({
          studentId: row.student.studentId,
          amount,
          type: input.mode === "earn" ? "earn" : "adjust",
          reason,
          createdBy: actor.uid,
          relatedReferenceId: related,
          idempotencyKey: key,
        }),
      );
    }
    for (const row of rows) {
      await repo.set(C.wallets, row.wallet.studentId, row.wallet);
      if (row.pet) await repo.set(C.pets, row.pet.petId, row.pet);
    }
    for (const entry of transactions) await repo.set(C.pointTransactions, entry.transactionId, entry);
    const body = { transactions, wallets: rows.map((row) => row.wallet) };
    await remember(repo, key, body);
    return body;
  });
}

export async function awardFromDraw(
  db: Database,
  actor: Actor,
  input: { drawId: unknown; ruleId: unknown; amount?: unknown; reason?: unknown; idempotencyKey: unknown },
) {
  assertTeacher(actor);
  const drawId = text(input.drawId, "抽籤", 80);
  const ruleId = text(input.ruleId, "加分項目", 40);
  const key = idempotencyKey(input.idempotencyKey);
  return db.withTransaction(async (repo) => {
    const prior = await cached<Record<string, unknown>>(repo, key);
    if (prior) return prior;
    const settings = await settingsOf(repo);
    const draw = await repo.get<DrawRecord>(C.drawHistory, drawId);
    if (!draw) throw new AppError(404, "找不到抽籤紀錄。", "DRAW");
    assertTeacher(actor, draw.classId);
    if (draw.result === "returned") {
      throw new AppError(409, "這位學生已返回未抽名單，不能就此紀錄加分。", "DRAW_RETURNED");
    }
    if (draw.awards[ruleId]) {
      const existing = await repo.get<PointTransaction>(C.pointTransactions, draw.awards[ruleId]);
      const wallet = await repo.get<Wallet>(C.wallets, draw.studentId);
      const body = { already: true, transactions: existing ? [existing] : [], wallets: wallet ? [wallet] : [] };
      await remember(repo, key, body);
      return body;
    }
    let amount = 0;
    let reason = "";
    if (ruleId === "custom") {
      amount = integer(input.amount, "積分", 1, 100);
      reason = text(input.reason ?? "自訂加分", "原因", 80);
    } else {
      const rule = settings.pointRules.find((item) => item.id === ruleId);
      if (!rule) throw new AppError(400, "找不到這個加分項目。", "VALIDATION");
      amount = rule.points;
      reason = rule.label;
    }
    const loaded = await economy(repo, [draw.studentId]);
    const row = loaded.rows[0];
    earn(row.wallet, row.pet, amount, loaded.settings);
    const entry = tx({
      studentId: row.student.studentId,
      amount,
      type: "earn",
      reason,
      createdBy: actor.uid,
      relatedReferenceId: draw.drawId,
      idempotencyKey: key,
    });
    draw.awards = { ...draw.awards, [ruleId]: entry.transactionId };
    await repo.set(C.wallets, row.wallet.studentId, row.wallet);
    if (row.pet) await repo.set(C.pets, row.pet.petId, row.pet);
    await repo.set(C.pointTransactions, entry.transactionId, entry);
    await repo.set(C.drawHistory, draw.drawId, draw);
    const body = { already: false, transactions: [entry], wallets: [row.wallet] };
    await remember(repo, key, body);
    return body;
  });
}

export async function listTransactions(db: Database, actor: Actor, studentId: string) {
  const student = await db.read((repo) => repo.get<Student>(C.students, studentId));
  if (!student) throw new AppError(404, "找不到學生。", "STUDENT");
  if (actor.role === "student" && actor.linkedStudentId !== studentId) {
    throw new AppError(403, "不能查看其他同學的積分紀錄。", "FORBIDDEN");
  }
  if (actor.role === "teacher") assertTeacher(actor, student.classId);
  const transactions = await db.read((repo) => repo.list<PointTransaction>(C.pointTransactions));
  return transactions
    .filter((entry) => entry.studentId === studentId)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    .slice(0, 200);
}

function inPeriod(iso: string, period: "week" | "month" | "term", week: string, month: string) {
  if (period === "term") return true;
  if (period === "week") return hkDateString(new Date(iso)) >= week;
  return hkMonthKey(new Date(iso)) === month;
}

export async function leaderboard(db: Database, actor: Actor, classIdRaw: unknown, periodRaw: unknown) {
  const period = periodRaw === "week" || periodRaw === "month" || periodRaw === "term" ? periodRaw : "term";
  const settings = await db.read(settingsOf);
  let classId = "";
  if (actor.role === "student") {
    if (!settings.leaderboardEnabled) return { enabled: false, period, rows: [] };
    const me = await db.read((repo) => repo.get<Student>(C.students, ownStudentId(actor)));
    if (!me) throw new AppError(404, "找不到學生。", "STUDENT");
    classId = me.classId;
  } else {
    classId = text(classIdRaw, "班別", 80);
    assertTeacher(actor, classId);
  }
  const now = new Date();
  const week = hkWeekStart(now);
  const month = hkMonthKey(now);
  return db.read(async (repo) => {
    const students = await activeStudents(repo, classId);
    const transactions = await repo.list<PointTransaction>(C.pointTransactions);
    const nickname = actor.role === "student" && settings.leaderboardUseNickname;
    const rows = students
      .map((student) => ({
        studentId: actor.role === "teacher" ? student.studentId : null,
        classNumber: student.classNumber,
        name: nickname ? student.displayName : student.studentName,
        earned: transactions
          .filter(
            (entry) =>
              entry.studentId === student.studentId &&
              entry.type === "earn" &&
              inPeriod(entry.createdAt, period, week, month),
          )
          .reduce((sum, entry) => sum + entry.amount, 0),
        isMe: actor.linkedStudentId === student.studentId,
      }))
      .sort((a, b) => b.earned - a.earned || a.classNumber - b.classNumber)
      .map((row, index) => ({ ...row, rank: index + 1 }));
    return { enabled: true, period, classId, useNickname: nickname, rows };
  });
}

export async function listItems(db: Database, actor: Actor) {
  const items = await db.read((repo) => repo.list<Item>(C.items));
  const visible = actor.role === "teacher" ? items : items.filter((item) => item.isActive);
  return visible.map(presentItem).sort((a, b) => a.price - b.price || a.name.localeCompare(b.name, "zh-Hant"));
}

export async function saveItem(db: Database, actor: Actor, itemId: string | null, input: Record<string, unknown>) {
  assertTeacher(actor);
  const name = text(input.name, "商品名稱", 40);
  if (!CATEGORIES.has(input.category as ItemCategory)) throw new AppError(400, "商品種類不正確。", "VALIDATION");
  if (!RARITIES.has(input.rarity as Rarity)) throw new AppError(400, "稀有度不正確。", "VALIDATION");
  const category = input.category as ItemCategory;
  const rarity = input.rarity as Rarity;
  const price = integer(input.price, "價格", 0, 100000);
  const description = typeof input.description === "string" ? input.description.trim().slice(0, 200) : "";
  const minLevel = input.minLevel == null || input.minLevel === "" ? 1 : integer(input.minLevel, "等級要求", 1, 200);
  const isActive = input.isActive !== false && input.isActive !== "false";
  const stock = input.stock == null || input.stock === "" ? null : integer(input.stock, "庫存", 0, 100000);
  const purchaseLimit =
    input.purchaseLimit == null || input.purchaseLimit === ""
      ? null
      : integer(input.purchaseLimit, "購買上限", 1, 100);
  const item: Item = {
    itemId: itemId ?? newId("item"),
    name,
    category,
    rarity,
    price,
    statsBonus: normalizeStats(input.statsBonus as Partial<Stats> | null),
    description,
    imageKey: optionalText(input.imageKey, "圖片", 300),
    stock,
    purchaseLimit,
    minLevel,
    isActive,
    slot: slotForCategory(category),
    updatedAt: nowIso(),
  };
  await db.withTransaction(async (repo) => {
    if (itemId && input.allowCreate !== true && !(await repo.get<Item>(C.items, itemId))) {
      throw new AppError(404, "找不到商品。", "ITEM");
    }
    await repo.set(C.items, item.itemId, item);
  });
  return presentItem(item);
}

export async function listRewards(db: Database, actor: Actor) {
  const rewards = await db.read((repo) => repo.list<Reward>(C.rewards));
  const visible = actor.role === "teacher" ? rewards : rewards.filter((reward) => reward.isActive);
  return visible.sort((a, b) => a.price - b.price);
}

export async function saveReward(
  db: Database,
  actor: Actor,
  rewardId: string | null,
  input: Record<string, unknown>,
) {
  assertTeacher(actor);
  const reward: Reward = {
    rewardId: rewardId ?? newId("rew"),
    name: text(input.name, "獎勵名稱", 40),
    description: typeof input.description === "string" ? input.description.trim().slice(0, 200) : "",
    price: integer(input.price, "價格", 0, 100000),
    stock: integer(input.stock, "庫存", 0, 100000),
    isActive: input.isActive !== false && input.isActive !== "false",
    updatedAt: nowIso(),
  };
  await db.withTransaction(async (repo) => {
    if (rewardId && input.allowCreate !== true && !(await repo.get(C.rewards, rewardId))) {
      throw new AppError(404, "找不到獎勵。", "REWARD");
    }
    await repo.set(C.rewards, reward.rewardId, reward);
  });
  return reward;
}

export async function purchaseItem(
  db: Database,
  actor: Actor,
  input: { itemId: unknown; idempotencyKey: unknown },
) {
  const studentId = ownStudentId(actor);
  const itemId = text(input.itemId, "商品", 80);
  const key = idempotencyKey(input.idempotencyKey);
  return db.withTransaction(async (repo) => {
    const prior = await cached<Record<string, unknown>>(repo, key);
    if (prior) return prior;
    const item = await repo.get<Item>(C.items, itemId);
    if (!item?.isActive) throw new AppError(404, "商品未有出售。", "ITEM");
    const student = await repo.get<Student>(C.students, studentId);
    if (!student || student.enrollmentStatus !== "active") throw new AppError(403, "目前不能購買。", "STUDENT");
    const wallet = (await repo.get<Wallet>(C.wallets, studentId)) ?? emptyWallet(studentId);
    const pet = await repo.get<Pet>(C.pets, petDocId(studentId));
    const settings = await settingsOf(repo);
    const level = pet ? progressFromExp(pet.exp, settings.levelBaseExp, settings.levelGrowth).level : 1;
    if (level < item.minLevel) throw new AppError(400, `需要寵物達到 ${item.minLevel} 級。`, "LEVEL");
    if (item.stock != null && item.stock < 1) throw new AppError(400, "商品已售罄。", "STOCK");
    const owned = (await repo.list<Order>(C.orders)).filter(
      (order) =>
        order.studentId === studentId &&
        order.itemId === itemId &&
        order.orderType === "virtual" &&
        order.status !== "cancelled",
    ).length;
    if (item.purchaseLimit != null && owned >= item.purchaseLimit) {
      throw new AppError(400, "已達到此商品的購買上限。", "LIMIT");
    }
    spend(wallet, item.price);
    if (item.stock != null) item.stock -= 1;
    item.updatedAt = nowIso();
    const order: Order = {
      orderId: newId("ord"),
      studentId,
      orderType: "virtual",
      itemId: item.itemId,
      itemName: item.name,
      quantity: 1,
      totalPrice: item.price,
      status: "completed",
      createdAt: nowIso(),
      fulfilledAt: nowIso(),
      idempotencyKey: key,
      note: null,
    };
    const inventory: InventoryItem = {
      inventoryId: newId("inv"),
      studentId,
      itemId: item.itemId,
      quantity: 1,
      acquiredAt: nowIso(),
      orderId: order.orderId,
    };
    const entry = tx({
      studentId,
      amount: -item.price,
      type: "spend",
      reason: `購買 ${item.name}`,
      createdBy: actor.uid,
      relatedReferenceId: order.orderId,
      idempotencyKey: key,
    });
    await repo.set(C.wallets, studentId, wallet);
    await repo.set(C.items, item.itemId, item);
    await repo.set(C.orders, order.orderId, order);
    await repo.set(C.inventories, inventory.inventoryId, inventory);
    await repo.set(C.pointTransactions, entry.transactionId, entry);
    const body = { order, inventory, wallet, item: presentItem(item) };
    await remember(repo, key, body);
    return body;
  });
}

export async function redeemReward(
  db: Database,
  actor: Actor,
  input: { rewardId: unknown; idempotencyKey: unknown },
) {
  const studentId = ownStudentId(actor);
  const rewardId = text(input.rewardId, "獎勵", 80);
  const key = idempotencyKey(input.idempotencyKey);
  return db.withTransaction(async (repo) => {
    const prior = await cached<Record<string, unknown>>(repo, key);
    if (prior) return prior;
    const reward = await repo.get<Reward>(C.rewards, rewardId);
    if (!reward?.isActive) throw new AppError(404, "這份獎勵未有開放兌換。", "REWARD");
    if (reward.stock < 1) throw new AppError(400, "獎勵存貨不足。", "STOCK");
    const wallet = (await repo.get<Wallet>(C.wallets, studentId)) ?? emptyWallet(studentId);
    spend(wallet, reward.price);
    reward.stock -= 1;
    reward.updatedAt = nowIso();
    const order: Order = {
      orderId: newId("ord"),
      studentId,
      orderType: "physical",
      itemId: reward.rewardId,
      itemName: reward.name,
      quantity: 1,
      totalPrice: reward.price,
      status: "pending",
      createdAt: nowIso(),
      fulfilledAt: null,
      idempotencyKey: key,
      note: null,
    };
    const entry = tx({
      studentId,
      amount: -reward.price,
      type: "spend",
      reason: `兌換 ${reward.name}`,
      createdBy: actor.uid,
      relatedReferenceId: order.orderId,
      idempotencyKey: key,
    });
    await repo.set(C.wallets, studentId, wallet);
    await repo.set(C.rewards, reward.rewardId, reward);
    await repo.set(C.orders, order.orderId, order);
    await repo.set(C.pointTransactions, entry.transactionId, entry);
    const body = { order, wallet };
    await remember(repo, key, body);
    return body;
  });
}

export async function listOrders(
  db: Database,
  actor: Actor,
  query: { status?: string | null; studentId?: string | null; orderType?: string | null },
) {
  const orders = await db.read((repo) => repo.list<Order>(C.orders));
  if (actor.role === "student") {
    const studentId = ownStudentId(actor);
    return orders
      .filter((order) => order.studentId === studentId)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }
  assertTeacher(actor);
  const students = await db.read((repo) => repo.list<Student>(C.students));
  const byId = new Map(students.map((student) => [student.studentId, student]));
  return orders
    .filter((order) => {
      const student = byId.get(order.studentId);
      if (student && actor.authorizedClassIds.length && !actor.authorizedClassIds.includes(student.classId)) {
        return false;
      }
      if (query.studentId && order.studentId !== query.studentId) return false;
      if (query.status && order.status !== query.status) return false;
      if (query.orderType && order.orderType !== query.orderType) return false;
      return true;
    })
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    .map((order) => ({
      ...order,
      studentName: byId.get(order.studentId)?.studentName ?? "",
      classNumber: byId.get(order.studentId)?.classNumber ?? null,
      classId: byId.get(order.studentId)?.classId ?? null,
    }));
}

export async function fulfillOrder(db: Database, actor: Actor, orderId: string) {
  assertTeacher(actor);
  return db.withTransaction(async (repo) => {
    const order = await repo.get<Order>(C.orders, orderId);
    if (!order) throw new AppError(404, "找不到訂單。", "ORDER");
    const student = await repo.get<Student>(C.students, order.studentId);
    if (student) assertTeacher(actor, student.classId);
    if (order.orderType !== "physical" || order.status !== "pending") {
      throw new AppError(409, "這張訂單不能標記為已領取。", "ORDER");
    }
    order.status = "fulfilled";
    order.fulfilledAt = nowIso();
    await repo.set(C.orders, order.orderId, order);
    return order;
  });
}

export async function cancelOrder(db: Database, actor: Actor, orderId: string, note: unknown) {
  assertTeacher(actor);
  return db.withTransaction(async (repo) => {
    const order = await repo.get<Order>(C.orders, orderId);
    if (!order) throw new AppError(404, "找不到訂單。", "ORDER");
    const student = await repo.get<Student>(C.students, order.studentId);
    if (student) assertTeacher(actor, student.classId);
    const reward = await repo.get<Reward>(C.rewards, order.itemId);
    const wallet = (await repo.get<Wallet>(C.wallets, order.studentId)) ?? emptyWallet(order.studentId);
    if (order.orderType !== "physical" || order.status !== "pending") {
      throw new AppError(409, "這張訂單不能取消。", "ORDER");
    }
    order.status = "cancelled";
    order.fulfilledAt = nowIso();
    order.note = optionalText(note, "備註", 80);
    if (reward) {
      reward.stock += order.quantity;
      reward.updatedAt = nowIso();
      await repo.set(C.rewards, reward.rewardId, reward);
    }
    refundCoins(wallet, order.totalPrice);
    const entry = tx({
      studentId: order.studentId,
      amount: order.totalPrice,
      type: "refund",
      reason: `取消兌換，退回金幣：${order.itemName}`,
      createdBy: actor.uid,
      relatedReferenceId: order.orderId,
      idempotencyKey: null,
    });
    await repo.set(C.wallets, wallet.studentId, wallet);
    await repo.set(C.orders, order.orderId, order);
    await repo.set(C.pointTransactions, entry.transactionId, entry);
    return { order, wallet, transaction: entry };
  });
}

async function petDetail(repo: Repo, pet: Pet, settings: Settings) {
  const inventory = (await repo.list<InventoryItem>(C.inventories)).filter(
    (item) => item.studentId === pet.studentId,
  );
  const items = await repo.list<Item>(C.items);
  const byItem = new Map(items.map((item) => [item.itemId, item]));
  const byInventory = new Map(inventory.map((item) => [item.inventoryId, item]));
  const equippedItems: Item[] = [];
  const slots: Record<string, { inventoryId: string; item: ReturnType<typeof presentItem> } | null> = {};
  for (const slot of SLOTS) {
    const inventoryId = pet.equipped[slot];
    const row = inventoryId ? byInventory.get(inventoryId) : undefined;
    const item = row ? byItem.get(row.itemId) : undefined;
    if (inventoryId && item) {
      equippedItems.push(item);
      slots[slot] = { inventoryId, item: presentItem(item) };
    } else {
      slots[slot] = null;
    }
  }
  const progress = progressFromExp(pet.exp, settings.levelBaseExp, settings.levelGrowth);
  const combat = combatFrom(
    pet.petType,
    progress.level,
    equippedItems.map((item) => item.statsBonus),
  );
  return {
    pet: { ...pet, level: progress.level },
    species: PET_CATALOG[pet.petType],
    progress,
    combat,
    slots,
    inventory: inventory
      .map((row) => ({
        ...row,
        item: byItem.get(row.itemId) ? presentItem(byItem.get(row.itemId)!) : null,
      }))
      .sort((a, b) => b.acquiredAt.localeCompare(a.acquiredAt)),
  };
}

export async function studentHome(db: Database, actor: Actor, studentIdRaw?: string | null) {
  const studentId = actor.role === "student" ? ownStudentId(actor) : text(studentIdRaw, "學生", 80);
  return db.read(async (repo) => {
    const student = await repo.get<Student>(C.students, studentId);
    if (!student) throw new AppError(404, "找不到學生。", "STUDENT");
    if (actor.role === "teacher") assertTeacher(actor, student.classId);
    if (actor.role === "student" && student.studentId !== actor.linkedStudentId) {
      throw new AppError(403, "不能查看其他同學的寵物。", "FORBIDDEN");
    }
    const settings = await settingsOf(repo);
    const wallet = (await repo.get<Wallet>(C.wallets, studentId)) ?? emptyWallet(studentId);
    const pet = await repo.get<Pet>(C.pets, petDocId(studentId));
    const detail = pet ? await petDetail(repo, pet, settings) : null;
    const orders = (await repo.list<Order>(C.orders)).filter((order) => order.studentId === studentId);
    const draws = (await repo.list<DrawRecord>(C.drawHistory)).filter(
      (draw) => draw.studentId === studentId && draw.result !== "returned",
    );
    const level = detail?.pet.level ?? 0;
    return {
      student: {
        studentId: student.studentId,
        classId: student.classId,
        classNumber: student.classNumber,
        studentName: student.studentName,
        displayName: student.displayName,
        enrollmentStatus: student.enrollmentStatus,
      },
      wallet,
      detail,
      expPerCoin: settings.expPerCoin,
      battleEnabled: false as const,
      milestones: [
        { id: "pet", title: "迎接夥伴", detail: "選擇初始寵物", done: Boolean(pet), progress: pet ? 1 : 0 },
        { id: "level", title: "穩步成長", detail: "寵物達到 5 級", done: level >= 5, progress: Math.min(1, level / 5) },
        {
          id: "coins",
          title: "金幣收藏",
          detail: "累積獲得 50 寵物金幣",
          done: wallet.lifetimeEarned >= 50,
          progress: Math.min(1, wallet.lifetimeEarned / 50),
        },
        {
          id: "shop",
          title: "第一筆交易",
          detail: "完成一次購買或兌換",
          done: orders.length > 0,
          progress: orders.length ? 1 : 0,
        },
        {
          id: "draw",
          title: "課堂常客",
          detail: "被抽中回答 3 次",
          done: draws.length >= 3,
          progress: Math.min(1, draws.length / 3),
        },
      ],
    };
  });
}

export function petChoices() {
  return PET_TYPES.map((type) => PET_CATALOG[type]);
}

export async function choosePet(db: Database, actor: Actor, input: { petType: unknown; name?: unknown }) {
  const studentId = ownStudentId(actor);
  if (!PET_TYPES.includes(input.petType as PetType)) throw new AppError(400, "請選擇一種初始寵物。", "VALIDATION");
  const petType = input.petType as PetType;
  const species = PET_CATALOG[petType];
  const name = input.name ? text(input.name, "寵物名稱", 12) : species.name;
  return db.withTransaction(async (repo) => {
    if (await repo.get<Pet>(C.pets, petDocId(studentId))) {
      throw new AppError(409, "你已經有寵物了。", "PET_EXISTS");
    }
    const settings = await settingsOf(repo);
    const wallet = (await repo.get<Wallet>(C.wallets, studentId)) ?? emptyWallet(studentId);
    const pet: Pet = {
      petId: petDocId(studentId),
      studentId,
      petType,
      name,
      level: 1,
      exp: wallet.pendingExp,
      equipped: EMPTY_EQUIPPED(),
      createdAt: nowIso(),
    };
    wallet.pendingExp = 0;
    wallet.updatedAt = nowIso();
    syncLevel(pet, settings);
    await repo.set(C.pets, pet.petId, pet);
    await repo.set(C.wallets, wallet.studentId, wallet);
    return { pet };
  });
}

export async function renamePet(db: Database, actor: Actor, nameRaw: unknown) {
  const studentId = ownStudentId(actor);
  const name = text(nameRaw, "寵物名稱", 12);
  return db.withTransaction(async (repo) => {
    const pet = await repo.get<Pet>(C.pets, petDocId(studentId));
    if (!pet) throw new AppError(404, "尚未選擇寵物。", "PET");
    pet.name = name;
    await repo.set(C.pets, pet.petId, pet);
    return { pet };
  });
}

export async function equipItem(db: Database, actor: Actor, inventoryIdRaw: unknown) {
  const studentId = ownStudentId(actor);
  const inventoryId = text(inventoryIdRaw, "道具", 80);
  return db.withTransaction(async (repo) => {
    const row = await repo.get<InventoryItem>(C.inventories, inventoryId);
    if (!row || row.studentId !== studentId) {
      throw new AppError(403, "不能裝備不屬於自己的道具。", "FORBIDDEN");
    }
    const item = await repo.get<Item>(C.items, row.itemId);
    if (!item?.slot) throw new AppError(400, "這件道具不能裝備。", "ITEM");
    const pet = await repo.get<Pet>(C.pets, petDocId(studentId));
    if (!pet) throw new AppError(400, "請先選擇寵物。", "PET");
    const equipped = { ...pet.equipped };
    for (const slot of SLOTS) {
      if (equipped[slot] === inventoryId) equipped[slot] = null;
    }
    equipped[item.slot] = inventoryId;
    pet.equipped = equipped;
    await repo.set(C.pets, pet.petId, pet);
    return { pet };
  });
}

export async function unequipItem(db: Database, actor: Actor, slotRaw: unknown) {
  const studentId = ownStudentId(actor);
  const slot = text(slotRaw, "欄位", 20);
  if (!SLOTS.includes(slot as (typeof SLOTS)[number])) throw new AppError(400, "裝備欄位不正確。", "VALIDATION");
  return db.withTransaction(async (repo) => {
    const pet = await repo.get<Pet>(C.pets, petDocId(studentId));
    if (!pet) throw new AppError(400, "請先選擇寵物。", "PET");
    pet.equipped = { ...pet.equipped, [slot]: null };
    await repo.set(C.pets, pet.petId, pet);
    return { pet };
  });
}

export async function listClassPets(db: Database, actor: Actor, classId: string) {
  assertTeacher(actor, classId);
  return db.read(async (repo) => {
    const settings = await settingsOf(repo);
    const students = (await activeStudents(repo, classId)).sort((a, b) => a.classNumber - b.classNumber);
    const rows = [];
    for (const student of students) {
      const pet = await repo.get<Pet>(C.pets, petDocId(student.studentId));
      rows.push({
        student: {
          studentId: student.studentId,
          classNumber: student.classNumber,
          studentName: student.studentName,
          displayName: student.displayName,
        },
        detail: pet ? await petDetail(repo, pet, settings) : null,
      });
    }
    return rows;
  });
}

export async function getSettings(db: Database, actor: Actor) {
  assertTeacher(actor);
  return db.read(settingsOf);
}

export async function updateSettings(db: Database, actor: Actor, input: Record<string, unknown>) {
  assertTeacher(actor);
  return db.withTransaction(async (repo) => {
    const settings = await settingsOf(repo);
    if (input.schoolYear != null) {
      const year = text(input.schoolYear, "學年", 9);
      if (!/^\d{4}-\d{4}$/.test(year)) throw new AppError(400, "學年格式應為 2026-2027。", "VALIDATION");
      settings.schoolYear = year;
    }
    if (input.expPerCoin != null) settings.expPerCoin = integer(input.expPerCoin, "經驗值", 0, 100);
    if (input.levelBaseExp != null) settings.levelBaseExp = integer(input.levelBaseExp, "升級經驗", 10, 10000);
    if (input.levelGrowth != null) {
      const growth = Number(input.levelGrowth);
      if (!Number.isFinite(growth) || growth < 1.05 || growth > 3) {
        throw new AppError(400, "等級成長倍率不正確。", "VALIDATION");
      }
      settings.levelGrowth = Math.round(growth * 100) / 100;
    }
    if (input.pointRules != null) {
      if (!Array.isArray(input.pointRules) || input.pointRules.length < 1 || input.pointRules.length > 12) {
        throw new AppError(400, "加分項目數量不正確。", "VALIDATION");
      }
      settings.pointRules = input.pointRules.map((rule: PointRule, index) => ({
        id: text(rule?.id || `rule${index + 1}`, "項目", 40),
        label: text(rule?.label, "項目名稱", 20),
        points: integer(rule?.points, "積分", 1, 100),
      }));
    }
    if (typeof input.fastDraw === "boolean") settings.fastDraw = input.fastDraw;
    if (typeof input.leaderboardEnabled === "boolean") settings.leaderboardEnabled = input.leaderboardEnabled;
    if (typeof input.leaderboardUseNickname === "boolean") {
      settings.leaderboardUseNickname = input.leaderboardUseNickname;
    }
    if (typeof input.projectionShowsFullName === "boolean") {
      settings.projectionShowsFullName = input.projectionShowsFullName;
    }
    if (typeof input.demoMode === "boolean") settings.demoMode = input.demoMode;
    settings.featureFlags = { battle: false };
    await repo.set(C.settings, SETTINGS_ID, settings);
    return settings;
  });
}

function recentDates(count: number) {
  const dates: string[] = [];
  const seen = new Set<string>();
  let cursor = new Date();
  while (dates.length < count) {
    const day = hkDateString(cursor);
    if (!seen.has(day)) {
      seen.add(day);
      dates.push(day);
    }
    cursor = new Date(cursor.getTime() - 24 * 60 * 60 * 1000);
  }
  return dates.reverse();
}

export async function reportOverview(db: Database, actor: Actor) {
  assertTeacher(actor);
  return db.read(async (repo) => {
    const today = hkDateString();
    const settings = await settingsOf(repo);
    const classes = (await repo.list<ClassRoom>(C.classes))
      .filter(
        (room) =>
          room.status === "active" &&
          (actor.authorizedClassIds.length === 0 || actor.authorizedClassIds.includes(room.classId)),
      )
      .sort((a, b) => a.className.localeCompare(b.className, "zh-Hant"));
    const classIds = new Set(classes.map((room) => room.classId));
    const students = (await repo.list<Student>(C.students)).filter((student) => classIds.has(student.classId));
    const active = students.filter((student) => student.enrollmentStatus === "active");
    const wallets = await repo.list<Wallet>(C.wallets);
    const pets = await repo.list<Pet>(C.pets);
    const draws = (await repo.list<DrawRecord>(C.drawHistory)).filter((draw) => classIds.has(draw.classId));
    const sessions = (await repo.list<DrawSession>(C.drawSessions)).filter((session) => classIds.has(session.classId));
    const transactions = await repo.list<PointTransaction>(C.pointTransactions);
    const orders = await repo.list<Order>(C.orders);
    const absences = await repo.list<Absence>(C.absences);
    const walletOf = new Map(wallets.map((wallet) => [wallet.studentId, wallet]));
    const petOf = new Map(pets.map((pet) => [pet.studentId, pet]));
    const classRows = classes.map((room) => {
      const members = active.filter((student) => student.classId === room.classId);
      const session = latestSession(sessions.filter((item) => item.classId === room.classId));
      const levels = members
        .map((student) => petOf.get(student.studentId))
        .filter((pet): pet is Pet => Boolean(pet))
        .map((pet) => progressFromExp(pet.exp, settings.levelBaseExp, settings.levelGrowth).level);
      return {
        classId: room.classId,
        className: room.className,
        studentCount: members.length,
        roundNumber: session?.roundNumber ?? 0,
        roundStatus: session?.status ?? "ready",
        drawnThisRound:
          session?.status === "completed"
            ? members.length
            : members.filter((student) => session?.drawnStudentIds.includes(student.studentId)).length,
        absentToday: absences.find((absence) => absence.classId === room.classId && absence.date === today)
          ?.studentIds.length ?? 0,
        lifetimeEarned: members.reduce((sum, student) => sum + (walletOf.get(student.studentId)?.lifetimeEarned ?? 0), 0),
        averagePetLevel: levels.length
          ? Math.round((levels.reduce((sum, level) => sum + level, 0) / levels.length) * 10) / 10
          : 0,
        drawCount: draws.filter((draw) => draw.classId === room.classId && draw.result !== "returned").length,
      };
    });
    const drawCounts = new Map<string, { count: number; last: string | null }>();
    for (const draw of draws) {
      if (draw.result === "returned") continue;
      const current = drawCounts.get(draw.studentId) ?? { count: 0, last: null };
      current.count += 1;
      if (!current.last || draw.timestamp > current.last) current.last = draw.timestamp;
      drawCounts.set(draw.studentId, current);
    }
    const className = new Map(classes.map((room) => [room.classId, room.className]));
    const rarelyDrawn = active
      .map((student) => ({
        studentId: student.studentId,
        className: className.get(student.classId) ?? "",
        classNumber: student.classNumber,
        studentName: student.studentName,
        drawCount: drawCounts.get(student.studentId)?.count ?? 0,
        lastDrawAt: drawCounts.get(student.studentId)?.last ?? null,
      }))
      .sort((a, b) => a.drawCount - b.drawCount || a.className.localeCompare(b.className, "zh-Hant") || a.classNumber - b.classNumber)
      .slice(0, 8);
    const coinsByDay = recentDates(14).map((date) => ({
      date,
      amount: transactions
        .filter((entry) => entry.type === "earn" && hkDateString(new Date(entry.createdAt)) === date)
        .reduce((sum, entry) => sum + entry.amount, 0),
    }));
    const popular = new Map<string, { name: string; count: number }>();
    for (const order of orders) {
      if (order.orderType !== "virtual" || order.status === "cancelled") continue;
      const current = popular.get(order.itemId) ?? { name: order.itemName, count: 0 };
      current.count += 1;
      popular.set(order.itemId, current);
    }
    return {
      classCount: classes.length,
      studentCount: active.length,
      drawsToday: draws.filter(
        (draw) => draw.result !== "returned" && hkDateString(new Date(draw.timestamp)) === today,
      ).length,
      coinsToday: transactions
        .filter((entry) => entry.type === "earn" && hkDateString(new Date(entry.createdAt)) === today)
        .reduce((sum, entry) => sum + entry.amount, 0),
      pendingRewards: orders.filter((order) => order.orderType === "physical" && order.status === "pending").length,
      classRows,
      rarelyDrawn,
      coinsByDay,
      popularItems: [...popular.values()].sort((a, b) => b.count - a.count).slice(0, 6),
    };
  });
}

export async function exportData(
  db: Database,
  actor: Actor,
  query: { kind?: string | null; format?: string | null; classId?: string | null; from?: string | null; to?: string | null },
) {
  assertTeacher(actor, query.classId);
  const format = query.format === "xlsx" ? "xlsx" : query.format === "json" ? "json" : "csv";
  if (query.kind === "draws") {
    const history = await listDrawHistory(db, actor, query);
    const rows = history.map((draw) => ({
      時間: draw.timestamp,
      班別: draw.className,
      學號: draw.classNumber ?? "",
      姓名: draw.studentName,
      輪次: draw.roundNumber,
      結果: draw.resultLabel,
    }));
    return pack(rows, format === "json" ? "csv" : format, "抽籤紀錄");
  }
  if (query.kind === "points") {
    const classes = await listClasses(db, actor);
    const rows: Record<string, string | number>[] = [];
    for (const room of classes) {
      if (room.status === "archived") continue;
      if (query.classId && room.classId !== query.classId) continue;
      const students = await listStudents(db, actor, { classId: room.classId });
      for (const student of students) {
        rows.push({
          班別: room.className,
          學號: student.classNumber,
          姓名: student.studentName,
          可用金幣: student.wallet.currentBalance,
          累積獲得: student.wallet.lifetimeEarned,
          已花費: student.wallet.lifetimeSpent,
        });
      }
    }
    return pack(rows, format === "json" ? "csv" : format, "積分紀錄");
  }
  if (query.kind === "backup") {
    const body = await db.read(async (repo) => {
      const users = await repo.list<import("./types").UserRecord>(C.users);
      return {
        exportedAt: nowIso(),
        settings: await settingsOf(repo),
        classes: await repo.list(C.classes),
        students: await repo.list(C.students),
        users: users.map((user) => ({
          uid: user.uid,
          role: user.role,
          displayName: user.displayName,
          loginId: user.loginId,
          linkedStudentId: user.linkedStudentId,
          authorizedClassIds: user.authorizedClassIds,
          createdAt: user.createdAt,
        })),
        wallets: await repo.list(C.wallets),
        pets: await repo.list(C.pets),
        items: await repo.list(C.items),
        rewards: await repo.list(C.rewards),
        inventories: await repo.list(C.inventories),
        orders: await repo.list(C.orders),
        drawSessions: await repo.list(C.drawSessions),
        drawHistory: await repo.list(C.drawHistory),
        pointTransactions: await repo.list(C.pointTransactions),
      };
    });
    return {
      filename: "classroom-pet-quest-backup.json",
      contentType: "application/json; charset=utf-8",
      body: Buffer.from(JSON.stringify(body, null, 2)),
    };
  }
  throw new AppError(400, "不支援這個匯出類型。", "EXPORT");
}

function pack(rows: Record<string, string | number | null | undefined>[], format: "csv" | "xlsx", name: string) {
  if (format === "xlsx") {
    return {
      filename: `${name}.xlsx`,
      contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      body: toXlsx(rows, name),
    };
  }
  return {
    filename: `${name}.csv`,
    contentType: "text/csv; charset=utf-8",
    body: Buffer.from(toCsv(rows)),
  };
}

export async function listClassPoints(db: Database, actor: Actor, classId: string) {
  assertTeacher(actor, classId);
  const students = await listStudents(db, actor, { classId });
  return students;
}
