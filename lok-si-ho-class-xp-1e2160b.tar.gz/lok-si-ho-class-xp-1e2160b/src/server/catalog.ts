import type { EquipSlot, ItemCategory, PetType, Settings, Stats } from "./types";
import { ZERO_STATS } from "./types";

export interface PetSpecies {
  type: PetType;
  name: string;
  element: string;
  blurb: string;
  base: Stats;
  growth: Stats;
}

export const PET_CATALOG: Record<PetType, PetSpecies> = {
  fire: {
    type: "fire",
    name: "小火龍",
    element: "火",
    blurb: "圓滾滾的焰團團，尾巴尖端燃着一小朵不會燙人的火焰。攻擊隨等級成長較快。",
    base: { hp: 36, attack: 10, defense: 8, speed: 9, criticalRate: 5 },
    growth: { hp: 2, attack: 1, defense: 0.5, speed: 0.5, criticalRate: 0.2 },
  },
  water: {
    type: "water",
    name: "水滴獸",
    element: "水",
    blurb: "軟軟的水滴夥伴，腮邊總掛着泡泡。防禦穩陣，適合慢慢陪你上課。",
    base: { hp: 48, attack: 8, defense: 12, speed: 8, criticalRate: 4 },
    growth: { hp: 3, attack: 0.4, defense: 1, speed: 0.4, criticalRate: 0.2 },
  },
  nature: {
    type: "nature",
    name: "森林狐",
    element: "自然",
    blurb: "耳尖夾着一片小葉的狐狸，走路很輕。速度是牠最得意的地方。",
    base: { hp: 40, attack: 9, defense: 9, speed: 12, criticalRate: 5 },
    growth: { hp: 2, attack: 0.5, defense: 0.5, speed: 1, criticalRate: 0.3 },
  },
  thunder: {
    type: "thunder",
    name: "雷電貓",
    element: "雷",
    blurb: "頰邊會劈出小小電光的貓。動作俐落，較容易打出暴擊。",
    base: { hp: 34, attack: 10, defense: 7, speed: 11, criticalRate: 8 },
    growth: { hp: 2, attack: 0.6, defense: 0.4, speed: 0.7, criticalRate: 0.8 },
  },
};

export const PET_TYPES = Object.keys(PET_CATALOG) as PetType[];

export const EQUIP_SLOTS: EquipSlot[] = [
  "weapon",
  "armor",
  "headgear",
  "accessory",
  "appearance",
];

export const SLOT_LABEL: Record<EquipSlot, string> = {
  weapon: "武器",
  armor: "防具",
  headgear: "頭飾",
  accessory: "飾品",
  appearance: "造型",
};

export const CATEGORY_LABEL: Record<ItemCategory, string> = {
  weapon: "武器",
  armor: "防具",
  headgear: "頭飾",
  accessory: "飾品",
  consumable: "消耗品",
  cosmetic: "寵物造型",
};

export const RARITY_LABEL: Record<string, string> = {
  common: "普通",
  rare: "稀有",
  epic: "史詩",
  legendary: "傳說",
};

export function slotForCategory(category: ItemCategory): EquipSlot | null {
  if (category === "consumable") return null;
  if (category === "cosmetic") return "appearance";
  return category;
}

export function defaultSettings(): Settings {
  return {
    schoolYear: "2026-2027",
    expPerCoin: 10,
    levelBaseExp: 100,
    levelGrowth: 1.5,
    pointRules: [
      { id: "correct", label: "正確回答問題", points: 1 },
      { id: "active", label: "主動參與課堂", points: 2 },
      { id: "excellent", label: "出色回答", points: 3 },
      { id: "challenge", label: "完成額外挑戰", points: 5 },
    ],
    fastDraw: false,
    leaderboardEnabled: true,
    leaderboardUseNickname: false,
    projectionShowsFullName: false,
    featureFlags: { battle: false },
    demoMode: false,
  };
}

export function expRequiredForLevel(level: number, base: number, growth: number) {
  return Math.max(1, Math.round(base * growth ** (level - 1)));
}

export function progressFromExp(exp: number, base: number, growth: number) {
  let level = 1;
  let rest = Math.max(0, Math.floor(exp));
  for (let guard = 0; guard < 400; guard += 1) {
    const need = expRequiredForLevel(level, base, growth);
    if (rest < need) return { level, into: rest, need };
    rest -= need;
    level += 1;
  }
  return { level, into: rest, need: expRequiredForLevel(level, base, growth) };
}

export function addStats(left: Stats, right: Stats): Stats {
  return {
    hp: left.hp + right.hp,
    attack: left.attack + right.attack,
    defense: left.defense + right.defense,
    speed: left.speed + right.speed,
    criticalRate: left.criticalRate + right.criticalRate,
  };
}

export function scaleGrowth(growth: Stats, levelsGained: number): Stats {
  const factor = Math.max(0, levelsGained);
  return {
    hp: Math.round(growth.hp * factor),
    attack: Math.round(growth.attack * factor),
    defense: Math.round(growth.defense * factor),
    speed: Math.round(growth.speed * factor),
    criticalRate: Math.round(growth.criticalRate * factor),
  };
}

export function combatFrom(petType: PetType, level: number, equipped: Stats[]) {
  const species = PET_CATALOG[petType];
  const levelBonus = scaleGrowth(species.growth, level - 1);
  const equipmentBonus = equipped.reduce(addStats, ZERO_STATS());
  const final = addStats(addStats(species.base, levelBonus), equipmentBonus);
  return { base: species.base, levelBonus, equipmentBonus, final };
}

export function normalizeStats(input: Partial<Stats> | null | undefined): Stats {
  return {
    hp: num(input?.hp),
    attack: num(input?.attack),
    defense: num(input?.defense),
    speed: num(input?.speed),
    criticalRate: num(input?.criticalRate),
  };
}

function num(value: unknown) {
  const n = typeof value === "number" ? value : Number(value ?? 0);
  if (!Number.isFinite(n)) return 0;
  return Math.round(n);
}

export function makeLoginId(className: string, classNumber: number) {
  return `${className}-${String(classNumber).padStart(2, "0")}`;
}
