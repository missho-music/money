import { PET_TYPES } from "./catalog";
import type { Database } from "./repo";
import {
  awardPoints,
  choosePet,
  performDraw,
  saveItem,
  saveReward,
  updateSettings,
} from "./game-services";
import { C } from "./collections";
import { DEMO, addStudent, createClass, createTeacher } from "./services";
import type { Actor, PetType, Stats, UserRecord } from "./types";
import { ZERO_STATS } from "./types";

const FAMILY = ["陳", "李", "黃", "張", "林", "吳", "鄭", "何", "周", "馬", "梁", "蔡", "許", "鄧", "馮", "曾", "葉", "劉", "謝", "潘", "羅", "鍾", "賴", "湯"];
const GIVEN = ["大文", "小明", "家欣", "志強", "美玲", "俊傑", "凱晴", "詠詩", "柏豪", "天朗", "嘉怡", "子軒", "文迪", "佩珊", "皓然", "樂兒", "志明", "穎琳", "家豪", "曉彤", "子謙", "嘉寶", "思穎", "卓霖", "詩雅", "俊熙", "朗晴", "子晴", "家樂", "凱琳"];

function studentName(index: number) {
  const surname = FAMILY[index % FAMILY.length];
  const given = GIVEN[(index * 7) % GIVEN.length];
  return `${surname}${given}`;
}

function bonus(partial: Partial<Stats>): Stats {
  return { ...ZERO_STATS(), ...partial };
}

const ITEMS: Record<string, unknown>[] = [
  { itemId: "item_wood_sword", name: "木劍", category: "weapon", rarity: "common", price: 10, statsBonus: bonus({ attack: 2 }), description: "輕巧的練習木劍，適合剛剛出發的寵物。" },
  { itemId: "item_iron_sword", name: "鐵劍", category: "weapon", rarity: "rare", price: 25, statsBonus: bonus({ attack: 5 }), description: "鍛得結實的鐵劍，攻擊力明顯提升。" },
  { itemId: "item_wand", name: "魔法法杖", category: "weapon", rarity: "epic", price: 60, statsBonus: bonus({ attack: 10 }), description: "杖頭嵌着一顆會輕輕發亮的石頭。" },
  { itemId: "item_wood_shield", name: "木盾", category: "armor", rarity: "common", price: 10, statsBonus: bonus({ defense: 2 }), description: "圓圓的木盾，擋得住課堂裡的小風波。" },
  { itemId: "item_iron_shield", name: "鐵盾", category: "armor", rarity: "rare", price: 25, statsBonus: bonus({ defense: 5 }), description: "厚實鐵盾，防禦成長很穩。" },
  { itemId: "item_helm", name: "騎士頭盔", category: "headgear", rarity: "rare", price: 30, statsBonus: bonus({ defense: 4 }), description: "亮面頭盔，戴上時耳朵仍露得出來。" },
  { itemId: "item_boots", name: "速度靴", category: "accessory", rarity: "rare", price: 25, statsBonus: bonus({ speed: 3 }), description: "靴底有彈力，步伐會變得輕快。" },
  { itemId: "item_charm", name: "幸運項鏈", category: "accessory", rarity: "epic", price: 40, statsBonus: bonus({ criticalRate: 3 }), description: "小小的金墜子，據說能帶來準確一擊。" },
  { itemId: "item_cloak", name: "星光斗篷", category: "armor", rarity: "legendary", price: 120, statsBonus: bonus({ defense: 8, hp: 12 }), description: "斗篷邊緣繡着細星，是商店裡最華麗的防具。" },
  { itemId: "item_leaf", name: "葉子髮圈", category: "cosmetic", rarity: "common", price: 8, statsBonus: bonus({}), description: "森林狐也很喜歡的小葉子，只改變造型。" },
  { itemId: "item_snack", name: "行軍乾糧", category: "consumable", rarity: "common", price: 8, statsBonus: bonus({}), description: "預留給未來對戰的補給。現時只可收藏，不能使用。" },
];

const REWARDS: Record<string, unknown>[] = [
  { rewardId: "reward_pen", name: "原子筆", description: "書寫順滑的藍色原子筆。", price: 15, stock: 30 },
  { rewardId: "reward_sticker", name: "貼紙包", description: "一套課室主題貼紙。", price: 10, stock: 40 },
  { rewardId: "reward_gift", name: "小禮品", description: "由老師預備的小禮物。", price: 40, stock: 12 },
  { rewardId: "reward_book", name: "課室圖書券", description: "可向老師換取一本課外書。", price: 80, stock: 5 },
];

export async function seedIfEmpty(db: Database) {
  const users = await db.read((repo) => repo.list<UserRecord>(C.users));
  if (users.length) return;
  const teacher = await createTeacher(
    db,
    null,
    {
      displayName: DEMO.teacherName,
      loginId: DEMO.teacherLogin,
      password: DEMO.teacherPassword,
      authorizedClassIds: [],
    },
    true,
  );
  const plan = [
    { className: "1A", count: 30 },
    { className: "1B", count: 24 },
    { className: "2A", count: 18 },
  ];
  let nameIndex = 0;
  for (const entry of plan) {
    const room = await createClass(db, teacher, { className: entry.className, schoolYear: "2026-2027" });
    for (let number = 1; number <= entry.count; number += 1) {
      const created = await addStudent(db, teacher, {
        classId: room.classId,
        classNumber: number,
        studentName: studentName(nameIndex),
        password: DEMO.studentPassword,
      });
      nameIndex += 1;
      if (entry.className === "1A" && number <= 8) {
        const studentActor: Actor = {
          uid: created.student.userId!,
          role: "student",
          displayName: created.student.displayName,
          loginId: created.loginId,
          linkedStudentId: created.student.studentId,
          authorizedClassIds: [],
        };
        const petType = PET_TYPES[(number - 1) % PET_TYPES.length] as PetType;
        await choosePet(db, studentActor, {
          petType,
          name: number === 1 ? "火火" : undefined,
        });
        const amount = number === 1 ? 30 : 6 + number * 2;
        await awardPoints(db, teacher, {
          studentIds: [created.student.studentId],
          amount,
          reason: number === 1 ? "開學表現獎勵" : "課堂參與",
          mode: "earn",
          idempotencyKey: `seed-award-${room.classId}-${number}`,
        });
      }
    }
    if (entry.className === "1A") {
      for (let draw = 0; draw < 4; draw += 1) {
        await performDraw(db, teacher, {
          classId: room.classId,
          idempotencyKey: `seed-draw-${draw + 1}`,
        });
      }
    }
  }
  for (const item of ITEMS) {
    await saveItem(db, teacher, String(item.itemId), { ...item, allowCreate: true, isActive: true });
  }
  for (const reward of REWARDS) {
    await saveReward(db, teacher, String(reward.rewardId), { ...reward, allowCreate: true, isActive: true });
  }
  await updateSettings(db, teacher, { demoMode: true, schoolYear: "2026-2027" });
}
