import type { CollectionName } from "./collections";

export interface Repo {
  get<T>(collection: CollectionName, id: string): Promise<T | null>;
  set<T>(collection: CollectionName, id: string, value: T): Promise<void>;
  delete(collection: CollectionName, id: string): Promise<void>;
  list<T>(collection: CollectionName): Promise<T[]>;
}

export interface Database {
  backend: "sqlite" | "firestore";
  read<T>(fn: (repo: Repo) => Promise<T>): Promise<T>;
  withTransaction<T>(fn: (repo: Repo) => Promise<T>): Promise<T>;
  authenticate(loginId: string, password: string): Promise<import("./types").UserRecord | null>;
  /** Mutates the user record with a password hash, or creates/updates the Firebase Auth user. */
  provisionLogin(user: import("./types").UserRecord, password: string): Promise<void>;
}
