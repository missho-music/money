import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";

const SCRYPT = {
  N: Number(process.env.CPQ_SCRYPT_N || 16384),
  r: 8,
  p: 1,
} as const;

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString("base64url");
  const hash = scryptSync(password, salt, 32, SCRYPT).toString("base64url");
  return { salt, hash };
}

export function verifyPassword(password: string, salt: string, hash: string) {
  const actual = scryptSync(password, salt, 32, SCRYPT);
  const expected = Buffer.from(hash, "base64url");
  if (actual.length !== expected.length) return false;
  return timingSafeEqual(actual, expected);
}

export function assertPasswordStrength(password: string) {
  if (password.length < 8 || password.length > 72) {
    throw new Error("密碼長度需為 8 至 72 個字元");
  }
}
