import { AppError } from "./errors";
import * as game from "./game-services";
import { getDatabase, ready } from "./db";
import * as accounts from "./services";
import { signSession } from "./session";
import type { Actor } from "./types";

export type ApiResult =
  | { kind: "json"; status: number; body: unknown; session?: string | null }
  | { kind: "file"; filename: string; contentType: string; body: Buffer };

function json(body: unknown, status = 200, session?: string | null): ApiResult {
  return { kind: "json", status, body, session };
}

function must(actor: Actor | null) {
  if (!actor) throw new AppError(401, "請先登入。", "AUTH");
  return actor;
}

function payload(body: Record<string, unknown>) {
  return body as never;
}

async function readBody(request: Request) {
  if (request.method === "GET" || request.method === "HEAD") return {} as Record<string, unknown>;
  const type = request.headers.get("content-type") ?? "";
  if (!type.includes("application/json")) return {} as Record<string, unknown>;
  try {
    const value = await request.json();
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      throw new AppError(400, "請求格式不正確。", "VALIDATION");
    }
    return value as Record<string, unknown>;
  } catch (error) {
    if (error instanceof AppError) throw error;
    throw new AppError(400, "請求格式不正確。", "VALIDATION");
  }
}

export async function dispatch(request: Request, parts: string[], actor: Actor | null): Promise<ApiResult> {
  await ready();
  const db = getDatabase();
  const method = request.method.toUpperCase();
  const query = new URL(request.url).searchParams;
  const body = await readBody(request);
  const [resource, id, action] = parts;

  if (method === "GET" && resource === "demo" && !id) return json(await accounts.demoHint(db));
  if (method === "POST" && resource === "auth" && id === "login") {
    const loggedIn = await accounts.login(db, body.loginId, body.password);
    return json({ actor: loggedIn }, 200, signSession(loggedIn.uid));
  }
  if (method === "POST" && resource === "auth" && id === "logout") return json({ ok: true }, 200, null);
  if (method === "POST" && resource === "auth" && id === "password") {
    return json(await accounts.changePassword(db, must(actor), body.currentPassword, body.nextPassword));
  }
  if (method === "GET" && resource === "me" && !id) {
    return json(await accounts.getSessionProfile(db, must(actor)));
  }

  if (method === "GET" && resource === "teachers" && !id) return json(await accounts.listTeachers(db, must(actor)));
  if (method === "POST" && resource === "teachers" && !id) {
    return json(await accounts.createTeacher(db, must(actor), payload(body)));
  }

  if (method === "GET" && resource === "classes" && !id) return json(await accounts.listClasses(db, must(actor)));
  if (method === "POST" && resource === "classes" && !id) return json(await accounts.createClass(db, must(actor), payload(body)));
  if (method === "PATCH" && resource === "classes" && id) {
    return json(await accounts.updateClass(db, must(actor), id, body));
  }

  if (method === "GET" && resource === "students" && !id) {
    return json(await accounts.listStudents(db, must(actor), { classId: query.get("classId"), q: query.get("q") }));
  }
  if (method === "POST" && resource === "students" && id === "import") {
    return json(await game.importStudents(db, must(actor), payload(body)));
  }
  if (method === "POST" && resource === "students" && !id) {
    return json(
      await accounts.addStudent(db, must(actor), {
        classId: String(body.classId ?? ""),
        classNumber: Number(body.classNumber),
        studentName: String(body.studentName ?? ""),
        displayName: typeof body.displayName === "string" ? body.displayName : null,
      }),
    );
  }
  if (method === "PATCH" && resource === "students" && id && !action) {
    return json(await accounts.updateStudent(db, must(actor), id, body));
  }
  if (method === "POST" && resource === "students" && id && action === "password") {
    return json(await game.resetStudentPassword(db, must(actor), id));
  }

  if (method === "GET" && resource === "absences") {
    return json(await game.getAbsences(db, must(actor), query.get("classId") ?? "", query.get("date")));
  }
  if ((method === "PUT" || method === "POST") && resource === "absences") {
    return json(await game.setAbsences(db, must(actor), payload(body)));
  }

  if (method === "GET" && resource === "draws" && id === "state") {
    return json(await game.getDrawState(db, must(actor), query.get("classId") ?? ""));
  }
  if (method === "POST" && resource === "draws" && !id) return json(await game.performDraw(db, must(actor), payload(body)));
  if (method === "POST" && resource === "draws" && id === "resolve") {
    return json(await game.resolveDraw(db, must(actor), payload(body)));
  }
  if (method === "POST" && resource === "draws" && id === "reset") {
    return json(await game.resetRound(db, must(actor), payload(body)));
  }
  if (method === "GET" && resource === "draws" && id === "history") {
    return json(
      await game.listDrawHistory(db, must(actor), {
        classId: query.get("classId"),
        studentId: query.get("studentId"),
        from: query.get("from"),
        to: query.get("to"),
      }),
    );
  }

  if (method === "GET" && resource === "points" && id === "transactions") {
    return json(await game.listTransactions(db, must(actor), query.get("studentId") ?? ""));
  }
  if (method === "GET" && resource === "points" && !id) {
    return json(await game.listClassPoints(db, must(actor), query.get("classId") ?? ""));
  }
  if (method === "POST" && resource === "points" && id === "award") {
    return json(await game.awardPoints(db, must(actor), payload(body)));
  }
  if (method === "POST" && resource === "points" && id === "draw-award") {
    return json(await game.awardFromDraw(db, must(actor), payload(body)));
  }

  if (method === "GET" && resource === "leaderboard") {
    return json(await game.leaderboard(db, must(actor), query.get("classId"), query.get("period")));
  }

  if (method === "GET" && resource === "items" && !id) return json(await game.listItems(db, must(actor)));
  if (method === "POST" && resource === "items" && !id) return json(await game.saveItem(db, must(actor), null, body));
  if (method === "PATCH" && resource === "items" && id) return json(await game.saveItem(db, must(actor), id, body));

  if (method === "GET" && resource === "rewards" && !id) return json(await game.listRewards(db, must(actor)));
  if (method === "POST" && resource === "rewards" && !id) return json(await game.saveReward(db, must(actor), null, body));
  if (method === "PATCH" && resource === "rewards" && id) {
    return json(await game.saveReward(db, must(actor), id, body));
  }

  if (method === "POST" && resource === "shop" && id === "purchase") {
    return json(await game.purchaseItem(db, must(actor), payload(body)));
  }
  if (method === "POST" && resource === "rewards" && id === "redeem") {
    return json(await game.redeemReward(db, must(actor), payload(body)));
  }

  if (method === "GET" && resource === "orders" && !id) {
    return json(
      await game.listOrders(db, must(actor), {
        status: query.get("status"),
        studentId: query.get("studentId"),
        orderType: query.get("orderType"),
      }),
    );
  }
  if (method === "POST" && resource === "orders" && id && action === "fulfill") {
    return json(await game.fulfillOrder(db, must(actor), id));
  }
  if (method === "POST" && resource === "orders" && id && action === "cancel") {
    return json(await game.cancelOrder(db, must(actor), id, body.note));
  }

  if (method === "GET" && resource === "pets" && id === "choices") return json(game.petChoices());
  if (method === "GET" && resource === "pets" && id === "home") {
    return json(await game.studentHome(db, must(actor), query.get("studentId")));
  }
  if (method === "GET" && resource === "pets" && !id) {
    return json(await game.listClassPets(db, must(actor), query.get("classId") ?? ""));
  }
  if (method === "POST" && resource === "pets" && id === "choose") return json(await game.choosePet(db, must(actor), payload(body)));
  if (method === "POST" && resource === "pets" && id === "rename") {
    return json(await game.renamePet(db, must(actor), body.name));
  }
  if (method === "POST" && resource === "pets" && id === "equip") {
    return json(await game.equipItem(db, must(actor), body.inventoryId));
  }
  if (method === "POST" && resource === "pets" && id === "unequip") {
    return json(await game.unequipItem(db, must(actor), body.slot));
  }

  if (method === "GET" && resource === "settings") return json(await game.getSettings(db, must(actor)));
  if (method === "PATCH" && resource === "settings") return json(await game.updateSettings(db, must(actor), body));
  if (method === "GET" && resource === "reports") return json(await game.reportOverview(db, must(actor)));
  if (method === "GET" && resource === "export") {
    const file = await game.exportData(db, must(actor), {
      kind: query.get("kind"),
      format: query.get("format"),
      classId: query.get("classId"),
      from: query.get("from"),
      to: query.get("to"),
    });
    return { kind: "file", ...file };
  }

  throw new AppError(404, "找不到這個功能。", "NOT_FOUND");
}
