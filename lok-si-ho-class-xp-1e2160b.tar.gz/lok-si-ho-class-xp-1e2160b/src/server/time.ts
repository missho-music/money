export function hkDateString(date = new Date()) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Hong_Kong",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

export function hkParts(date = new Date()) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Hong_Kong",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
  const pick = (type: string) => Number(parts.find((part) => part.type === type)?.value);
  return { year: pick("year"), month: pick("month"), day: pick("day") };
}

/** Monday-based week key in Hong Kong, formatted YYYY-MM-DD of that Monday. */
export function hkWeekStart(date = new Date()) {
  const day = new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Hong_Kong",
    weekday: "short",
  }).format(date);
  const index: Record<string, number> = { Mon: 0, Tue: 1, Wed: 2, Thu: 3, Fri: 4, Sat: 5, Sun: 6 };
  const offset = index[day] ?? 0;
  const shifted = new Date(date.getTime() - offset * 24 * 60 * 60 * 1000);
  return hkDateString(shifted);
}

export function hkMonthKey(date = new Date()) {
  const { year, month } = hkParts(date);
  return `${year}-${String(month).padStart(2, "0")}`;
}

export function inRange(iso: string, from?: string | null, to?: string | null) {
  const day = hkDateString(new Date(iso));
  if (from && day < from) return false;
  if (to && day > to) return false;
  return true;
}
