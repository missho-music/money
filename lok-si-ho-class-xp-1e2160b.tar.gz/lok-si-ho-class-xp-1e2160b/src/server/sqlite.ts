import { mkdirSync } from "node:fs";
import { createRequire } from "node:module";
import path from "node:path";
import type { CollectionName } from "./collections";
import { loginKey } from "./collections";
import { C } from "./collections";
import { verifyPassword } from "./password";
import { hashPassword } from "./password";
import type { Database, Repo } from "./repo";
import type { LoginLock, UserRecord } from "./types";

interface SqlStatement {
  run(...params: unknown[]): unknown;
  get(...params: unknown[]): unknown;
  all(...params: unknown[]): unknown[];
}

interface SqlDatabase {
  exec(sql: string): void;
  prepare(sql: string): SqlStatement;
  close(): void;
}

const require = createRequire(import.meta.url);
const { DatabaseSync } = require("node:sqlite") as {
  DatabaseSync: new (filename: string) => SqlDatabase;
};

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

class SqliteRepo implements Repo {
  constructor(private db: SqlDatabase) {}

  async get<T>(collection: CollectionName, id: string): Promise<T | null> {
    const row = this.db
      .prepare("SELECT json FROM docs WHERE collection = ? AND id = ?")
      .get(collection, id) as { json: string } | undefined;
    return row ? (JSON.parse(row.json) as T) : null;
  }

  async set<T>(collection: CollectionName, id: string, value: T): Promise<void> {
    const json = JSON.stringify(value);
    this.db
      .prepare(
        `INSERT INTO docs (collection, id, json) VALUES (?, ?, ?)
         ON CONFLICT(collection, id) DO UPDATE SET json = excluded.json`,
      )
      .run(collection, id, json);
  }

  async delete(collection: CollectionName, id: string): Promise<void> {
    this.db.prepare("DELETE FROM docs WHERE collection = ? AND id = ?").run(collection, id);
  }

  async list<T>(collection: CollectionName): Promise<T[]> {
    const rows = this.db
      .prepare("SELECT json FROM docs WHERE collection = ?")
      .all(collection) as { json: string }[];
    return rows.map((row) => JSON.parse(row.json) as T);
  }
}

function createLock() {
  let tail = Promise.resolve();
  return function lock<T>(fn: () => Promise<T>): Promise<T> {
    const run = tail.then(fn, fn);
    tail = run.then(
      () => undefined,
      () => undefined,
    );
    return run;
  };
}

export function createSqliteDatabase(filename: string): Database {
  mkdirSync(path.dirname(filename), { recursive: true });
  const db = new DatabaseSync(filename);
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA busy_timeout = 5000;
    CREATE TABLE IF NOT EXISTS docs (
      collection TEXT NOT NULL,
      id TEXT NOT NULL,
      json TEXT NOT NULL,
      PRIMARY KEY (collection, id)
    );
  `);
  const repo = new SqliteRepo(db);
  const lock = createLock();

  const database: Database = {
    backend: "sqlite",
    read(fn) {
      return lock(() => fn(repo));
    },
    withTransaction(fn) {
      return lock(async () => {
        db.exec("BEGIN IMMEDIATE");
        try {
          const result = await fn(repo);
          db.exec("COMMIT");
          return result;
        } catch (error) {
          try {
            db.exec("ROLLBACK");
          } catch {
            /* already rolled back */
          }
          throw error;
        }
      });
    },
    async authenticate(loginId, password) {
      const lockDoc = await database.read((r) =>
        r.get<LoginLock>(C.loginIndex, loginKey(loginId)),
      );
      if (!lockDoc) return null;
      const user = await database.read((r) => r.get<UserRecord>(C.users, lockDoc.uid));
      if (!user?.passwordHash || !user.passwordSalt) return null;
      return verifyPassword(password, user.passwordSalt, user.passwordHash) ? clone(user) : null;
    },
    async provisionLogin(user, password) {
      const { hash, salt } = hashPassword(password);
      user.passwordHash = hash;
      user.passwordSalt = salt;
    },
  };

  return database;
}
