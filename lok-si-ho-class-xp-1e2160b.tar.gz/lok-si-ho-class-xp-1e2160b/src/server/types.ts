export type Role = "teacher" | "student";
export type EnrollmentStatus = "active" | "withdrawn";
export type ClassStatus = "active" | "archived";
export type PetType = "fire" | "water" | "nature" | "thunder";
export type ItemCategory =
  | "weapon"
  | "armor"
  | "headgear"
  | "accessory"
  | "consumable"
  | "cosmetic";
export type EquipSlot =
  | "weapon"
  | "armor"
  | "headgear"
  | "accessory"
  | "appearance";
export type Rarity = "common" | "rare" | "epic" | "legendary";
export type DrawResultKind = "selected" | "returned" | "marked";
export type PointType = "earn" | "spend" | "adjust" | "refund";
export type OrderType = "virtual" | "physical";
export type OrderStatus = "completed" | "pending" | "fulfilled" | "cancelled";
export type RoundStatus = "ready" | "active" | "completed";

export interface Stats {
  hp: number;
  attack: number;
  defense: number;
  speed: number;
  criticalRate: number;
}

export interface UserRecord {
  uid: string;
  role: Role;
  displayName: string;
  loginId: string;
  linkedStudentId: string | null;
  authorizedClassIds: string[];
  passwordHash: string | null;
  passwordSalt: string | null;
  createdAt: string;
}

export interface Actor {
  uid: string;
  role: Role;
  displayName: string;
  loginId: string;
  linkedStudentId: string | null;
  authorizedClassIds: string[];
}

export interface ClassRoom {
  classId: string;
  className: string;
  schoolYear: string;
  status: ClassStatus;
  createdAt: string;
}

export interface Student {
  studentId: string;
  classId: string;
  classNumber: number;
  studentName: string;
  displayName: string;
  userId: string | null;
  enrollmentStatus: EnrollmentStatus;
  createdAt: string;
}

export interface Wallet {
  studentId: string;
  currentBalance: number;
  lifetimeEarned: number;
  lifetimeSpent: number;
  pendingExp: number;
  updatedAt: string;
}

export interface PointTransaction {
  transactionId: string;
  studentId: string;
  amount: number;
  type: PointType;
  reason: string;
  createdBy: string;
  createdAt: string;
  relatedReferenceId: string | null;
  idempotencyKey: string | null;
}

export interface DrawSession {
  sessionId: string;
  classId: string;
  roundNumber: number;
  drawnStudentIds: string[];
  status: "active" | "completed";
  startedAt: string;
  completedAt: string | null;
}

export interface DrawRecord {
  drawId: string;
  sessionId: string;
  classId: string;
  studentId: string;
  roundNumber: number;
  result: DrawResultKind;
  timestamp: string;
  createdBy: string;
  awards: Record<string, string>;
}

export interface Absence {
  classId: string;
  date: string;
  studentIds: string[];
}

export interface Equipped {
  weapon: string | null;
  armor: string | null;
  headgear: string | null;
  accessory: string | null;
  appearance: string | null;
}

export interface Pet {
  petId: string;
  studentId: string;
  petType: PetType;
  name: string;
  level: number;
  exp: number;
  equipped: Equipped;
  createdAt: string;
}

export interface Item {
  itemId: string;
  name: string;
  category: ItemCategory;
  rarity: Rarity;
  price: number;
  statsBonus: Stats;
  description: string;
  imageKey: string | null;
  stock: number | null;
  purchaseLimit: number | null;
  minLevel: number;
  isActive: boolean;
  slot: EquipSlot | null;
  updatedAt: string;
}

export interface Reward {
  rewardId: string;
  name: string;
  description: string;
  price: number;
  stock: number;
  isActive: boolean;
  updatedAt: string;
}

export interface InventoryItem {
  inventoryId: string;
  studentId: string;
  itemId: string;
  quantity: number;
  acquiredAt: string;
  orderId: string | null;
}

export interface Order {
  orderId: string;
  studentId: string;
  orderType: OrderType;
  itemId: string;
  itemName: string;
  quantity: number;
  totalPrice: number;
  status: OrderStatus;
  createdAt: string;
  fulfilledAt: string | null;
  idempotencyKey: string | null;
  note: string | null;
}

export interface PointRule {
  id: string;
  label: string;
  points: number;
}

export interface Settings {
  schoolYear: string;
  expPerCoin: number;
  levelBaseExp: number;
  levelGrowth: number;
  pointRules: PointRule[];
  fastDraw: boolean;
  leaderboardEnabled: boolean;
  leaderboardUseNickname: boolean;
  projectionShowsFullName: boolean;
  featureFlags: {
    battle: false;
  };
  demoMode: boolean;
}

export interface SeatLock {
  studentId: string;
}

export interface LoginLock {
  uid: string;
}

export interface IdempotencyRecord {
  body: unknown;
  createdAt: string;
}

export const EMPTY_EQUIPPED = (): Equipped => ({
  weapon: null,
  armor: null,
  headgear: null,
  accessory: null,
  appearance: null,
});

export const ZERO_STATS = (): Stats => ({
  hp: 0,
  attack: 0,
  defense: 0,
  speed: 0,
  criticalRate: 0,
});
