import "server-only";
import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { cookies } from "next/headers";
import { C } from "./collections";
import { getDatabase, ready } from "./db";
import { toActor } from "./services";
import type { UserRecord } from "./types";

function secret() {
  if (process.env.SESSION_SECRET) return process.env.SESSION_SECRET;
  const file = path.join(process.cwd(), "data", "session.secret");
  if (existsSync(file)) return readFileSync(file, "utf8");
  mkdirSync(path.dirname(file), { recursive: true });
  const value = randomBytes(32).toString("base64url");
  writeFileSync(file, value, { mode: 0o600 });
  return value;
}

export function signSession(uid: string) {
  const body = Buffer.from(JSON.stringify({ uid, exp: Date.now() + 16 * 60 * 60 * 1000 })).toString(
    "base64url",
  );
  const signature = createHmac("sha256", secret()).update(body).digest("base64url");
  return `${body}.${signature}`;
}

export function readSessionUid(token: string) {
  const [body, signature] = token.split(".");
  if (!body || !signature) return null;
  const expected = createHmac("sha256", secret()).update(body).digest("base64url");
  const left = Buffer.from(signature);
  const right = Buffer.from(expected);
  if (left.length !== right.length || !timingSafeEqual(left, right)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, "base64url").toString()) as { uid?: string; exp?: number };
    if (!payload.uid || !payload.exp || payload.exp < Date.now()) return null;
    return payload.uid;
  } catch {
    return null;
  }
}

export async function getActor() {
  await ready();
  const jar = await cookies();
  const token = jar.get("cpq_session")?.value;
  if (!token) return null;
  const uid = readSessionUid(token);
  if (!uid) return null;
  const user = await getDatabase().read((repo) => repo.get<UserRecord>(C.users, uid));
  return user ? toActor(user) : null;
}

export const SESSION_COOKIE = "cpq_session";

export function sessionCookieOptions() {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    path: "/",
    maxAge: 60 * 60 * 16,
    secure: process.env.COOKIE_SECURE === "true",
  };
}
