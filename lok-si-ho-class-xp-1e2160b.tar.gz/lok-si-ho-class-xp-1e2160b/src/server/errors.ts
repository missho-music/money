export class AppError extends Error {
  constructor(
    public status: number,
    message: string,
    public code: string,
    public details?: Record<string, unknown>,
  ) {
    super(message);
    this.name = "AppError";
  }
}

export function toErrorBody(error: unknown) {
  if (error instanceof AppError) {
    return {
      status: error.status,
      body: { error: error.message, code: error.code, details: error.details ?? null },
    };
  }
  console.error("[cpq]", error instanceof Error ? error.message : "unknown");
  return {
    status: 500,
    body: { error: "系統暫時未能完成操作，請稍後再試。", code: "INTERNAL", details: null },
  };
}
