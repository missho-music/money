import { defaultSettings, makeLoginId, progressFromExp } from "./catalog";
import { C, SETTINGS_ID, absenceKey, loginKey, seatKey } from "./collections";
import { AppError } from "./errors";
import { newId, nowIso, randomIntBelow, temporaryPassword } from "./ids";
import { parseStudentTable, toCsv, toXlsx } from "./importers";
import { assertPasswordStrength } from "./password";
import type { Database, Repo } from "./repo";
import { hkDateString, hkMonthKey, hkWeekStart, inRange } from "./time";
import type {
  Absence,
  Actor,
  ClassRoom,
  DrawRecord,
  DrawSession,
  Equipped,
  IdempotencyRecord,
  InventoryItem,
  Item,
  ItemCategory,
  LoginLock,
  Order,
  Pet,
  PetType,
  PointRule,
  PointTransaction,
  Rarity,
  Reward,
  SeatLock,
  Settings,
  Student,
  UserRecord,
  Wallet,
} from "./types";
import { EMPTY_EQUIPPED } from "./types";

const EQUIP_ORDER = ["weapon", "armor", "headgear", "accessory", "appearance"] as const;
const RARITIES = new Set<Rarity>(["common", "rare", "epic", "legendary"]);
const CATEGORIES = new Set<ItemCategory>([
  "weapon",
  "armor",
  "headgear",
  "accessory",
  "consumable",
  "cosmetic",
]);

const failures = new Map<string, { count: number; until: number }>();

export const DEMO = {
  teacherLogin: "teacher@petquest.school",
  teacherPassword: "PetQuest2026",
  teacherName: "陳老師",
  studentPassword: "Student2026",
  sampleLogin: "1A-01",
  sampleLabel: "1A 陳大文",
};

export function toActor(user: UserRecord): Actor {
  return {
    uid: user.uid,
    role: user.role,
    displayName: user.displayName,
    loginId: user.loginId,
    linkedStudentId: user.linkedStudentId,
    authorizedClassIds: user.authorizedClassIds ?? [],
  };
}

function publicUser(user: UserRecord) {
  return {
    uid: user.uid,
    role: user.role,
    displayName: user.displayName,
    loginId: user.loginId,
    linkedStudentId: user.linkedStudentId,
    authorizedClassIds: user.authorizedClassIds,
    createdAt: user.createdAt,
  };
}

export function assertTeacher(actor: Actor, classId?: string | null) {
  if (actor.role !== "teacher") {
    throw new AppError(403, "只有教師可以執行此操作。", "FORBIDDEN");
  }
  if (
    classId &&
    actor.authorizedClassIds.length > 0 &&
    !actor.authorizedClassIds.includes(classId)
  ) {
    throw new AppError(403, "你未獲授權管理此班別。", "FORBIDDEN_CLASS");
  }
}

export function ownStudentId(actor: Actor) {
  if (actor.role !== "student" || !actor.linkedStudentId) {
    throw new AppError(403, "只可以管理自己的資料。", "FORBIDDEN");
  }
  return actor.linkedStudentId;
}

export function text(value: unknown, label: string, max: number) {
  if (typeof value !== "string") throw new AppError(400, `${label}不正確。`, "VALIDATION");
  const trimmed = value.trim();
  if (!trimmed || trimmed.length > max) throw new AppError(400, `${label}不正確。`, "VALIDATION");
  return trimmed;
}

export function optionalText(value: unknown, label: string, max: number) {
  if (value == null || value === "") return null;
  return text(value, label, max);
}

export function integer(value: unknown, label: string, min: number, max: number) {
  const number = typeof value === "number" ? value : Number(value);
  if (!Number.isInteger(number) || number < min || number > max) {
    throw new AppError(400, `${label}不正確。`, "VALIDATION");
  }
  return number;
}

export function idempotencyKey(value: unknown) {
  const key = text(value, "操作編號", 80);
  if (!/^[A-Za-z0-9:_-]{6,80}$/.test(key)) {
    throw new AppError(400, "操作編號不正確。", "VALIDATION");
  }
  return key;
}

function passwordOrThrow(value: unknown) {
  if (typeof value !== "string") throw new AppError(400, "密碼不正確。", "VALIDATION");
  try {
    assertPasswordStrength(value);
  } catch (error) {
    throw new AppError(400, error instanceof Error ? error.message : "密碼不正確。", "VALIDATION");
  }
  return value;
}

export async function settingsOf(repo: Repo) {
  return (await repo.get<Settings>(C.settings, SETTINGS_ID)) ?? defaultSettings();
}

export async function cached<T>(repo: Repo, key: string): Promise<T | undefined> {
  const existing = await repo.get<IdempotencyRecord>(C.idempotency, key);
  return existing ? (existing.body as T) : undefined;
}

export async function remember(repo: Repo, key: string, body: unknown) {
  const record: IdempotencyRecord = { body, createdAt: nowIso() };
  await repo.set(C.idempotency, key, record);
}

export function petDocId(studentId: string) {
  return `pet_${studentId}`;
}

export function emptyWallet(studentId: string): Wallet {
  return {
    studentId,
    currentBalance: 0,
    lifetimeEarned: 0,
    lifetimeSpent: 0,
    pendingExp: 0,
    updatedAt: nowIso(),
  };
}

export function syncLevel(pet: Pet, settings: Settings) {
  pet.level = progressFromExp(pet.exp, settings.levelBaseExp, settings.levelGrowth).level;
}

function grantExp(wallet: Wallet, pet: Pet | null, coins: number, settings: Settings) {
  const delta = coins * settings.expPerCoin;
  if (!delta) return;
  if (pet) {
    pet.exp = Math.max(0, pet.exp + delta);
    syncLevel(pet, settings);
  } else {
    wallet.pendingExp = Math.max(0, wallet.pendingExp + delta);
  }
}

export function earn(wallet: Wallet, pet: Pet | null, amount: number, settings: Settings) {
  wallet.currentBalance += amount;
  wallet.lifetimeEarned += amount;
  wallet.updatedAt = nowIso();
  grantExp(wallet, pet, amount, settings);
}

export function spend(wallet: Wallet, amount: number) {
  if (wallet.currentBalance < amount) {
    throw new AppError(
      400,
      `寵物金幣不足。需要 ${amount}，目前餘額 ${wallet.currentBalance}。`,
      "INSUFFICIENT",
      { price: amount, balance: wallet.currentBalance },
    );
  }
  wallet.currentBalance -= amount;
  wallet.lifetimeSpent += amount;
  wallet.updatedAt = nowIso();
}

export function deduct(wallet: Wallet, pet: Pet | null, amount: number, settings: Settings) {
  if (wallet.currentBalance < amount) {
    throw new AppError(400, "扣除後金幣不可低於 0，請改用較小的數值。", "BELOW_ZERO", {
      balance: wallet.currentBalance,
    });
  }
  wallet.currentBalance -= amount;
  wallet.updatedAt = nowIso();
  grantExp(wallet, pet, -amount, settings);
}

export function refundCoins(wallet: Wallet, amount: number) {
  wallet.currentBalance += amount;
  wallet.lifetimeSpent = Math.max(0, wallet.lifetimeSpent - amount);
  wallet.updatedAt = nowIso();
}

export function tx(input: Omit<PointTransaction, "transactionId" | "createdAt">): PointTransaction {
  return { ...input, transactionId: newId("ptx"), createdAt: nowIso() };
}

export async function requireClass(repo: Repo, classId: string) {
  const room = await repo.get<ClassRoom>(C.classes, classId);
  if (!room) throw new AppError(404, "找不到班別。", "CLASS");
  return room;
}

export function resultLabel(result: DrawRecord["result"]) {
  if (result === "returned") return "稍後再抽";
  if (result === "marked") return "略過並標記已抽";
  return "抽中";
}

export async function login(db: Database, loginIdRaw: unknown, passwordRaw: unknown) {
  const loginId = text(loginIdRaw, "登入名稱", 80);
  const password = typeof passwordRaw === "string" ? passwordRaw : "";
  if (password.length < 1 || password.length > 72) {
    throw new AppError(401, "帳號或密碼不正確。", "AUTH");
  }
  const key = loginKey(loginId);
  const bucket = failures.get(key);
  if (bucket && bucket.until > Date.now() && bucket.count >= 8) {
    throw new AppError(429, "嘗試次數太多，請稍後再試。", "RATE_LIMIT");
  }
  const user = await db.authenticate(loginId, password);
  if (!user) {
    const count = bucket && bucket.until > Date.now() ? bucket.count + 1 : 1;
    failures.set(key, { count, until: Date.now() + 10 * 60 * 1000 });
    throw new AppError(401, "帳號或密碼不正確。", "AUTH");
  }
  failures.delete(key);
  return toActor(user);
}

export async function changePassword(
  db: Database,
  actor: Actor,
  currentPassword: unknown,
  nextPassword: unknown,
) {
  const next = passwordOrThrow(nextPassword);
  if (typeof currentPassword !== "string" || !(await db.authenticate(actor.loginId, currentPassword))) {
    throw new AppError(400, "目前密碼不正確。", "AUTH");
  }
  const user = await db.read((repo) => repo.get<UserRecord>(C.users, actor.uid));
  if (!user) throw new AppError(401, "請重新登入。", "AUTH");
  await db.provisionLogin(user, next);
  await db.withTransaction(async (repo) => {
    await repo.set(C.users, user.uid, user);
  });
  return { ok: true };
}

export async function getSessionProfile(db: Database, actor: Actor) {
  const settings = await db.read(settingsOf);
  return {
    actor,
    backend: db.backend,
    demoMode: settings.demoMode,
    schoolYear: settings.schoolYear,
    battleEnabled: false,
  };
}

export async function demoHint(db: Database) {
  const settings = await db.read(settingsOf);
  return {
    backend: db.backend,
    demoMode: settings.demoMode,
    accounts: settings.demoMode
      ? [
          {
            role: "teacher",
            label: DEMO.teacherName,
            loginId: DEMO.teacherLogin,
            password: DEMO.teacherPassword,
          },
          {
            role: "student",
            label: DEMO.sampleLabel,
            loginId: DEMO.sampleLogin,
            password: DEMO.studentPassword,
          },
        ]
      : [],
  };
}

export async function listTeachers(db: Database, actor: Actor) {
  assertTeacher(actor);
  const users = await db.read((repo) => repo.list<UserRecord>(C.users));
  return users.filter((user) => user.role === "teacher").map(publicUser);
}

export async function createTeacher(
  db: Database,
  actor: Actor | null,
  input: {
    displayName: unknown;
    loginId: unknown;
    password: unknown;
    authorizedClassIds?: unknown;
  },
  bootstrap = false,
) {
  if (!bootstrap) {
    if (!actor) throw new AppError(401, "請先登入。", "AUTH");
    assertTeacher(actor);
  }
  const displayName = text(input.displayName, "教師名稱", 40);
  const loginId = text(input.loginId, "登入名稱", 80);
  const password = passwordOrThrow(input.password);
  const classIds = Array.isArray(input.authorizedClassIds)
    ? input.authorizedClassIds.map((id) => text(id, "班別", 80))
    : [];
  const user: UserRecord = {
    uid: newId("usr"),
    role: "teacher",
    displayName,
    loginId,
    linkedStudentId: null,
    authorizedClassIds: classIds,
    passwordHash: null,
    passwordSalt: null,
    createdAt: nowIso(),
  };
  await db.provisionLogin(user, password);
  await db.withTransaction(async (repo) => {
    for (const classId of classIds) await requireClass(repo, classId);
    const existing = await repo.get<LoginLock>(C.loginIndex, loginKey(loginId));
    if (existing) throw new AppError(409, "此登入名稱已被使用。", "DUPLICATE_LOGIN");
    await repo.set(C.loginIndex, loginKey(user.loginId), { uid: user.uid });
    await repo.set(C.users, user.uid, user);
  });
  return toActor(user);
}

export async function listClasses(db: Database, actor: Actor) {
  assertTeacher(actor);
  return db.read(async (repo) => {
    const [classes, students] = await Promise.all([
      repo.list<ClassRoom>(C.classes),
      repo.list<Student>(C.students),
    ]);
    return classes
      .filter(
        (room) =>
          actor.authorizedClassIds.length === 0 || actor.authorizedClassIds.includes(room.classId),
      )
      .map((room) => ({
        ...room,
        studentCount: students.filter(
          (student) => student.classId === room.classId && student.enrollmentStatus === "active",
        ).length,
      }))
      .sort((a, b) => a.className.localeCompare(b.className, "zh-Hant"));
  });
}

export async function createClass(
  db: Database,
  actor: Actor,
  input: { className: unknown; schoolYear?: unknown },
) {
  assertTeacher(actor);
  const settings = await db.read(settingsOf);
  const className = text(input.className, "班別名稱", 12);
  const schoolYear = input.schoolYear ? text(input.schoolYear, "學年", 9) : settings.schoolYear;
  if (!/^\d{4}-\d{4}$/.test(schoolYear)) {
    throw new AppError(400, "學年格式應為 2026-2027。", "VALIDATION");
  }
  const room: ClassRoom = {
    classId: newId("cls"),
    className,
    schoolYear,
    status: "active",
    createdAt: nowIso(),
  };
  await db.withTransaction(async (repo) => {
    const classes = await repo.list<ClassRoom>(C.classes);
    const duplicate = classes.some(
      (item) =>
        item.status === "active" &&
        item.schoolYear === schoolYear &&
        item.className.toLowerCase() === className.toLowerCase(),
    );
    if (duplicate) throw new AppError(409, "同學年已有相同班別名稱。", "DUPLICATE_CLASS");
    await repo.set(C.classes, room.classId, room);
  });
  return room;
}

export async function updateClass(
  db: Database,
  actor: Actor,
  classId: string,
  input: { className?: unknown; status?: unknown },
) {
  assertTeacher(actor, classId);
  return db.withTransaction(async (repo) => {
    const room = await requireClass(repo, classId);
    const classes = await repo.list<ClassRoom>(C.classes);
    if (input.className !== undefined) room.className = text(input.className, "班別名稱", 12);
    if (input.status !== undefined) {
      if (input.status !== "active" && input.status !== "archived") {
        throw new AppError(400, "班別狀態不正確。", "VALIDATION");
      }
      room.status = input.status;
    }
    const duplicate = classes.some(
      (item) =>
        item.classId !== room.classId &&
        item.status === "active" &&
        room.status === "active" &&
        item.schoolYear === room.schoolYear &&
        item.className.toLowerCase() === room.className.toLowerCase(),
    );
    if (duplicate) throw new AppError(409, "同學年已有相同班別名稱。", "DUPLICATE_CLASS");
    await repo.set(C.classes, room.classId, room);
    return room;
  });
}

async function studentView(repo: Repo, student: Student, today: string) {
  const [user, wallet, pet, absence] = await Promise.all([
    student.userId ? repo.get<UserRecord>(C.users, student.userId) : Promise.resolve(null),
    repo.get<Wallet>(C.wallets, student.studentId),
    repo.get<Pet>(C.pets, petDocId(student.studentId)),
    repo.get<Absence>(C.absences, absenceKey(student.classId, today)),
  ]);
  return {
    ...student,
    loginId: user?.loginId ?? null,
    wallet: wallet ?? emptyWallet(student.studentId),
    petLevel: pet?.level ?? null,
    petType: pet?.petType ?? null,
    absentToday: Boolean(absence?.studentIds.includes(student.studentId)),
  };
}

export async function listStudents(
  db: Database,
  actor: Actor,
  query: { classId?: string | null; q?: string | null },
) {
  const today = hkDateString();
  if (actor.role === "student") {
    return db.read(async (repo) => {
      const student = await repo.get<Student>(C.students, ownStudentId(actor));
      return student ? [await studentView(repo, student, today)] : [];
    });
  }
  assertTeacher(actor, query.classId);
  const needle = query.q?.trim().toLowerCase() ?? "";
  return db.read(async (repo) => {
    const students = (await repo.list<Student>(C.students)).filter((student) => {
      if (actor.authorizedClassIds.length && !actor.authorizedClassIds.includes(student.classId)) {
        return false;
      }
      if (query.classId && student.classId !== query.classId) return false;
      return true;
    });
    const views = [];
    for (const student of students) views.push(await studentView(repo, student, today));
    return views
      .filter((student) => {
        if (!needle) return true;
        return (
          student.studentName.toLowerCase().includes(needle) ||
          student.displayName.toLowerCase().includes(needle) ||
          String(student.classNumber) === needle ||
          (student.loginId ?? "").toLowerCase().includes(needle)
        );
      })
      .sort((a, b) => a.classNumber - b.classNumber);
  });
}

export async function addStudent(
  db: Database,
  actor: Actor,
  input: {
    classId: string;
    classNumber: number;
    studentName: string;
    displayName?: string | null;
    loginId?: string | null;
    password?: string;
  },
) {
  assertTeacher(actor, input.classId);
  const classNumber = integer(input.classNumber, "學號", 1, 80);
  const studentName = text(input.studentName, "學生姓名", 40);
  const displayName = input.displayName ? text(input.displayName, "顯示名稱", 40) : studentName;
  const room = await db.read((repo) => requireClass(repo, input.classId));
  if (room.status !== "active") throw new AppError(400, "班別已封存，不能新增學生。", "CLASS");
  assertTeacher(actor, room.classId);
  let loginId = input.loginId ? text(input.loginId, "登入名稱", 80) : makeLoginId(room.className, classNumber);
  const password = input.password ?? temporaryPassword();
  passwordOrThrow(password);
  const taken = await db.read((repo) => repo.get<LoginLock>(C.loginIndex, loginKey(loginId)));
  if (taken) loginId = `${room.schoolYear}-${makeLoginId(room.className, classNumber)}`;
  const studentId = newId("stu");
  const user: UserRecord = {
    uid: newId("usr"),
    role: "student",
    displayName,
    loginId,
    linkedStudentId: studentId,
    authorizedClassIds: [],
    passwordHash: null,
    passwordSalt: null,
    createdAt: nowIso(),
  };
  const student: Student = {
    studentId,
    classId: room.classId,
    classNumber,
    studentName,
    displayName,
    userId: user.uid,
    enrollmentStatus: "active",
    createdAt: nowIso(),
  };
  await db.provisionLogin(user, password);
  student.userId = user.uid;
  await db.withTransaction(async (repo) => {
    const current = await requireClass(repo, room.classId);
    if (current.status !== "active") throw new AppError(400, "班別已封存。", "CLASS");
    const seat = await repo.get<SeatLock>(C.seats, seatKey(current.classId, classNumber));
    if (seat) throw new AppError(409, "此班學號已被使用。", "DUPLICATE_SEAT");
    const login = await repo.get<LoginLock>(C.loginIndex, loginKey(user.loginId));
    if (login) throw new AppError(409, "此登入名稱已被使用。", "DUPLICATE_LOGIN");
    await repo.set(C.seats, seatKey(current.classId, classNumber), { studentId });
    await repo.set(C.loginIndex, loginKey(user.loginId), { uid: user.uid });
    await repo.set(C.users, user.uid, user);
    await repo.set(C.students, studentId, student);
    await repo.set(C.wallets, studentId, emptyWallet(studentId));
  });
  return { student, loginId: user.loginId, temporaryPassword: password };
}

export async function updateStudent(
  db: Database,
  actor: Actor,
  studentId: string,
  input: {
    studentName?: unknown;
    displayName?: unknown;
    classId?: unknown;
    classNumber?: unknown;
    enrollmentStatus?: unknown;
  },
) {
  assertTeacher(actor);
  return db.withTransaction(async (repo) => {
    const student = await repo.get<Student>(C.students, studentId);
    if (!student) throw new AppError(404, "找不到學生。", "STUDENT");
    assertTeacher(actor, student.classId);
    const previousClassId = student.classId;
    const previousNumber = student.classNumber;
    const wasActive = student.enrollmentStatus === "active";
    const nextClassId = input.classId === undefined ? student.classId : text(input.classId, "班別", 80);
    const nextNumber =
      input.classNumber === undefined ? student.classNumber : integer(input.classNumber, "學號", 1, 80);
    const nextStatus = input.enrollmentStatus === undefined ? student.enrollmentStatus : input.enrollmentStatus;
    if (nextStatus !== "active" && nextStatus !== "withdrawn") {
      throw new AppError(400, "學生狀態不正確。", "VALIDATION");
    }
    if (nextClassId !== student.classId) {
      const destination = await requireClass(repo, nextClassId);
      if (destination.status !== "active") throw new AppError(400, "目標班別已封存。", "CLASS");
      assertTeacher(actor, destination.classId);
    }
    const user = student.userId ? await repo.get<UserRecord>(C.users, student.userId) : null;
    const oldSeat = wasActive
      ? await repo.get<SeatLock>(C.seats, seatKey(previousClassId, previousNumber))
      : null;
    const nextSeat =
      nextStatus === "active" ? await repo.get<SeatLock>(C.seats, seatKey(nextClassId, nextNumber)) : null;
    if (nextSeat && nextSeat.studentId !== student.studentId) {
      throw new AppError(409, "此班學號已被使用。", "DUPLICATE_SEAT");
    }
    if (input.studentName !== undefined) student.studentName = text(input.studentName, "學生姓名", 40);
    if (input.displayName !== undefined) student.displayName = text(input.displayName, "顯示名稱", 40);
    const moveSeat =
      wasActive && (nextStatus !== "active" || nextClassId !== previousClassId || nextNumber !== previousNumber);
    student.classId = nextClassId;
    student.classNumber = nextNumber;
    student.enrollmentStatus = nextStatus;
    if (moveSeat && oldSeat?.studentId === student.studentId) {
      await repo.delete(C.seats, seatKey(previousClassId, previousNumber));
    }
    if (nextStatus === "active") {
      await repo.set(C.seats, seatKey(nextClassId, nextNumber), { studentId: student.studentId });
    }
    if (user) {
      user.displayName = student.displayName;
      await repo.set(C.users, user.uid, user);
    }
    await repo.set(C.students, student.studentId, student);
    return student;
  });
}
