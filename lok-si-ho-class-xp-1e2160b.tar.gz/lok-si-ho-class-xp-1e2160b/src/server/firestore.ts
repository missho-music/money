import { getApps, cert, initializeApp, type App } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore, type Firestore, type Transaction } from "firebase-admin/firestore";
import type { CollectionName } from "./collections";
import { C, loginKey } from "./collections";
import { AppError } from "./errors";
import type { Database, Repo } from "./repo";
import type { LoginLock, UserRecord } from "./types";

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

function firebaseApp(): App {
  const existing = getApps()[0];
  if (existing) return existing;
  const projectId = process.env.FIREBASE_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  const privateKey = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, "\n");
  if (!projectId || !clientEmail || !privateKey) {
    throw new AppError(500, "Firebase 管理員憑證未設定。", "FIREBASE_CONFIG");
  }
  return initializeApp({
    credential: cert({ projectId, clientEmail, privateKey }),
    storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
  });
}

export function toAuthEmail(loginId: string) {
  const raw = loginId.trim().toLowerCase();
  if (raw.includes("@")) return raw;
  const local = raw.replace(/[^a-z0-9._+-]/g, "-").replace(/^-+|-+$/g, "");
  return `${local || "student"}@students.classroom-pet-quest.local`;
}

class FirestoreRepo implements Repo {
  private overlay = new Map<string, unknown | null>();
  private cache = new Map<string, Map<string, unknown>>();
  private writing = false;

  constructor(
    private fs: Firestore,
    private tx: Transaction | null,
  ) {}

  private key(collection: string, id: string) {
    return `${collection}/${id}`;
  }

  async get<T>(collection: CollectionName, id: string): Promise<T | null> {
    const key = this.key(collection, id);
    if (this.overlay.has(key)) {
      const value = this.overlay.get(key);
      return value == null ? null : clone(value as T);
    }
    const cached = this.cache.get(collection)?.get(id);
    if (cached !== undefined) return clone(cached as T);
    if (this.writing) {
      throw new Error(`Firestore read after write: ${key}`);
    }
    const ref = this.fs.collection(collection).doc(id);
    const snap = this.tx ? await this.tx.get(ref) : await ref.get();
    if (!snap.exists) return null;
    return clone(snap.data() as T);
  }

  async set<T>(collection: CollectionName, id: string, value: T): Promise<void> {
    const stored = clone(value);
    const key = this.key(collection, id);
    this.overlay.set(key, stored);
    const bucket = this.cache.get(collection);
    if (bucket) bucket.set(id, stored);
    if (!this.tx) {
      await this.fs.collection(collection).doc(id).set(stored as FirebaseFirestore.DocumentData);
      this.overlay.delete(key);
      return;
    }
    this.writing = true;
  }

  async delete(collection: CollectionName, id: string): Promise<void> {
    const key = this.key(collection, id);
    this.overlay.set(key, null);
    this.cache.get(collection)?.delete(id);
    if (!this.tx) {
      await this.fs.collection(collection).doc(id).delete();
      this.overlay.delete(key);
      return;
    }
    this.writing = true;
  }

  async list<T>(collection: CollectionName): Promise<T[]> {
    let bucket = this.cache.get(collection);
    if (!bucket) {
      if (this.writing) throw new Error(`Firestore query after write: ${collection}`);
      const ref = this.fs.collection(collection);
      const snap = this.tx ? await this.tx.get(ref) : await ref.get();
      bucket = new Map();
      snap.docs.forEach((doc) => bucket!.set(doc.id, doc.data()));
      this.cache.set(collection, bucket);
    }
    const merged = new Map(bucket);
    for (const [key, value] of this.overlay) {
      const prefix = `${collection}/`;
      if (!key.startsWith(prefix)) continue;
      const id = key.slice(prefix.length);
      if (value == null) merged.delete(id);
      else merged.set(id, value);
    }
    return [...merged.values()].map((value) => clone(value as T));
  }

  flush() {
    if (!this.tx) return;
    for (const [key, value] of this.overlay) {
      const slash = key.indexOf("/");
      const ref = this.fs.collection(key.slice(0, slash)).doc(key.slice(slash + 1));
      if (value == null) this.tx.delete(ref);
      else this.tx.set(ref, value as FirebaseFirestore.DocumentData);
    }
  }
}

async function firebaseSignIn(loginId: string, password: string) {
  const apiKey = process.env.FIREBASE_WEB_API_KEY;
  if (!apiKey) throw new AppError(500, "未設定 FIREBASE_WEB_API_KEY。", "FIREBASE_CONFIG");
  const response = await fetch(
    `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${apiKey}`,
    {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        email: toAuthEmail(loginId),
        password,
        returnSecureToken: true,
      }),
    },
  );
  return response.ok;
}

export function createFirestoreDatabase(): Database {
  const fs = getFirestore(firebaseApp());
  const database: Database = {
    backend: "firestore",
    async read(fn) {
      return fn(new FirestoreRepo(fs, null));
    },
    async withTransaction(fn) {
      return fs.runTransaction(async (tx) => {
        const repo = new FirestoreRepo(fs, tx);
        const result = await fn(repo);
        repo.flush();
        return result;
      });
    },
    async authenticate(loginId, password) {
      const ok = await firebaseSignIn(loginId, password);
      if (!ok) return null;
      const lockDoc = await database.read((repo) =>
        repo.get<LoginLock>(C.loginIndex, loginKey(loginId)),
      );
      if (!lockDoc) return null;
      return database.read((repo) => repo.get<UserRecord>(C.users, lockDoc.uid));
    },
    async provisionLogin(user, password) {
      const auth = getAuth(firebaseApp());
      const email = toAuthEmail(user.loginId);
      try {
        const created = await auth.createUser({
          uid: user.uid,
          email,
          password,
          displayName: user.displayName,
        });
        user.uid = created.uid;
      } catch (error) {
        const code = (error as { code?: string }).code;
        if (code === "auth/email-already-exists" || code === "auth/uid-already-exists") {
          const existing = await auth.getUserByEmail(email);
          await auth.updateUser(existing.uid, { password, displayName: user.displayName });
          user.uid = existing.uid;
        } else {
          throw error;
        }
      }
      user.passwordHash = null;
      user.passwordSalt = null;
    },
  };
  return database;
}
