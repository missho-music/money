import Papa from "papaparse";
import * as XLSX from "xlsx";
import { AppError } from "./errors";

export interface StudentRow {
  rowNumber: number;
  className: string;
  classNumber: number;
  studentName: string;
  displayName: string;
}

const CLASS_KEYS = ["class", "班別", "班級", "class name", "classname"];
const NUMBER_KEYS = ["class number", "classnumber", "class no", "學號", "班號", "no", "number"];
const NAME_KEYS = ["student name", "studentname", "姓名", "學生姓名", "name"];
const DISPLAY_KEYS = ["display name", "displayname", "顯示名稱", "nickname"];

function cell(row: Record<string, unknown>, keys: string[]) {
  for (const [rawKey, value] of Object.entries(row)) {
    if (!keys.includes(rawKey.trim().toLowerCase())) continue;
    if (value == null) continue;
    const text = String(value).trim();
    if (text) return text;
  }
  return "";
}

function rowsFromUnknown(table: Record<string, unknown>[]): StudentRow[] {
  const rows: StudentRow[] = [];
  table.forEach((row, index) => {
    const className = cell(row, CLASS_KEYS);
    const numberText = cell(row, NUMBER_KEYS);
    const studentName = cell(row, NAME_KEYS);
    if (!className && !numberText && !studentName) return;
    const classNumber = Number(numberText);
    if (!className || !studentName || !Number.isInteger(classNumber) || classNumber < 1 || classNumber > 80) {
      throw new AppError(400, `第 ${index + 2} 行資料不完整或學號不正確。`, "IMPORT_ROW", {
        row: index + 2,
      });
    }
    const displayName = cell(row, DISPLAY_KEYS) || studentName;
    rows.push({
      rowNumber: index + 2,
      className,
      classNumber,
      studentName,
      displayName,
    });
  });
  if (!rows.length) throw new AppError(400, "檔案沒有可匯入的學生。", "IMPORT_EMPTY");
  if (rows.length > 500) throw new AppError(400, "一次最多匯入 500 位學生。", "IMPORT_LIMIT");
  return rows;
}

export function parseStudentTable(input: { csv?: string; fileBase64?: string; filename?: string }) {
  if (input.csv) {
    if (input.csv.length > 2_000_000) throw new AppError(400, "檔案太大。", "IMPORT_LIMIT");
    const parsed = Papa.parse<Record<string, unknown>>(input.csv, {
      header: true,
      skipEmptyLines: "greedy",
    });
    if (parsed.errors.length && parsed.data.length === 0) {
      throw new AppError(400, "CSV 格式不正確。", "IMPORT_PARSE");
    }
    return rowsFromUnknown(parsed.data);
  }
  if (!input.fileBase64) throw new AppError(400, "請上傳 CSV 或 Excel 檔案。", "IMPORT_PARSE");
  if (input.fileBase64.length > 3_000_000) throw new AppError(400, "檔案太大。", "IMPORT_LIMIT");
  const workbook = XLSX.read(Buffer.from(input.fileBase64, "base64"), { type: "buffer" });
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  if (!sheet) throw new AppError(400, "Excel 沒有工作表。", "IMPORT_PARSE");
  const table = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: "" });
  return rowsFromUnknown(table);
}

export function toCsv(rows: Record<string, string | number | null | undefined>[]) {
  if (!rows.length) return "\uFEFF";
  const headers = Object.keys(rows[0]);
  const lines = [headers.join(",")];
  for (const row of rows) {
    lines.push(
      headers
        .map((header) => {
          const text = row[header] == null ? "" : String(row[header]);
          return /[",\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
        })
        .join(","),
    );
  }
  return `\uFEFF${lines.join("\n")}`;
}

export function toXlsx(rows: Record<string, string | number | null | undefined>[], sheetName: string) {
  const sheet = XLSX.utils.json_to_sheet(rows);
  const book = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(book, sheet, sheetName.slice(0, 31));
  return XLSX.write(book, { type: "buffer", bookType: "xlsx" }) as Buffer;
}
