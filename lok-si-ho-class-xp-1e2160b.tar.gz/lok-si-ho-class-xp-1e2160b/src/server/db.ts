import "server-only";
import path from "node:path";
import { createFirestoreDatabase } from "./firestore";
import type { Database } from "./repo";
import { seedIfEmpty } from "./seed";
import { createSqliteDatabase } from "./sqlite";

const globalStore = globalThis as unknown as {
  __cpq?: Database;
  __cpqReady?: Promise<void>;
};

export function getDatabase(): Database {
  if (!globalStore.__cpq) {
    if (process.env.DATA_BACKEND === "firestore") {
      globalStore.__cpq = createFirestoreDatabase();
      globalStore.__cpqReady = Promise.resolve();
    } else {
      const filename = process.env.DATABASE_PATH || path.join(process.cwd(), "data", "classroom.sqlite");
      const database = createSqliteDatabase(filename);
      globalStore.__cpq = database;
      globalStore.__cpqReady = seedIfEmpty(database);
    }
  }
  return globalStore.__cpq;
}

export async function ready() {
  getDatabase();
  await globalStore.__cpqReady;
}
