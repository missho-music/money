import assert from "node:assert/strict";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import test from "node:test";
import { readFileSync } from "node:fs";
import {
  awardFromDraw,
  awardPoints,
  equipItem,
  getDrawState,
  listTransactions,
  performDraw,
  purchaseItem,
  resetRound,
  resolveDraw,
  saveItem,
  setAbsences,
  studentHome,
  unequipItem,
  choosePet,
  importStudents,
  updateSettings,
} from "../src/server/game-services";
import { createSqliteDatabase } from "../src/server/sqlite";
import { addStudent, createClass, createTeacher, listStudents } from "../src/server/services";
import type { Actor } from "../src/server/types";
import { AppError } from "../src/server/errors";

function tempDb() {
  const dir = mkdtempSync(path.join(tmpdir(), "cpq-"));
  return createSqliteDatabase(path.join(dir, "class.sqlite"));
}

async function teacherAndClass(db: ReturnType<typeof tempDb>, className = "1A", count = 3) {
  const teacher = await createTeacher(
    db,
    null,
    {
      displayName: "陳老師",
      loginId: `teacher-${className}-${count}@test.school`,
      password: "PetQuest2026",
      authorizedClassIds: [],
    },
    true,
  );
  const room = await createClass(db, teacher, { className, schoolYear: "2026-2027" });
  const students = [];
  for (let number = 1; number <= count; number += 1) {
    students.push(
      await addStudent(db, teacher, {
        classId: room.classId,
        classNumber: number,
        studentName: `學生${number}`,
        password: "Student2026",
      }),
    );
  }
  return { teacher, room, students };
}

function asStudent(created: Awaited<ReturnType<typeof addStudent>>): Actor {
  return {
    uid: created.student.userId!,
    role: "student",
    displayName: created.student.displayName,
    loginId: created.loginId,
    linkedStudentId: created.student.studentId,
    authorizedClassIds: [],
  };
}

test("draw does not repeat until the round is reset", async () => {
  const db = tempDb();
  const { teacher, room } = await teacherAndClass(db, "1A", 30);
  const picked = new Set<string>();
  for (let index = 0; index < 30; index += 1) {
    const result = await performDraw(db, teacher, {
      classId: room.classId,
      idempotencyKey: `draw-round-${index}`,
    });
    assert.equal(result.status, "selected");
    if (result.status !== "selected") return;
    assert.equal(picked.has(result.student.studentId), false);
    picked.add(result.student.studentId);
    if (index === 29) assert.equal(result.roundComplete, true);
  }
  assert.equal(picked.size, 30);
  const blocked = await performDraw(db, teacher, {
    classId: room.classId,
    idempotencyKey: "draw-round-blocked",
  });
  assert.equal(blocked.status, "round_complete");
  assert.match(String(blocked.message), /本輪抽籤已完成/);
});

test("class draw progress stays independent", async () => {
  const db = tempDb();
  const { teacher, room } = await teacherAndClass(db, "1A", 12);
  const other = await createClass(db, teacher, { className: "1B", schoolYear: "2026-2027" });
  for (let number = 1; number <= 8; number += 1) {
    await addStudent(db, teacher, {
      classId: other.classId,
      classNumber: number,
      studentName: `乙班${number}`,
      password: "Student2026",
    });
  }
  for (let index = 0; index < 10; index += 1) {
    await performDraw(db, teacher, { classId: room.classId, idempotencyKey: `draw-a-${index}` });
  }
  for (let index = 0; index < 5; index += 1) {
    await performDraw(db, teacher, { classId: other.classId, idempotencyKey: `draw-b-${index}` });
  }
  const back = await getDrawState(db, teacher, room.classId);
  const away = await getDrawState(db, teacher, other.classId);
  assert.equal(back.drawnCount, 10);
  assert.equal(away.drawnCount, 5);
  assert.equal(back.totalActive, 12);
});

test("records survive reopening the database", async () => {
  const dir = mkdtempSync(path.join(tmpdir(), "cpq-persist-"));
  const filename = path.join(dir, "class.sqlite");
  const db = createSqliteDatabase(filename);
  const { teacher, room, students } = await teacherAndClass(db, "1A", 2);
  await awardPoints(db, teacher, {
    studentIds: [students[0].student.studentId],
    amount: 3,
    reason: "正確回答問題",
    mode: "earn",
    idempotencyKey: "persist-award",
  });
  const reopened = createSqliteDatabase(filename);
  const rows = await listStudents(reopened, teacher, { classId: room.classId });
  const target = rows.find((row) => row.studentId === students[0].student.studentId);
  assert.equal(target?.wallet.currentBalance, 3);
  const history = await listTransactions(reopened, teacher, students[0].student.studentId);
  assert.equal(history.length, 1);
  assert.equal(history[0].reason, "正確回答問題");
});

test("awarding coins writes a transaction and never drops earned total when spending", async () => {
  const db = tempDb();
  const { teacher, students } = await teacherAndClass(db, "1A", 1);
  const student = asStudent(students[0]);
  await awardPoints(db, teacher, {
    studentIds: [students[0].student.studentId],
    amount: 3,
    reason: "主動參與課堂",
    mode: "earn",
    idempotencyKey: "earn-three",
  });
  let home = await studentHome(db, student);
  assert.equal(home.wallet.currentBalance, 3);
  assert.equal(home.wallet.lifetimeEarned, 3);
  await updateSettings(db, teacher, { expPerCoin: 10 });
  await choosePet(db, student, { petType: "fire", name: "火火" });
  await awardPoints(db, teacher, {
    studentIds: [students[0].student.studentId],
    amount: 27,
    reason: "補發",
    mode: "earn",
    idempotencyKey: "earn-rest",
  });
  await saveItem(db, teacher, "item_iron_sword", {
    allowCreate: true,
    name: "鐵劍",
    category: "weapon",
    rarity: "rare",
    price: 25,
    statsBonus: { attack: 5 },
    description: "鐵劍",
    isActive: true,
  });
  const before = await studentHome(db, student);
  const purchased = await purchaseItem(db, student, {
    itemId: "item_iron_sword",
    idempotencyKey: "buy-iron-sword",
  });
  assert.equal(purchased.wallet.currentBalance, 5);
  assert.equal(purchased.wallet.lifetimeEarned, 30);
  assert.equal(purchased.wallet.lifetimeSpent, 25);
  home = await studentHome(db, student);
  assert.equal(home.detail?.pet.exp, before.detail?.pet.exp);
  assert.ok((home.detail?.inventory.length ?? 0) >= 1);
});

test("purchase is rejected when balance is too low and a double click does not charge twice", async () => {
  const db = tempDb();
  const { teacher, students } = await teacherAndClass(db, "1A", 1);
  const student = asStudent(students[0]);
  await choosePet(db, student, { petType: "fire" });
  await updateSettings(db, teacher, { expPerCoin: 0 });
  await saveItem(db, teacher, "item_iron_sword", {
    allowCreate: true,
    name: "鐵劍",
    category: "weapon",
    rarity: "rare",
    price: 25,
    statsBonus: { attack: 5 },
    description: "鐵劍",
    isActive: true,
  });
  await awardPoints(db, teacher, {
    studentIds: [student.linkedStudentId],
    amount: 5,
    reason: "少少獎勵",
    mode: "earn",
    idempotencyKey: "small-award",
  });
  await assert.rejects(
    () => purchaseItem(db, student, { itemId: "item_iron_sword", idempotencyKey: "too-poor" }),
    (error: unknown) => error instanceof AppError && error.code === "INSUFFICIENT",
  );
  const still = await studentHome(db, student);
  assert.equal(still.wallet.currentBalance, 5);
  await awardPoints(db, teacher, {
    studentIds: [student.linkedStudentId],
    amount: 25,
    reason: "補足",
    mode: "earn",
    idempotencyKey: "top-up",
  });
  const attempts = await Promise.allSettled([
    purchaseItem(db, student, { itemId: "item_iron_sword", idempotencyKey: "race-a-key" }),
    purchaseItem(db, student, { itemId: "item_iron_sword", idempotencyKey: "race-b-key" }),
  ]);
  const successes = attempts.filter((result) => result.status === "fulfilled");
  assert.equal(successes.length, 1);
  const afterRace = await studentHome(db, student);
  assert.equal(afterRace.wallet.currentBalance, 5);
  assert.equal(afterRace.detail?.inventory.length, 1);
  const winningKey = attempts[0].status === "fulfilled" ? "race-a-key" : "race-b-key";
  const replay = await purchaseItem(db, student, { itemId: "item_iron_sword", idempotencyKey: winningKey });
  const afterReplay = await studentHome(db, student);
  assert.equal(afterReplay.wallet.currentBalance, 5);
  assert.equal(replay.wallet.currentBalance, 5);
});

test("equipment changes attack and comes off cleanly", async () => {
  const db = tempDb();
  const { teacher, students } = await teacherAndClass(db, "1A", 1);
  const student = asStudent(students[0]);
  await choosePet(db, student, { petType: "fire", name: "火火" });
  await updateSettings(db, teacher, { expPerCoin: 0 });
  await saveItem(db, teacher, "item_iron_sword", {
    allowCreate: true,
    name: "鐵劍",
    category: "weapon",
    rarity: "rare",
    price: 25,
    statsBonus: { attack: 5 },
    description: "鐵劍",
    isActive: true,
  });
  await awardPoints(db, teacher, {
    studentIds: [student.linkedStudentId],
    amount: 25,
    reason: "購買測試",
    mode: "earn",
    idempotencyKey: "gear-coins",
  });
  const bought = await purchaseItem(db, student, { itemId: "item_iron_sword", idempotencyKey: "gear-buy" });
  await equipItem(db, student, bought.inventory.inventoryId);
  const equipped = await studentHome(db, student);
  assert.equal(equipped.detail?.combat.base.attack, 10);
  assert.equal(equipped.detail?.combat.final.attack, 15);
  await unequipItem(db, student, "weapon");
  const removed = await studentHome(db, student);
  assert.equal(removed.detail?.combat.final.attack, 10);
});

test("students cannot change coins, classmates, or shop prices", async () => {
  const db = tempDb();
  const { teacher, students } = await teacherAndClass(db, "1A", 2);
  const student = asStudent(students[0]);
  const other = students[1].student.studentId;
  await assert.rejects(
    () =>
      awardPoints(db, student, {
        studentIds: [student.linkedStudentId],
        amount: 100,
        reason: "自己加分",
        mode: "earn",
        idempotencyKey: "cheat-coins",
      }),
    (error: unknown) => error instanceof AppError && error.code === "FORBIDDEN",
  );
  await assert.rejects(
    () => listTransactions(db, student, other),
    (error: unknown) => error instanceof AppError && error.code === "FORBIDDEN",
  );
  await assert.rejects(
    () =>
      saveItem(db, student, "item_iron_sword", {
        name: "免費劍",
        category: "weapon",
        rarity: "common",
        price: 0,
        description: "不行",
      }),
    (error: unknown) => error instanceof AppError && error.code === "FORBIDDEN",
  );
  await assert.rejects(
    () => performDraw(db, student, { classId: "class", idempotencyKey: "student-draw" }),
    (error: unknown) => error instanceof AppError && error.code === "FORBIDDEN",
  );
  void teacher;
});

test("absence, skip, and manual reset keep history", async () => {
  const db = tempDb();
  const { teacher, room, students } = await teacherAndClass(db, "1A", 3);
  await setAbsences(db, teacher, {
    classId: room.classId,
    studentIds: [students[0].student.studentId],
  });
  const seen = new Set<string>();
  for (let index = 0; index < 2; index += 1) {
    const result = await performDraw(db, teacher, { classId: room.classId, idempotencyKey: `absent-${index}` });
    assert.equal(result.status, "selected");
    if (result.status === "selected") {
      assert.notEqual(result.student.studentId, students[0].student.studentId);
      seen.add(result.student.studentId);
    }
  }
  await assert.rejects(
    () => performDraw(db, teacher, { classId: room.classId, idempotencyKey: "absent-empty" }),
    (error: unknown) => error instanceof AppError && error.code === "NO_ELIGIBLE",
  );
  const returned = await performDraw(db, teacher, { classId: room.classId, idempotencyKey: "will-return" }).catch(
    () => null,
  );
  assert.equal(returned, null);
  const first = await performDraw(db, teacher, { classId: room.classId, idempotencyKey: "absent-0" });
  assert.equal(first.status, "selected");
  if (first.status !== "selected") return;
  await resolveDraw(db, teacher, { drawId: first.draw.drawId, action: "return" });
  const state = await getDrawState(db, teacher, room.classId);
  assert.equal(state.drawnCount, 1);
  await awardFromDraw(db, teacher, {
    drawId: first.draw.drawId,
    ruleId: "correct",
    idempotencyKey: "should-fail-award",
  }).then(
    () => assert.fail("returned student should not be awarded"),
    (error: unknown) => assert.equal(error instanceof AppError && error.code, "DRAW_RETURNED"),
  );
  const markedDraw = await performDraw(db, teacher, { classId: room.classId, idempotencyKey: "mark-me" });
  assert.equal(markedDraw.status, "selected");
  if (markedDraw.status !== "selected") return;
  await resolveDraw(db, teacher, { drawId: markedDraw.draw.drawId, action: "mark" });
  await awardFromDraw(db, teacher, {
    drawId: markedDraw.draw.drawId,
    ruleId: "correct",
    idempotencyKey: "award-once",
  });
  const repeat = await awardFromDraw(db, teacher, {
    drawId: markedDraw.draw.drawId,
    ruleId: "correct",
    idempotencyKey: "award-once-again",
  });
  assert.equal(repeat.already, true);
  const txs = await listTransactions(db, teacher, markedDraw.student.studentId);
  assert.equal(txs.filter((entry) => entry.relatedReferenceId === markedDraw.draw.drawId).length, 1);
  const reset = await resetRound(db, teacher, {
    classId: room.classId,
    confirm: true,
    idempotencyKey: "reset-round-1",
  });
  assert.equal(reset.roundNumber, 2);
  const after = await getDrawState(db, teacher, room.classId);
  assert.equal(after.drawnCount, 0);
  assert.equal(after.roundNumber, 2);
});

test("csv import skips duplicate class numbers", async () => {
  const db = tempDb();
  const teacher = await createTeacher(
    db,
    null,
    { displayName: "陳老師", loginId: "import@test.school", password: "PetQuest2026", authorizedClassIds: [] },
    true,
  );
  const csv = "Class,Class Number,Student Name\n1C,1,Chan Tai Man\n1C,2,Lee Siu Ming\n1C,1,Chan Tai Man\n";
  const first = await importStudents(db, teacher, { csv });
  assert.equal(first.created.length, 2);
  assert.equal(first.skipped.length, 1);
  const second = await importStudents(db, teacher, { csv });
  assert.equal(second.created.length, 0);
  assert.equal(second.skipped.length, 3);
});

test("deduction cannot push a balance below zero", async () => {
  const db = tempDb();
  const { teacher, students } = await teacherAndClass(db, "1A", 1);
  await awardPoints(db, teacher, {
    studentIds: [students[0].student.studentId],
    amount: 3,
    reason: "起始",
    mode: "earn",
    idempotencyKey: "start-balance",
  });
  await assert.rejects(
    () =>
      awardPoints(db, teacher, {
        studentIds: [students[0].student.studentId],
        amount: -5,
        reason: "誤加積分，修正",
        mode: "adjust",
        idempotencyKey: "too-much-off",
      }),
    (error: unknown) => error instanceof AppError && error.code === "BELOW_ZERO",
  );
  const rows = await listTransactions(db, teacher, students[0].student.studentId);
  assert.equal(rows.length, 1);
});

test("firestore rules deny client writes to wallets and prices", () => {
  const rules = readFileSync(path.join(process.cwd(), "firestore.rules"), "utf8");
  assert.match(rules, /match \/wallets\/\{studentId\}/);
  assert.match(rules, /allow write: if false/);
  assert.match(rules, /match \/items\/\{itemId\}/);
  assert.match(rules, /match \/orders\/\{orderId\}/);
});
