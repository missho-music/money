import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { seedIfEmpty } from "../src/server/seed";
import { createSqliteDatabase } from "../src/server/sqlite";
import { C } from "../src/server/collections";

async function main() {
  const dir = mkdtempSync(path.join(tmpdir(), "cpq-seed-"));
  const db = createSqliteDatabase(path.join(dir, "class.sqlite"));
  await seedIfEmpty(db);
  const [classes, students, items, pets, draws] = await db.read(async (repo) =>
    Promise.all([
      repo.list(C.classes),
      repo.list(C.students),
      repo.list(C.items),
      repo.list(C.pets),
      repo.list(C.drawHistory),
    ]),
  );
  console.log({
    classes: classes.length,
    students: students.length,
    items: items.length,
    pets: pets.length,
    draws: draws.length,
  });
  await seedIfEmpty(db);
  console.log("second seed skipped");
}

main();
